import os, time
from Spectral_algorithms import XYZ_from_matfile, fun_rotation_mat, generate_data, Predicted_KI, Predicted_KRR, \
    Predicted_KGD, Predicted_TSVD, KRR_condi_lambda, KGD_condi_step, TSVD_condi_nu, parameter_lambda_krr_forplot, \
    parameter_step_kgd_forplot, parameter_lambda_TSVD_forplot, parameter_lambda_krr
import pandas as pd
from numpy import *
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib import rcParams
import matplotlib.gridspec as gridspec
from matplotlib.ticker import FuncFormatter
time_start = time.time()



'''0. set up'''
func = 'f2'  # from paper "DIVIDE AND CONQUER LEAST SQAURES FOR UNCERTAINTY OF KERNEL INTERPOLATION ON SPHERES"
f, d = 5, 3  # folds of corss-validation; dimension of the input X
test_size = (100, 3)
trails = 5



'''
------------------------------------ 1. Increase the amount of data by increase the "t" in t-design -------------------------------------
Observe the RMSE of KI changes along with the increasing N when noise = 0, 0.001, 0.01, 0.1, 0.3, 0.5
'''
# f2_h3k_rotation = {} # function name: f2, kernel name:h3k, data increasing way: t (of rotation) increases
# np.save('/Users/liuxiaotong/Documents/machine learning/4_Kernel method_spherical/Result_data/f2/f2_h3k_rotation.npy', f2_h3k_rotation)
# print('save f2_h3k_rotation.npy done')

loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/f2_h3k_rotation.npy', allow_pickle=True)
f2_h3k_rotation = loadData.tolist()
print(f2_h3k_rotation.keys())

# np.random.seed(1)
# noise_sd = 0.5
# data_sizes, rmses, condis = [], [], []
#
# t_design = 15 # 120 data
# rotation_total_times = 20 # 2400 total data
# mat_ori = XYZ_from_matfile(t_design)


''' 1.1 caculate RMSE '''
# for i in range(rotation_total_times):
#     XYZ_train = fun_rotation_mat(mat_ori, rotation_total_times, i)
#     X_train, y_train, X_test, y_test = generate_data(XYZ_train, test_size, func, noise_sd)  # generate the (len(XYZ_train), d) training data set and (100, 3) testing data set
#
#     Pred = Predicted_KI(X_train, y_train, X_test, y_test, d)
#     rmse, condi = Pred[1], Pred[2]
#     rmses.append(rmse)
#     condis.append(condi)
#     data_sizes.append(len(XYZ_train))
#     print('RMSEs:', rmses)
#     print('data_sizes:', data_sizes)
#
#
# # noise_sd = 0.0
# # f2_h3k_rotation['KI_rmse_noi0'] = rmses
# # f2_h3k_rotation['KI_sizes'] = data_sizes
# # f2_h3k_rotation['KI_condi'] = condis
#
# # # noise_sd = 0.1
# # f2_h3k_rotation['KI_rmse_noi1'] = rmses
# #
# # # noise_sd = 0.3
# # f2_h3k_rotation['KI_rmse_noi3'] = rmses
# #
# # # noise_sd = 0.5
# f2_h3k_rotation['KI_rmse_noi5'] = rmses
# np.save(os.path.dirname(os.getcwd()) + '/Result_data/f2_h3k_rotation.npy', f2_h3k_rotation)
# print('save f2_h3k_rotation.npy done')
# print(f2_h3k_rotation.keys())
# time_total = time.time() - time_start
# print('runing time:', time_total)


# (2) Plot Condition number and N
# ax.plot(sizes, condis, c='royalblue', linestyle='-', linewidth=1.2) # condi=[1.0, 1.612599660652674, 9.749194001868375, 37.36974223496753, 112.17342650455599, 321.44248868690715, 671.5413553669802, 1398.157423632555, 2541.42629482062, 4215.898770110927, 7070.0432188056175, 10974.549734760414, 16801.509325642714, 25116.383505739737, 34138.36746585262, 47170.15263652693]
# ax.set_xlabel('The number of training samples', fontsize='14')
# ax.set_ylabel('Condition number', fontsize='13')
# plt.yscale('log')
# # plt.ylim(0.9, 100000)  # you can't set the minimum y-value to 0 on a log scale since log(0) is not defined
# # plt.title('Kernel Interpolation', fontsize='12')
# plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/f2/KI_Condi_N(rotation).pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.show()




'''2: RMSE for 5 trails, 5-cv '''
noise_sd = 0.5 # 0.1, 0.3, 0.5
t_design = 15 # 120 data
rotation_total_times = 20 # 2400 total data
mat_ori = XYZ_from_matfile(t_design)
rmses_ki_t5 = np.empty(shape=(20, 5))
for trail in range(trails):
    time_start = time.time()
    rmses_ki = []
    np.random.seed(trail)
    print('------------------------------------------------ trail:', trail + 1)

    for i in range(rotation_total_times):
        print('------------------------------------------------ rotation time:', i)
        XYZ_train = fun_rotation_mat(mat_ori, rotation_total_times, i)
        X_train, y_train, X_test, y_test = generate_data(XYZ_train, test_size, func, noise_sd)  # generate the (len(XYZ_train), d) training data set and (100, 3) testing data set

        # KI
        Pred = Predicted_KI(X_train, y_train, X_test, y_test, d)[1]
        rmses_ki.append(Pred)

    rmses_ki_ar = np.array(rmses_ki)
    rmses_ki_t5[:, trail] = np.squeeze(rmses_ki_ar)
    time_total = time.time() - time_start
    print('runing time for 1 trail:', time_total) # runing time for 1 trail: 1467.094449043274, 24min


f2_h3k_rotation['KI_rmse_noi5_5trails'] = rmses_ki_t5
# f2_h3k_rotation['KI_rmse_noi3_5trails'] = rmses_ki_t5
# f2_h3k_rotation['KI_rmse_noi1_5trails'] = rmses_ki_t5
np.save(os.path.dirname(os.getcwd()) + '/Result_data/f2_h3k_rotation.npy', f2_h3k_rotation)
print('save f2_h3k_rotation.npy done')
print(f2_h3k_rotation.keys())
time_total = time.time() - time_start
print('runing time:', time_total)

