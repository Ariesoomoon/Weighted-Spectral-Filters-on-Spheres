import os, time
from Spectral_algorithms import XYZ_from_matfile, fun_rotation_mat, generate_data, Predicted_KI, Predicted_KRR, \
    Predicted_KGD, Predicted_TSVD, KRR_condi_lambda, KGD_condi_step, TSVD_condi_nu, parameter_lambda_krr_forplot, \
    parameter_step_kgd_forplot, parameter_lambda_TSVD_forplot, parameter_lambda_krr, \
    parameter_lambda_TSVD, RMSE_parameter_tsvd, TSVD_condi_nu_usecondi, parameter_lambda_TSVD_forrotation
import pandas as pd
from numpy import *
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib import rcParams
import matplotlib.gridspec as gridspec
from matplotlib.ticker import FuncFormatter
time_start = time.time()
config = {
    "font.family":'Times New Roman',
    "font.size": 20,
    "mathtext.fontset":'stix',
}
rcParams.update(config)


loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/f2_h3k_rotation.npy', allow_pickle=True)
f2_h3k_rotation = loadData.tolist()
print(f2_h3k_rotation.keys())




'''-------------------------- KRR --------------------------------------'''
# condis_ori = f2_h3k_rotation['KI_condi'][9] # original condition number
# print(condis_ori)
# mus_KRR = f2_h3k_rotation['t15r9_lambdas_KRR']
# condisdrop_KRR = f2_h3k_rotation['t15r9_condisdrop_KRR']
# # print(condisdrop_KRR)
# # print(mus_KRR)
#
# fig = plt.figure(tight_layout=True)
# gs = gridspec.GridSpec(1, 1)
# ax = fig.add_subplot(gs[0, 0])
# ax.grid(linestyle='-.', axis="y")
# plt.axhline(condis_ori,ls="--",c="forestgreen",  linestyle='--', linewidth=1.8)
# ax.plot(mus_KRR, condisdrop_KRR, c='royalblue', marker='o',  linestyle='--', linewidth=1.2, markersize=4)
# ax.set_xlabel('$\\mu$', fontsize='20')
# ax.set_ylabel('Condition number', fontsize='20')
# plt.yscale('log')
# # plt.title('Tikhonov Regularization', fontsize='12')
# plt.legend(['original CN','CN under Tikhonov'], loc='upper right', fontsize=16)
# plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/f2/KRRdropsCondi_mu(rotation, t15r9).pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.show()



'''-------------------------- KGD --------------------------------------'''
# condis_ori = f2_h3k_rotation['KI_condi'][9] # original condition number
# print(condis_ori)
# ts_KGD = f2_h3k_rotation['t15r9_steps_KGD']
# condisdrop_KGD = f2_h3k_rotation['t15r9_condisdrop_KGD']
# # print(condisdrop_KGD)
# # print(ts_KGD)
#
# fig = plt.figure(tight_layout=True)
# gs = gridspec.GridSpec(1, 1)
# ax = fig.add_subplot(gs[0, 0])
# ax.grid(linestyle='-.', axis="y")
# plt.axhline(condis_ori,c="forestgreen", linestyle='--', linewidth=1.8)
# ax.plot(ts_KGD, condisdrop_KGD, c='royalblue', marker='o',  linestyle='--', linewidth=1.2, markersize=4)
# ax.set_xlabel('$t$', fontsize='20')
# ax.set_ylabel('Condition number', fontsize='20')
# plt.yscale('log')
# # plt.ylim(0.009, 1.0)
# # plt.title('Landweber Iteration', fontsize='12')
# plt.legend(['original CN','CN under Landweber'], loc='upper right', fontsize='16')
# plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/f2/KGDdropsCondi_t(rotation, t15r9).pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.show()




'''-------------------------- TSVD --------------------------------------'''
# condis_ori = f2_h3k_rotation['KI_condi'][9] # original condition number
# print(condis_ori)
# nus_TSVD = f2_h3k_rotation['t15r9_nus_TSVD']
# condisdrop_TSVD = f2_h3k_rotation['t15r9_condisdrop_TSVD']
# # print(condisdrop_TSVD)
# # print(nus_TSVD)
#
# fig = plt.figure(tight_layout=True)
# gs = gridspec.GridSpec(1, 1)
# ax = fig.add_subplot(gs[0, 0])
# ax.grid(linestyle='-.', axis="y")
#
# plt.axhline(condis_ori,ls="--",c="forestgreen",  linestyle='--', linewidth=1.8)
# ax.plot(nus_TSVD, condisdrop_TSVD, c='royalblue', marker='o',  linestyle='--', linewidth=1.2, markersize=4)
#
# ax.set_xlabel('$\\nu$', fontsize='20')
# ax.set_ylabel('Condition number', fontsize='20')
# plt.yscale('log')
# # plt.title('Spectral Cut-off', fontsize='12')
# plt.legend(['original CN','CN under Cut-off'], loc='upper right', fontsize='16')
# plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/f2/TSVDdropsCondi_t(t15r9).pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.show()
#














