import os, time
from Spectral_algorithms import XYZ_from_matfile, fun_rotation_mat, generate_data, Predicted_KI, Predicted_KRR, \
    Predicted_KGD, Predicted_TSVD, KRR_condi_lambda, KGD_condi_step, TSVD_condi_nu, parameter_lambda_krr_forplot, \
    parameter_step_kgd_forplot, parameter_lambda_TSVD_forplot, parameter_lambda_krr, \
    parameter_lambda_TSVD, RMSE_parameter_tsvd, TSVD_condi_nu_usecondi, parameter_lambda_TSVD_forrotation
import pandas as pd
from numpy import *
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib import rcParams
import matplotlib.gridspec as gridspec
from matplotlib.ticker import FuncFormatter
time_start = time.time()
config = {
    "font.family":'Times New Roman',
    "font.size": 16,
    "mathtext.fontset":'stix',
}
rcParams.update(config)


loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/f2_h3k_rotation.npy', allow_pickle=True)
f2_h3k_rotation = loadData.tolist()
print(f2_h3k_rotation.keys())


# KI KI_rmse_noi5_5trails
KI_rmse_noi5_120 = np.mean(f2_h3k_rotation['KI_rmse_noi5_5trails'], axis=1)[0]
KI_rmse_noi5_1200 = np.mean(f2_h3k_rotation['KI_rmse_noi5_5trails'], axis=1)[9]
KI_rmse_noi5_2400 = np.mean(f2_h3k_rotation['KI_rmse_noi5_5trails'], axis=1)[19]
# KI_rmse_noi5_120 = f2_h3k_rotation['KI_rmse_noi5'][0]
# KI_rmse_noi5_1200 = f2_h3k_rotation['KI_rmse_noi5'][9]
# KI_rmse_noi5_2400 = f2_h3k_rotation['KI_rmse_noi5'][19]

# KRR
KRR_rmse_noi5_mean_120 = np.mean(f2_h3k_rotation['KRR_rmse_noi5_5trails'], axis=1)[0]
KRR_rmse_noi5_mean_1200 = np.mean(f2_h3k_rotation['KRR_rmse_noi5_5trails'], axis=1)[9]
KRR_rmse_noi5_mean_2400 = np.mean(f2_h3k_rotation['KRR_rmse_noi5_5trails'], axis=1)[19]


# KGD
KGD_rmse_noi5_mean_120 = np.mean(f2_h3k_rotation['KGD_rmse_noi5_5trails'], axis=1)[0]
KGD_rmse_noi5_mean_1200 = np.mean(f2_h3k_rotation['KGD_rmse_noi5_5trails'], axis=1)[9]
KGD_rmse_noi5_mean_2400 = np.mean(f2_h3k_rotation['KGD_rmse_noi5_5trails'], axis=1)[19]


# TSVD
TSVD_rmse_noi5_mean_120 = np.mean(f2_h3k_rotation['TSVD_rmse_noi5_5trails'], axis=1)[0]
TSVD_rmse_noi5_mean_1200 = np.mean(f2_h3k_rotation['TSVD_rmse_noi5_5trails'], axis=1)[9]
TSVD_rmse_noi5_mean_2400 = np.mean(f2_h3k_rotation['TSVD_rmse_noi5_5trails'], axis=1)[19]


fig = plt.figure(tight_layout=True)
colors_KI = ['darkgray', 'darkgray', 'darkgray']
colors_KRR = ['tan', 'tan', 'tan']
colors_KGD = ['rosybrown', 'rosybrown', 'rosybrown']
colors_TSVD = ['brown', 'brown', 'brown']

data_KI = [KI_rmse_noi5_120, KI_rmse_noi5_1200, KI_rmse_noi5_2400]
data_KRR = [KRR_rmse_noi5_mean_120, KRR_rmse_noi5_mean_1200, KRR_rmse_noi5_mean_2400]
data_KGD =[KGD_rmse_noi5_mean_120, KGD_rmse_noi5_mean_1200, KGD_rmse_noi5_mean_2400]
data_TSVD =[TSVD_rmse_noi5_mean_120, TSVD_rmse_noi5_mean_1200, TSVD_rmse_noi5_mean_2400]

bar_width = 0.45
x_range = np.arange(0,6,2)
rects0= plt.bar(x_range, data_KI, align='center', alpha=0.7, color=colors_KI, label='KI', width=0.45)
rects1= plt.bar(x_range + bar_width, data_KRR, align='center', alpha=0.7, color=colors_KRR, label='Tikhonov', width=0.45)
rects2= plt.bar(x_range+ 2*bar_width, data_KGD, align='center', alpha=0.7, color=colors_KGD, label='Landweber', width=0.45)
rects3= plt.bar(x_range+ 3*bar_width, data_TSVD, align='center', alpha=0.7, color=colors_TSVD, label='Cut-off', width=0.45)

for a,b in zip(x_range,data_KI):
    plt.text(a,b,'%.2f'%b,ha='center',va='bottom',fontsize=13)
for a1,b1 in zip(x_range+ bar_width,data_KRR):
    plt.text(a1,b1,'%.2f'%b1,ha='center',va='bottom',fontsize=13)
for a2,b2 in zip(x_range + 2*bar_width,data_KGD):
    plt.text(a2,b2,'%.2f'%b2,ha='center',va='bottom',fontsize=13)
for a3,b3 in zip(x_range + 3*bar_width,data_TSVD):
    plt.text(a3,b3,'%.2f'%b3,ha='center',va='bottom',fontsize=13)


plt.ylabel('RMSE($\\sigma=0.5$)', fontsize='17')
subjects = ('|D|=100', '|D|=1200', '|D|=2400')
plt.xticks(x_range+ 1.5*bar_width, subjects)
plt.legend(loc='upper left')
plt.yscale('log')
# plt.title('Comparison of different approaches', fontsize='13')
plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/f2/Compare_histogram_rmse.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
plt.show()



