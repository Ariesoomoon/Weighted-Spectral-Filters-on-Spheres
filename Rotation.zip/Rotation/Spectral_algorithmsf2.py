import pandas as pd
from numpy import *
import numpy as np
import math
from sklearn.model_selection import KFold
import os, time
time_start = time.time()
print('rrr')

'''0. 加载数据，检查是否有缺失值'''
data = pd.read_csv('ss047.csv', header=None)
data.columns = ['x1', 'x2', 'x3']
# print('检查数据是否有缺失值 ------------------------------------------------------------\n', data.isnull().sum())
# print('\n输出前5个数据 -----------------------------------------------------------------\n', data.head())
# data.info()
data_arr = np.array(data)  # x1, x2, x3 = data_arr[:, 0], data_arr[:, 1], data_arr[:, 1]
# print(data_arr)


'''1. 生成数据'''
# 第一个函数
def create_y_g1(X_tra):
    x1, x2, x3 = X_tra[:, 0], X_tra[:, 1], X_tra[:, 2]
    y = 0.75 * np.exp(-(9*x1-2)**2/4 - (9*x2-2)**2/4 - (9*x3-2)**2/4) + \
        0.75 * np.exp(-(9*x1+1)**2/49 - (9*x2+1)/10 - (9*x3+1)/10) + \
        0.5 * np.exp(-(9*x1-7)**2/4 - (9*x2-3)**2/4 - (9*x3-5)**2/4) - \
        0.2 * np.exp(-(9*x1-4)**2 - (9*x2-7)**2 - (9*x3-5)**2)
    return y


# 第二个函数
Z_tra = np.array([[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]])

def function_fai(x):
    if 1-x >= 0:
        result = (1 - x) ** 8 * (((32 * x + 25) * x + 8) * x + 1)
    else:
        result = 0.0
    return result


def create_y_g2(XYZ_tra, Z_tra):
    n, t = len(XYZ_tra), len(Z_tra)              # t= 6
    Z_tra_1 = np.reshape(Z_tra, (t, 1, 3))       # (6, 1, 3)
    Z_tra_1 = np.repeat(Z_tra_1, n, axis=1)      # (6, n, 3)
    XYZ_tra_1 = np.reshape(XYZ_tra, (1, n, 3))   # (1, n, 3)
    XYZ_tra_1 = np.repeat(XYZ_tra_1, t, axis=0)  # (6, n, 3)

    dis = XYZ_tra_1 - Z_tra_1

    dis_norm = np.linalg.norm(dis, axis=2)
    function_fai_vector = np.vectorize(function_fai)
    fai_xz = function_fai_vector(dis_norm)  # (6,n)
    sum_fai_xz = np.sum(fai_xz, axis=0)       # (n,)
    return sum_fai_xz


def sample(XYZ_train, test_size, func): # func is a string
    XYZ_tes = np.random.uniform(-1.0, 1.0, test_size)
    XYZ_tes = XYZ_tes / np.linalg.norm(XYZ_tes, axis=1, keepdims=True)
    noise = np.random.normal(0, 0.1, len(XYZ_train))
    print(noise)
    if func == 'f1':
        y_train = create_y_g1(XYZ_train) + noise
        y_test = create_y_g1(XYZ_tes)
    else:
        y_train = create_y_g2(XYZ_train, Z_tra) + noise
        y_test = create_y_g2(XYZ_tes, Z_tra)
    return XYZ_train.shape, y_train.shape, XYZ_train, y_train, XYZ_tes.shape, y_test.shape, XYZ_tes, y_test


def generate_data(XYZ_train, test_size, func):
    sample_data = sample(XYZ_train, test_size, func)
    X_train, y_train, X_test, y_test = sample_data[2], sample_data[3], sample_data[6], sample_data[7]
    print('------------------------------From  %s ------------------------------------------' % func)
    print('Train set X:%s, y:%s  |  Test set X:%s, y:%s' % (sample_data[0], sample_data[1], sample_data[4], sample_data[5]))
    return X_train, y_train, X_test, y_test

# np.random.seed(0)
# XYZ_train = data_arr
# test_size = (100, 3)
# func = 'f2'
# a = generate_data(XYZ_train, test_size, func)
# print(a)


'''2. 由训练数据生成核矩阵'''
# d=1 用的核函数
def kernel_d1(x,y):
    n,t = len(x), len(y)
    mat_1 = np.ones((t,n))
    y_1 = np.reshape(y, (t, 1), order='A')  # (t, 1)
    y_1 = np.repeat(y_1, n, axis=1)         # (t, n)
    x_1 = np.reshape(x, (1, n), order='A')  # (1, n)
    x_1 = np.repeat(x_1, t, axis=0)         # (t, n)
    kermatrix = np.minimum(x_1, y_1) + mat_1
    return kermatrix


# d=3 用的核函数 （1）
def function_h3(x):
    if x >= 0 and x <= 1:
        result = (1 - x) ** 4 * (4*x+1)  # 0.0
    else:
        result = 0.0                     # result = 0 时 kernel_d3(X_train, X_test)中的元素都是0
    return result


def kernel_d3(x,y):
    n, t = len(x), len(y)
    y_1 = np.reshape(y, (t, 1, 3))
    y_1 = np.repeat(y_1, n, axis=1)  # (t,n,3)
    x_1 = np.reshape(x, (1, n, 3))
    x_1 = np.repeat(x_1, t, axis=0)  # (t,n,3)
    dis = x_1 - y_1
    dis_norm = np.linalg.norm(dis, axis=2)   # (t,n)
    # 核函数（1）：h3
    function_h3_vector = np.vectorize(function_h3)
    kermatrix = function_h3_vector(dis_norm)
    # 核函数（2）：fai
    # function_fai_vector = np.vectorize(function_fai)
    # kermatrix = function_fai_vector(dis_norm)
    return kermatrix


def calculate_0(x):
    x[x<=0] = 0
    x[x>0] = 1
    num_fei0= np.sum(x)
    num = x.shape[0] * x.shape[1]
    return num_fei0, num

# b = calculate_0(aa)
# print('核矩阵中的非零元素个数:%s, 总元素个数：%s' % (b[0], b[1]))


# 计算核矩阵原始的条件数
def cv_condition(x, y, f):
    kf = KFold(n_splits=f, shuffle=True)
    condition_ns = []
    for train_index, test_index in kf.split(x):
        x_train, x_test = x[train_index], x[test_index]
        y_train, y_test = y[train_index], y[test_index]
        # print(x_test[0:3])
        ker = kernel_d3(x_train,x_train)
        U, S, V = np.linalg.svd(ker)
        condition_n = np.max(S) / np.min(S)
        condition_ns.append(condition_n)
    return sum(condition_ns)/f


'''测试------------'''
# d = 3
# func = 'f1'
# f = 5
# XYZ_train = data_arr
# test_size = (100, 3)
# np.random.seed(1)
# a = generate_data(XYZ_train, test_size, func)
# X_train, y_train, X_test, y_test = a
# # # # lambda_krr = 0.0001
# # # # step_kgd = 2
# b = cv_condition(X_train, y_train, f)
# print(b)  #2.812414523823635e+17


# for i in range(50):
#     regular_para = 0.5*i
#     cc = Predicted(X_train, y_train, X_test, y_test, d, regular_para)
#     print(cc[1])



'''3. 计算系数alpha：'''
'''（1）KRR '''
def Alpha_KRR(X_tra, y_tra, d, lambda_krr):  # d=3, x_train = 1000, runing time: 7.139469146728516
    n = len(X_tra)
    ker = kernel_d1(X_tra, X_tra) if d == 1 else kernel_d3(X_tra, X_tra)
    U, S, V = np.linalg.svd(ker)
    S_lambda = S + n * lambda_krr
    condition_n = np.max(S_lambda) / np.min(S_lambda)

    S_lambda = 1 / S_lambda  # (n, )
    S_lambda = np.reshape(S_lambda, (1, n), order='A') # (1, n)
    S_lambda = np.repeat(S_lambda, n, axis=0) # (n, n)
    US = np.multiply(U, S_lambda)  # 点乘 n^2计算量
    ker_inverse = np.dot(US, V)    # 叉乘 n^3计算量
    alpha = np.dot(ker_inverse, np.reshape(y_tra, (len(y_tra), 1)))
    return alpha, condition_n


def Alpha_KRR_nolambda(X_tra, y_tra, d):  # d=3, x_train = 1000, runing time: 7.139469146728516
    n = len(X_tra)
    ker = kernel_d1(X_tra, X_tra) if d == 1 else kernel_d3(X_tra, X_tra)
    U, S, V = np.linalg.svd(ker)
    condition_n = np.max(S) / np.min(S)

    S = 1 / S  # (n, )
    S = np.reshape(S, (1, n), order='A') # (1, n)
    S = np.repeat(S, n, axis=0) # (n, n)
    US = np.multiply(U, S)  # 点乘 n^2计算量
    ker_inverse = np.dot(US, V)    # 叉乘 n^3计算量
    alpha = np.dot(ker_inverse, np.reshape(y_tra, (len(y_tra), 1)))
    return alpha, condition_n



'''（2）Iterative landweber -- KGD '''
def Alpha_KGD(X_tra, y_tra, d, step_kgd):
    step_size = 1  # as in Spectral paper
    n = len(X_tra)
    y_tra = np.reshape(y_tra, (n, 1))
    alpha = np.reshape(np.zeros(n), (n, 1))  # alpha= np.empty(shape=n)  # 不是空的，是随机数值
    ker = kernel_d1(X_tra, X_tra) if d == 1 else kernel_d3(X_tra, X_tra)
    for i in range(step_kgd):
        alpha = alpha + (step_size/n) * (y_tra - np.dot(ker, alpha))
    return alpha


def matrixPow(Matrix,n):
    Matrix = np.mat(Matrix)
    if(n==1):
        return Matrix
    else:
        return np.matmul(Matrix,matrixPow(Matrix,n-1))


def KGD_neumann_condi(X_tra, step_kgd):
    n = len(X_tra)
    mat_I = np.identity(n)
    if step_kgd == 1:
        ker_neum = mat_I
    else:
        ker = kernel_d3(X_tra, X_tra)
        ker_neum = mat_I
        for i in range(1, step_kgd):
            ker_neum = ker_neum + matrixPow(mat_I - ker,i)  # 这里计算量很大，先只跑mse！！

    U, S, V = np.linalg.svd(ker_neum)
    condition_n = np.max(S) / np.min(S)
    return condition_n


'''（3）Semi-Iterative regularization '''
def Alpha_SemiIter(X_tra, y_tra, d, step_semi):
    v = 5  # v-method
    n = len(X_tra)
    y_tra = np.reshape(y_tra, (n, 1))
    alpha_i1, alpha_i2 = np.reshape(np.zeros(n), (n, 1)), np.reshape(np.zeros(n), (n, 1))
    ker = kernel_d1(X_tra, X_tra) if d == 1 else kernel_d3(X_tra, X_tra)
    for i in range(step_semi):
        u = ((i - 1) * (2 * i - 3) * (2 * i + 2 * v - 1)) / ((i + 2 * v - 1) * (2 * i + 4 * v - 1) * (2 * i + 2 * v - 3))
        w = 4 * ((2 * i + 2 * v - 1) * (i + v - 1)) / ((i + 2 * v - 1) * (2 * i + 4 * v - 1))
        alpha = alpha_i1 + u*(alpha_i1 - alpha_i2) + (w/n) * (y_tra - np.dot(ker, alpha_i1))
        alpha_i2 = alpha_i1
        alpha_i1 = alpha
    return alpha


'''（4）Spectral cut-off '''
def Alpha_SpecCut(X_tra, y_tra, d, lambda_cut):
    n = len(X_tra)
    ker = kernel_d1(X_tra, X_tra) if d == 1 else kernel_d3(X_tra, X_tra)
    U, S, V = np.linalg.svd(ker)   # V=U^T
    S= np.where(S >= lambda_cut, 1 / S, 0)
    condition_n = max(filter(lambda x: x > 0, S)) / S[0]

    S = np.reshape(S, (1, n), order='A')  # (1, n)
    S = np.repeat(S, n, axis=0)  # (n, n)
    US = np.multiply(U, S)         # 点乘 n^2计算量
    ker_inverse = np.dot(US, V)           # 叉乘 n^3计算量
    alpha = np.dot(ker_inverse, np.reshape(y_tra, (len(y_tra), 1)))
    return alpha, condition_n  # (n, 1)



'''（5.1）Iterated Tikhonov -- lambda '''
def Alpha_IterTik(X_tra, y_tra, d, lambda_tik):
    nu = 2

    n = len(X_tra)
    y_tra = np.reshape(y_tra, (n, 1))
    alpha_i1 = np.reshape(np.zeros(n), (n, 1))
    ker = kernel_d1(X_tra, X_tra) if d == 1 else kernel_d3(X_tra, X_tra)
    U, S, V = np.linalg.svd(ker)
    for i in range(nu):
        S_lambda = 1 / (S + n * lambda_tik)  # (n, )
        S_lambda = np.reshape(S_lambda, (1, n), order='A')  # (1, n)
        S_lambda = np.repeat(S_lambda, n, axis=0)  # (n, n)

        US = np.multiply(U, S_lambda)  # 点乘 n^2计算量
        ker_inverse = np.dot(US, V)    # 叉乘 n^3计算量(内积)
        alpha = np.dot(ker_inverse, (y_tra + n * lambda_tik * alpha_i1))
        alpha_i1 = alpha
    return alpha


'''（5.2）Iterated Tikhonov -- step(nu) '''
def Alpha_IterTik_nu(X_tra, y_tra, d, step_nu):
    lambda_tik = 0.002

    n = len(X_tra)
    y_tra = np.reshape(y_tra, (n, 1))
    alpha_i1 = np.reshape(np.zeros(n), (n, 1))
    ker = kernel_d1(X_tra, X_tra) if d == 1 else kernel_d3(X_tra, X_tra)
    U, S, V = np.linalg.svd(ker)
    for i in range(step_nu):
        S_lambda = 1 / (S + n * lambda_tik)  # (n, )
        S_lambda = np.reshape(S_lambda, (1, n), order='A')  # (1, n)
        S_lambda = np.repeat(S_lambda, n, axis=0)  # (n, n)

        US = np.multiply(U, S_lambda)  # 点乘 n^2计算量
        ker_inverse = np.dot(US, V)    # 叉乘 n^3计算量
        alpha = np.dot(ker_inverse, (y_tra + n * lambda_tik * alpha_i1))
        alpha_i1 = alpha
    return alpha


'''(5.3) 计算Iterated Tikhonov的条件数'''
def spectral_IterTik_lambda(X_tra, lambda1):
    nu1 = 5
    ker = kernel_d3(X_tra, X_tra)
    U, S, V = np.linalg.svd(ker)
    sigma1, sigman = np.max(S), np.min(S)

    gn = ((sigman + lambda1) ** nu1 - lambda1 ** nu1) / (sigman * (sigman + lambda1) ** nu1)
    g1 = ((sigma1 + lambda1) ** nu1 - lambda1 ** nu1) / (sigma1 * (sigma1 + lambda1) ** nu1)
    condition_n = gn / g1
    return condition_n


def spectral_IterTik_nu(X_tra, nu1):
    lambda1 = 0.04  # f1
    #lambda1 = 0.005  # f2
    ker = kernel_d3(X_tra, X_tra)
    U, S, V = np.linalg.svd(ker)
    sigma1, sigman = np.max(S), np.min(S)

    gn = ((sigman + lambda1) ** nu1 - lambda1 ** nu1) / (sigman * (sigman + lambda1) ** nu1)
    g1 = ((sigma1 + lambda1) ** nu1 - lambda1 ** nu1) / (sigma1 * (sigma1 + lambda1) ** nu1)
    condition_n = gn / g1
    return condition_n


'''4. 计算MSE'''
def Predicted(x_tra, y_tra, x_tes, y_tes, d, regular_para):
    n, t = len(x_tra), len(x_tes)
    pred_alpha = Alpha_IterTik(x_tra, y_tra, d, regular_para)
    if d == 1:
        pred_ker = kernel_d1(x_tra, x_tes)
        y_fit = np.dot(pred_ker, pred_alpha)
        y_fit = np.squeeze(y_fit)
    else:
        pred_ker = kernel_d3(x_tra, x_tes)
        y_fit = np.dot(pred_ker, pred_alpha)
        y_fit = np.squeeze(y_fit)

    average_error = np.sum((y_fit - y_tes) ** 2) / t
    return y_fit, average_error


def Predictedkgd(x_tra, y_tra, x_tes, y_tes, d, regular_para):
    n, t = len(x_tra), len(x_tes)
    pred_alpha = Alpha_KGD(x_tra, y_tra, d, regular_para)
    if d == 1:
        pred_ker = kernel_d1(x_tra, x_tes)
        y_fit = np.dot(pred_ker, pred_alpha)
        y_fit = np.squeeze(y_fit)

    else:
        pred_ker = kernel_d3(x_tra, x_tes)
        y_fit = np.dot(pred_ker, pred_alpha)
        y_fit = np.squeeze(y_fit)

    average_error = np.sum((y_fit - y_tes) ** 2) / t
    return y_fit, average_error


def Predictedsemi(x_tra, y_tra, x_tes, y_tes, d, regular_para):
    n, t = len(x_tra), len(x_tes)
    pred_alpha = Alpha_SemiIter(x_tra, y_tra, d, regular_para)
    if d == 1:
        pred_ker = kernel_d1(x_tra, x_tes)
        y_fit = np.dot(pred_ker, pred_alpha)
        y_fit = np.squeeze(y_fit)

    else:
        pred_ker = kernel_d3(x_tra, x_tes)
        y_fit = np.dot(pred_ker, pred_alpha)
        y_fit = np.squeeze(y_fit)

    average_error = np.sum((y_fit - y_tes) ** 2) / t
    return y_fit, average_error


def Predictednu(x_tra, y_tra, x_tes, y_tes, d, regular_para):
    n, t = len(x_tra), len(x_tes)
    pred_alpha = Alpha_IterTik_nu(x_tra, y_tra, d, regular_para)
    if d == 1:
        pred_ker = kernel_d1(x_tra, x_tes)
        y_fit = np.dot(pred_ker, pred_alpha)
        y_fit = np.squeeze(y_fit)
    else:
        pred_ker = kernel_d3(x_tra, x_tes)
        y_fit = np.dot(pred_ker, pred_alpha)
        y_fit = np.squeeze(y_fit)

    average_error = np.sum((y_fit - y_tes) ** 2) / t
    return y_fit, average_error   # , pred_condition(kgd没有)
    #return y_fit, average_error, pred_condition


def Predictedtsvd(x_tra, y_tra, x_tes, y_tes, d, regular_para):
    n, t = len(x_tra), len(x_tes)
    pred = Alpha_SpecCut(x_tra, y_tra, d, regular_para)
    pred_alpha, pred_condition = pred[0], pred[1]  # (n, 1)
    if d == 1:
        pred_ker = kernel_d1(x_tra, x_tes)
        y_fit = np.dot(pred_ker, pred_alpha)
        y_fit = np.squeeze(y_fit)
    else:
        pred_ker = kernel_d3(x_tra, x_tes)
        y_fit = np.dot(pred_ker, pred_alpha)
        y_fit = np.squeeze(y_fit)

    average_error = np.sum((y_fit - y_tes) ** 2) / t
    return y_fit, average_error, pred_condition


'''5. 训练正则参数 '''
'''(1) KRR -- lambda_krr'''
def cv_lambda_krr(x, y, f, d, lambda_krr):
    kf = KFold(n_splits=f, shuffle=True)
    # kf = KFold(n_splits=f)
    error, condition_n = [], []
    for train_index, test_index in kf.split(x):
        x_train, x_test = x[train_index], x[test_index]
        y_train, y_test = y[train_index], y[test_index]
        result = Predictedkrr(x_train, y_train, x_test, y_test, d, lambda_krr)
        error.append(result[1])
        condition_n.append(result[2])
    return sum(error)/f, sum(condition_n)/f


def parameter_lambda_krr(x_tra, y_tra, f, d):
    cv_errors, lambda_opts = [], []
    for i in range(1, 16):  # d=1
        lambda_i = 0.001 +0.0002*i
        print('lambda_i:', lambda_i)
        cv_error = cv_lambda_krr(x_tra, y_tra, f, d, lambda_i)
        cv_errors.append(cv_error)
        lambda_opts.append(lambda_i)

    index = cv_errors.index(min(cv_errors))
    lambda_opt = lambda_opts[index]
    return lambda_opt


def parameter_lambda_krr_forplot(x_tra, y_tra, f, d):
    errors, condition_ns, lambda_opts = [], [], []
    for i in range(20):
        # lambda_i = 0.0 + 0.0001 * i
        lambda_i = 0.0000005 + 0.0001 * i
        print('lambda_i:', lambda_i)
        cv = cv_lambda_krr(x_tra, y_tra, f, d, lambda_i)
        errors.append(cv[0])
        condition_ns.append(cv[1])
        lambda_opts.append(lambda_i)
        print(cv[0])
    return errors, lambda_opts, condition_ns


'''(2) KGD -- step_kgd'''
def cv_step_kgd(x, y, f, d, step_kgd):
    kf = KFold(n_splits=f, shuffle=True)
    error, condition_n = [], []
    for train_index, test_index in kf.split(x):
        x_train, x_test = x[train_index], x[test_index]
        y_train, y_test = y[train_index], y[test_index]
        result = Predictedkgd(x_train, y_train, x_test, y_test, d, step_kgd)[1]
        error.append(result)
        condition_n1 = KGD_neumann_condi(x_train, step_kgd)
        condition_n.append(condition_n1)
    # return sum(error)/f
    return sum(error)/f, sum(condition_n)/f


def parameter_step_kgd(x_tra, y_tra, f, d, step_sta, step_end):
    cv_errors, step_opts = [], []
    for step in range(step_sta, step_end):
        print('step:', step)
        cv_error = cv_step_kgd(x_tra, y_tra, f, d, step)
        cv_error, step_opt1 = cv_error, step
        cv_errors.append(cv_error)
        step_opts.append(step_opt1)

    index = cv_errors.index(min(cv_errors))
    step_opt = step_opts[index]
    return step_opt


def parameter_step_kgd_forplot(x_tra, y_tra, f, d, step_sta, step_end):
    errors, condition_ns, step_opts = [], [], []
    # for i in range(20):  # f1
    #     step = 15 + 40 * i
    for i in range(20):    # f2
        step = 100 + 400 * i
        print('step:', step)
        cv = cv_step_kgd(x_tra, y_tra, f, d, step)
        # errors.append(cv)
        errors.append(cv[0])
        condition_ns.append(cv[1])

        step_opts.append(step)
        print(cv)
    # return errors, step_opts
    return errors, step_opts, condition_ns


'''(3) Semi-Iterative regulation -- step_semi'''
def cv_step_semi(x, y, f, d, step_semi):
    kf = KFold(n_splits=f, shuffle=True)
    error = []
    for train_index, test_index in kf.split(x):
        x_train, x_test = x[train_index], x[test_index]
        y_train, y_test = y[train_index], y[test_index]
        error_validation = Predictedsemi(x_train, y_train, x_test, y_test, d, step_semi)[1]
        error.append(error_validation)
    return sum(error)/f


def parameter_step_semi(x_tra, y_tra, f, d, step_sta, step_end):
    cv_errors, step_opts = [], []
    for step in range(step_sta, step_end):
        print('step:', step)
        cv_error = cv_step_semi(x_tra, y_tra, f, d, step)
        cv_error, step_opt1 = cv_error, step
        cv_errors.append(cv_error)
        step_opts.append(step_opt1)

    index = cv_errors.index(min(cv_errors))
    step_opt = step_opts[index]
    return step_opt


def parameter_step_semi_forplot(x_tra, y_tra, f, d):
    cv_errors, step_opts = [], []
    # for step in range(step_sta, step_end):
    #     print('step:', step)
    # for i in range(20):    # f1
    #     step = 10+10 * i
    for i in range(20):  # f2
        step = 30 + 15 * i
        print('step:', step)
        cv_error = cv_step_semi(x_tra, y_tra, f, d, step)
        cv_error, step_opt1 = cv_error, step
        cv_errors.append(cv_error)
        step_opts.append(step_opt1)
        print(cv_error)
    return cv_errors, step_opts


'''(4) Spectral cut-off -- lambda_cut'''
def cv_lambda_SpecCut(x, y, f, d, lambda_cut):
    kf = KFold(n_splits=f, shuffle=True)
    #kf = KFold(n_splits=f)
    error, condition_n = [], []
    for train_index, test_index in kf.split(x):
        x_train, x_test = x[train_index], x[test_index]
        y_train, y_test = y[train_index], y[test_index]
        result = Predictedtsvd(x_train, y_train, x_test, y_test, d, lambda_cut)
        error.append(result[1])
        condition_n.append(result[2])
    return sum(error)/f, sum(condition_n)/f


def parameter_lambda_SpecCut(x_tra, y_tra, f, d):
    cv_errors, lambda_opts = [], []
    for i in range(51):
        lambda_i = 1 + 0.01 * i  # (1, 1.25)
        print('lambda_i:', lambda_i)
        cv_error = cv_lambda_SpecCut(x_tra, y_tra, f, d, lambda_i)
        cv_errors.append(cv_error)
        lambda_opts.append(lambda_i)

    index = cv_errors.index(min(cv_errors))
    lambda_opt = lambda_opts[index]
    return lambda_opt


def parameter_lambda_SpecCut_forplot(x_tra, y_tra, f, d):
    errors, condition_ns, lambda_opts = [], [], []
    # for i in range(20):    # f1
    #     lambda_i = 0.005 + 1 * i
    # for i in range(20):  # f2
    #     lambda_i = 0.0005 + 0.1 * i

    for i in range(2):  # f2
        lambda_i = 0.001*10**i
        print(lambda_i)

    # for i in range(20):  # f2
    #     lambda_i = 0.02 + 0.1 * i

        print('lambda_i:', lambda_i)
        cv = cv_lambda_SpecCut(x_tra, y_tra, f, d, lambda_i)
        errors.append(cv[0])
        condition_ns.append(cv[1])
        lambda_opts.append(lambda_i)
        print(cv)
    return errors, lambda_opts, condition_ns


'''(5.1) Iterated Tikhonov -- lambda_tik'''
def cv_lambda_IterTik(x, y, f, d, lambda_tik):
    kf = KFold(n_splits=f, shuffle=True)
    error = []
    for train_index, test_index in kf.split(x):
        x_train, x_test = x[train_index], x[test_index]
        y_train, y_test = y[train_index], y[test_index]
        error_validation = Predicted(x_train, y_train, x_test, y_test, d, lambda_tik)[1]
        error.append(error_validation)
    return sum(error)/f


def parameter_lambda_IterTik(x_tra, y_tra, f, d):
    cv_errors, lambda_opts = [], []
    for i in range(16):
        lambda_i = 0.015 + 0.001 * i  # (1, 1.25)
        print('lambda_i:', lambda_i)
        cv_error = cv_lambda_IterTik(x_tra, y_tra, f, d, lambda_i)
        cv_errors.append(cv_error)
        lambda_opts.append(lambda_i)

    index = cv_errors.index(min(cv_errors))
    lambda_opt = lambda_opts[index]
    return lambda_opt


def parameter_lambda_IterTik_forplot(x_tra, y_tra, f, d):
    cv_errors, lambda_opts = [], []
    # for i in range(20):    # f1
    #     lambda_i = 0.00005 + 0.01 * i
    for i in range(20):  # f2
        lambda_i = 0.00005 + 0.001 * i

        print('lambda_i:', lambda_i)
        cv_error = cv_lambda_IterTik(x_tra, y_tra, f, d, lambda_i)
        print(cv_error)
        cv_errors.append(cv_error)
        lambda_opts.append(lambda_i)
    return cv_errors, lambda_opts


'''(5.2) Iterated Tikhonov -- nu'''
def cv_nu_IterTik(x, y, f, d, step_nu):
    kf = KFold(n_splits=f, shuffle=True)
    error = []
    for train_index, test_index in kf.split(x):
        x_train, x_test = x[train_index], x[test_index]
        y_train, y_test = y[train_index], y[test_index]
        error_validation = Predictednu(x_train, y_train, x_test, y_test, d, step_nu)[1]
        error.append(error_validation)
    return sum(error)/f


def parameter_nu_IterTik(x_tra, y_tra, f, d, step_sta, step_end):
    cv_errors, step_opts = [], []
    for i in range(16): # d3:10-40
        step = 10 + 2*i
        print('step:', step)
        cv_error = cv_nu_IterTik(x_tra, y_tra, f, d, step)
        cv_errors.append(cv_error)
        step_opts.append(step)

    index = cv_errors.index(min(cv_errors))
    step_opt = step_opts[index]
    return step_opt


def parameter_nu_IterTik_forplot(x_tra, y_tra, f, d):
    cv_errors, step_opts = [], []
    # for i in range(20): # f1
    #     step = 1 + 4*i
    # for i in range(20):   # f2
    #     step = 15+15*i
    for i in range(20):   # f2
        step = 1+2*i
        print('step:', step)
        cv_error = cv_nu_IterTik(x_tra, y_tra, f, d, step)
        cv_errors.append(cv_error)
        step_opts.append(step)
        print(cv_error)
    return cv_errors, step_opts


# 计算KRR算法下的条件数的变化
def Predictedkrr(x_tra, y_tra, x_tes, y_tes, d, regular_para):
    n, t = len(x_tra), len(x_tes)

    pred = Alpha_KRR(x_tra, y_tra, d, regular_para)
    # pred = Alpha_KRR_nolambda(x_tra, y_tra, d)  # if only kernel interpolation

    pred_alpha, pred_condition = pred[0], pred[1]  # (n, 1)
    if d == 1:
        pred_ker = kernel_d1(x_tra, x_tes)
        y_fit = np.dot(pred_ker, pred_alpha)
        y_fit = np.squeeze(y_fit)

    else:
        pred_ker = kernel_d3(x_tra, x_tes)
        y_fit = np.dot(pred_ker, pred_alpha)
        y_fit = np.squeeze(y_fit)

    average_error = np.sum((y_fit - y_tes) ** 2) / t
    return y_fit, average_error, pred_condition


def cv_lambda_krr_condi(x, y, f, d, lambda_krr):
    kf = KFold(n_splits=f, shuffle=True)
    # kf = KFold(n_splits=f)
    error, condition_n = [], []
    for train_index, test_index in kf.split(x):
        x_train, x_test = x[train_index], x[test_index]
        y_train, y_test = y[train_index], y[test_index]
        result = Predictedkrr(x_train, y_train, x_test, y_test, d, lambda_krr)
        error.append(result[1])
        condition_n.append(result[2])
    return sum(error)/f, sum(condition_n)/f


def parameter_lambda_krr_condi_forplot(x_tra, y_tra, f, d):
    errors, condition_ns, lambda_opts = [], [], []
    for i in range(20):  # f1
        lambda_i = 0+0.0005*i
    # for i in range(20):  # f2
    #     lambda_i = 0.0000005 + 0.00005 * i
        print('lambda_i:', lambda_i)
        cv = cv_lambda_krr_condi(x_tra, y_tra, f, d, lambda_i)
        errors.append(cv[0])
        condition_ns.append(cv[1])
        lambda_opts.append(lambda_i)
        print(cv[0])
        print(cv[1])
    return errors, lambda_opts, condition_ns


# 计算kgd算法下的条件数的变化
def cv_step_kgd_condi(x, y, f, d, step_kgd):
    kf = KFold(n_splits=f, shuffle=True)
    condition_n = []
    for train_index, test_index in kf.split(x):
        x_train, x_test = x[train_index], x[test_index]
        y_train, y_test = y[train_index], y[test_index]
        condition_n1 = KGD_neumann_condi(x_train, step_kgd)
        condition_n.append(condition_n1)
    return sum(condition_n)/f


def parameter_step_kgd_condi_forplot(x_tra, y_tra, f, d):
    condition_ns, step_opts = [], []
    for i in range(15):  # f1
        step = 1 + 2 * i
    # for i in range(20):    # f2
    #     step = 400 + 500 * i
        print('step:', step)
        cv = cv_step_kgd_condi(x_tra, y_tra, f, d, step)
        condition_ns.append(cv)
        step_opts.append(step)
        print(cv)
    return step_opts, condition_ns


# 计算TSVD算法下的条件数的变化
def cv_lambda_SpecCut_condi(x, y, f, d, lambda_cut):
    kf = KFold(n_splits=f, shuffle=True)
    #kf = KFold(n_splits=f)
    error, condition_n = [], []
    for train_index, test_index in kf.split(x):
        x_train, x_test = x[train_index], x[test_index]
        y_train, y_test = y[train_index], y[test_index]
        result = Predictedtsvd(x_train, y_train, x_test, y_test, d, lambda_cut)
        error.append(result[1])
        condition_n.append(result[2])
    return sum(error)/f, sum(condition_n)/f


def parameter_lambda_SpecCut_condi_forplot(x_tra, y_tra, f, d):
    errors, condition_ns, lambda_opts = [], [], []
    for i in range(20):  # f1
        lambda_i = 0+0.0005*i
    # for i in range(20):  # f2
    #     lambda_i = 0.0005 + 0.1 * i
        print('lambda_i:', lambda_i)
        cv = cv_lambda_SpecCut_condi(x_tra, y_tra, f, d, lambda_i)
        errors.append(cv[0])
        condition_ns.append(cv[1])
        lambda_opts.append(lambda_i)
        print(cv[1])
    return errors, lambda_opts, condition_ns


# 计算Iterated Tikhonov算法下的条件数的变化
# lambda是参数
def cv_lambda_tik_condi(x, y, f, d, lambda1):
    kf = KFold(n_splits=f, shuffle=True)
    condition_n = []
    for train_index, test_index in kf.split(x):
        x_train, x_test = x[train_index], x[test_index]
        y_train, y_test = y[train_index], y[test_index]
        condition_n1 = spectral_IterTik_lambda(x_train, lambda1)
        condition_n.append(condition_n1)
    return sum(condition_n)/f


def parameter_lambda_tik_condi_forplot(x_tra, y_tra, f, d):
    condition_ns, lambda_opts = [], []
    for i in range(20):  # f1
        lambda1 = 0 + 0.0005 * i
    # for i in range(20):    # f2
    #     step = 400 + 500 * i
        print('lambda1:', lambda1)
        cv = cv_lambda_tik_condi(x_tra, y_tra, f, d, lambda1)
        condition_ns.append(cv)
        lambda_opts.append(lambda1)
        print(cv)
    return lambda_opts, condition_ns


# nu是参数
def cv_nu_tik_condi(x, y, f, d, nu1):
    kf = KFold(n_splits=f, shuffle=True)
    condition_n = []
    for train_index, test_index in kf.split(x):
        x_train, x_test = x[train_index], x[test_index]
        y_train, y_test = y[train_index], y[test_index]
        condition_n1 = spectral_IterTik_nu(x_train, nu1)
        condition_n.append(condition_n1)
    return sum(condition_n)/f


def parameter_nu_tik_condi_forplot(x_tra, y_tra, f, d):
    condition_ns, step_opts = [], []
    for i in range(15):   # f1
        nu1 = 1 + 2 * i
        print('nu1:', nu1)
        cv = cv_nu_tik_condi(x_tra, y_tra, f, d, nu1)
        condition_ns.append(cv)
        step_opts.append(nu1)
        print(cv)
    return step_opts, condition_ns

