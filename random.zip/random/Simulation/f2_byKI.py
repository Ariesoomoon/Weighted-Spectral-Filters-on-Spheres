import os, time
from Spectral_algorithms import XYZ_from_matfile, fun_rotation_mat, generate_data, Predicted_KI, Predicted_KRR, \
    Predicted_KGD, Predicted_TSVD, KRR_condi_lambda, KGD_condi_step, TSVD_condi_nu, parameter_lambda_krr_forplot, \
    parameter_step_kgd_forplot, parameter_lambda_TSVD_forplot, parameter_lambda_krr
import pandas as pd
from numpy import *
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib import rcParams
import matplotlib.gridspec as gridspec
from matplotlib.ticker import FuncFormatter
time_start = time.time()
config = {
    "font.family":'Times New Roman',
    "font.size": 20,
#     "mathtext.fontset":'stix',
}
rcParams.update(config)

# f2_h3k_random = {} # function name: f2, kernel name:h3k, data increasing way: t (of t-design) increases
# np.save('/Users/liuxiaotong/Documents/machine learning/4_Spectral approach on spheres/random/Result_data/f2_h3k_random.npy', f2_h3k_random)
# print('save f2_h3k_random.npy done')

loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/f2_h3k_random.npy', allow_pickle=True)
f2_h3k_random = loadData.tolist()
print(f2_h3k_random.keys())



'''0. set up'''
func = 'f2'  # from paper "DIVIDE AND CONQUER LEAST SQAURES FOR UNCERTAINTY OF KERNEL INTERPOLATION ON SPHERES"
f, d = 5, 3  # folds of corss-validation; dimension of the input X
test_size = (100, 3)
trails = 5


''' 1. caculate RMSE one trail '''
# np.random.seed(1)
# noise_sd = 0.5
# data_sizes, rmses, condis = [], [], []
# trail = 0
# for i in range(20):
#     np.random.seed(1)  # 这个是fig3.1，说明krr的labmda可以下降条件数专用的，之前的tdesign和rotation不用，是因为他们的样本都是准备好的，而这里是for逐渐生成的，每一个for，即使seed=1，生成的数据也不一样
#     train_size = (100*(i+1), 3)
#     data_sizes.append(train_size[0])
#     X_train, y_train, X_test, y_test = generate_data(train_size, test_size, func, noise_sd, trail)  # generate the (len(XYZ_train), d) training data set and (100, 3) testing data set
#     Pred = Predicted_KI(X_train, y_train, X_test, y_test, d)
#     rmse, condi = Pred[1], Pred[2]
#     rmses.append(rmse)
#     condis.append(condi)
#     print('rmses:', rmses)
#     print('condis:', condis)
#     print('data_sizes:', data_sizes)
#
# # noise_sd = 0.0
# # f2_h3k_random['KI_rmse_noi0'] = rmses
# # f2_h3k_random['KI_sizes'] = data_sizes
# # f2_h3k_random['KI_condi'] = condis
#
# # # noise_sd = 0.1
# # f2_h3k_random['KI_rmse_noi1'] = rmses
# #
# # # noise_sd = 0.3
# # f2_h3k_random['KI_rmse_noi3'] = rmses
# #
# # # noise_sd = 0.5
# f2_h3k_random['KI_rmse_noi5'] = rmses
#
# np.save(os.path.dirname(os.getcwd()) + '/Result_data/f2_h3k_random.npy', f2_h3k_random)
# print('save f2_h3k_random.npy done')
# print(f2_h3k_random.keys())
# time_total = time.time() - time_start
# print('runing time:', time_total)


''' 2.1 Plot RMSE and N'''
sizes = f2_h3k_random['KI_sizes']
condis = f2_h3k_random['KI_condi']
KI_rmse_noi0 = f2_h3k_random['KI_rmse_noi0']
KI_rmse_noi1 = f2_h3k_random['KI_rmse_noi1']
KI_rmse_noi3 = f2_h3k_random['KI_rmse_noi3']
KI_rmse_noi5 = f2_h3k_random['KI_rmse_noi5']
print(KI_rmse_noi1)
print(sizes)

fig = plt.figure(tight_layout=True)
gs = gridspec.GridSpec(1, 1)
ax = fig.add_subplot(gs[0, 0])
ax.grid(linestyle='-.', axis="y")

ax.plot(sizes, KI_rmse_noi1, c='darkorange', marker='d',  linestyle='--', linewidth=1.2, markersize=5)
ax.plot(sizes, KI_rmse_noi3, c='forestgreen', marker='s', markersize=4,  linestyle='--', linewidth=1.2)
ax.plot(sizes, KI_rmse_noi5, c='royalblue', marker='o',  linestyle='--', linewidth=1.2, markersize=4)
ax.set_xlabel('$|D|$', fontsize='20')
ax.set_ylabel('RMSE', fontsize='20')
plt.yscale('log')
plt.ylim(0.05, 3)
# plt.title('Kernel Interpolation', fontsize='12')
plt.legend(['$\\sigma$=0.1',
            '$\\sigma$=0.3',
            '$\\sigma$=0.5'], ncol=3, loc='upper center', fontsize=16)

plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/f2/KI_RMSE_N(random2000).pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
plt.show()



# ''' 2.2 Plot Condition number and N'''
# ax.plot(sizes, condis, c='royalblue', linestyle='-', linewidth=1.2) # condi=[1.0, 1.612599660652674, 9.749194001868375, 37.36974223496753, 112.17342650455599, 321.44248868690715, 671.5413553669802, 1398.157423632555, 2541.42629482062, 4215.898770110927, 7070.0432188056175, 10974.549734760414, 16801.509325642714, 25116.383505739737, 34138.36746585262, 47170.15263652693]
# ax.set_xlabel('The number of training samples', fontsize='14')
# ax.set_ylabel('Condition number', fontsize='13')
# plt.yscale('log')
# # plt.ylim(0.9, 100000)  # you can't set the minimum y-value to 0 on a log scale since log(0) is not defined
# # plt.title('Kernel Interpolation', fontsize='12')
# plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/f2/KI_Condi_N(random2000).pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.show()



'''3. RMSE for 5 trails, 5-cv '''
# noise_sd = 0.1 # 0.1, 0.3, 0.5
# rmses_ki_t5 = np.empty(shape=(20, 5))
#
# for trail in range(trails):
#     np.random.seed(1)
#     time_start = time.time()
#     rmses_ki = []
#     print('------------------------------------------------ trail:', trail + 1)
#     for i in range(20):
#         train_size = (100 * (i + 1), 3)
#         X_train, y_train, X_test, y_test = generate_data(train_size, test_size, func, noise_sd, trail)
#         print('------------------------------------------------ random:', train_size)
#
#         Pred = Predicted_KI(X_train, y_train, X_test, y_test, d)[1]
#         rmses_ki.append(Pred)
#
#     rmses_ki_ar = np.array(rmses_ki)
#     rmses_ki_t5[:, trail] = np.squeeze(rmses_ki_ar)
#     time_total = time.time() - time_start
#     print('runing time for 1 trail:', time_total) # runing time for 1 trail: 1467.094449043274, 24min
#
# # f2_h3k_random['KI_rmse_noi5_5trails'] = rmses_ki_t5
# # f2_h3k_random['KI_rmse_noi3_5trails'] = rmses_ki_t5
# f2_h3k_random['KI_rmse_noi1_5trails'] = rmses_ki_t5
# np.save(os.path.dirname(os.getcwd()) + '/Result_data/f2_h3k_random.npy', f2_h3k_random)
# print('save f2_h3k_random.npy done')
# print(f2_h3k_random.keys())
# time_total = time.time() - time_start
# print('runing time:', time_total)








