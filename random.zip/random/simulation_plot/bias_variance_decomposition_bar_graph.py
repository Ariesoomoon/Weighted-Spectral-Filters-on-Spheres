import os, time
from Spectral_algorithms import XYZ_from_matfile, fun_rotation_mat, generate_data, Predicted_KI, Predicted_KRR, \
    Predicted_KGD, Predicted_TSVD, KRR_condi_lambda, KGD_condi_step, TSVD_condi_nu, parameter_lambda_krr_forplot, \
    parameter_step_kgd_forplot, parameter_lambda_TSVD_forplot, parameter_lambda_krr, RMSE_parameter_krr, RMSE_parameter_kgd, RMSE_parameter_tsvd
import pandas as pd
from numpy import *
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib import rcParams
import matplotlib.gridspec as gridspec
from matplotlib.ticker import FuncFormatter
time_start = time.time()
config = {
    "font.family":'Times New Roman',
    "font.size": 13,
#     "mathtext.fontset":'stix',
}
rcParams.update(config)


'''0. set up'''
func = 'f2'  # from paper "DIVIDE AND CONQUER LEAST SQAURES FOR UNCERTAINTY OF KERNEL INTERPOLATION ON SPHERES"
f, d = 5, 3  # folds of corss-validation; dimension of the input X
test_size = (100, 3)
trails = 5


loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/Bias_var_com.npy', allow_pickle=True)
Bias_var_com = loadData.tolist()
print(Bias_var_com.keys())

# KI
KI_noi5 = Bias_var_com['KI_rmse_noi5'][11]
KI_noi0_bias = Bias_var_com['KI_rmse_noi0'][11]
KI_noi5_variance = KI_noi5 - KI_noi0_bias

# KRR
KRR_noi5 = Bias_var_com['KRR_rmse_noi5_1trail']
KRR_noi5_min_index = KRR_noi5.index(min(KRR_noi5))
KRR_noi5_min = min(KRR_noi5)
KRR_noi0_bias = Bias_var_com['KRR_rmse_noi0_1trail'][KRR_noi5_min_index]
KRR_noi5_min_variance = KRR_noi5_min - KRR_noi0_bias
mus = Bias_var_com['KRR_mus_noi5_1trail']
mus_min = mus[KRR_noi5_min_index]
# print('KRR_noi5_min_index:', KRR_noi5_min_index)
# print('mus_min:', mus_min)
# KRR_noi5_min_index: 23
# mus_min: 0.0115

# KGD
KGD_noi5 = Bias_var_com['KGD_rmse_noi5_1trail']
KGD_noi5_min_index = KGD_noi5.index(min(KGD_noi5))
KGD_noi5_min = min(KGD_noi5)
KGD_noi0_bias = Bias_var_com['KGD_rmse_noi0_1trail'][KGD_noi5_min_index]
KGD_noi5_min_variance = KGD_noi5_min - KGD_noi0_bias
ts = Bias_var_com['KGD_ts_noi5_1trail']
ts_min = ts[KGD_noi5_min_index]
# print('KGD_noi5_min_index:', KGD_noi5_min_index)
# print('ts_min:', ts_min)
# KGD_noi5_min_index: 8
# ts_min: 2050

# TSVD
TSVD_noi5 = Bias_var_com['TSVD_rmse_noi5_1trail']
TSVD_noi5_min_index = TSVD_noi5.index(min(TSVD_noi5))
TSVD_noi5_min = min(TSVD_noi5)
TSVD_noi0_bias = Bias_var_com['TSVD_rmse_noi0_1trail'][TSVD_noi5_min_index]
TSVD_noi5_min_variance = TSVD_noi5_min - TSVD_noi0_bias
nus = Bias_var_com['TSVD_nus_noi5_1trail']
nus_min = nus[TSVD_noi5_min_index]
# print('TSVD_noi5_min_index:', TSVD_noi5_min_index)
# print('nus_min:', nus_min)
# TSVD_noi5_min_index: 53
# nus_min: 13.25

fig = plt.figure(tight_layout=True)
colors_bias = ['grey', 'grey', 'grey', 'grey']
colors_variance = ['lightsteelblue', 'lightsteelblue', 'lightsteelblue', 'lightsteelblue']
colors_gene_error = ['royalblue', 'royalblue', 'royalblue', 'royalblue']
data_bias = [KI_noi0_bias, KRR_noi0_bias, KGD_noi0_bias, TSVD_noi0_bias]
data_variance = [KI_noi5_variance, KRR_noi5_min_variance, KGD_noi5_min_variance, TSVD_noi5_min_variance]
data_gene_error =[KI_noi5, KRR_noi5_min, KGD_noi5_min, TSVD_noi5_min]

bar_width = 0.45
x_range = np.arange(0,8,2)
rects0= plt.bar(x_range, data_bias, align='center', alpha=0.7, color=colors_bias, label='Fitting part', width=0.45)
rects1= plt.bar(x_range + bar_width, data_variance, align='center', alpha=0.7, color=colors_variance, label='Stability part', width=0.45)
rects2= plt.bar(x_range+ 2*bar_width, data_gene_error, align='center', alpha=0.7, color=colors_gene_error, label='Approximation error', width=0.45)

for a,b in zip(x_range,data_bias):
    plt.text(a,b,'%.3f'%b,ha='center',va='bottom',fontsize=8)
for a1,b1 in zip(x_range+ bar_width,data_variance):
    plt.text(a1,b1,'%.3f'%b1,ha='center',va='bottom',fontsize=8)
for a2,b2 in zip(x_range + 2*bar_width,data_gene_error):
    plt.text(a2,b2,'%.3f'%b2,ha='center',va='bottom',fontsize=8)

# plt.ylabel('RMSE', fontsize='13')
subjects = ('KI', 'Tikhonov\n($\\mu=0.0115$)', 'Landweber\n($t=2050$)', 'Cut-off\n($\\nu=13.25$)')
plt.xticks(x_range+ bar_width, subjects)
plt.legend(loc='upper right')
plt.yscale('log')
plt.ylim(-0.00001, 12)
# plt.title('Comparison of different approaches', fontsize='13')
# plt.title('Comparison of different approaches \n($|D|=1130$, $\\sigma=0.5$)')
plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/f2/Compare_histogram.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
plt.show()




'''3. Histogram: bias and variance of KI when noise=0.0, 0.001, 0.01, 0.1, 0.3, 0.5'''
loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/f2_h3k_tdesign.npy', allow_pickle=True)
f2_h3k_tdesign = loadData.tolist()
print(f2_h3k_tdesign.keys())

# bias
KI_rmse_noi0 = f2_h3k_tdesign['KI_rmse_noi0'][11] # t=47, n=1130
print(KI_rmse_noi0) # 1.4448688615407509e-05
KI_rmse_noi0_var = 0
KI_rmse_noi1 = f2_h3k_tdesign['KI_rmse_noi1'][11]
KI_rmse_noi1_var = KI_rmse_noi1 - KI_rmse_noi0
KI_rmse_noi3 = f2_h3k_tdesign['KI_rmse_noi3'][11]
KI_rmse_noi3_var = KI_rmse_noi3 - KI_rmse_noi0
KI_rmse_noi5 = f2_h3k_tdesign['KI_rmse_noi5'][11]
KI_rmse_noi5_var = KI_rmse_noi5 - KI_rmse_noi0
fig = plt.figure(tight_layout=True)
colors_bias = ['grey', 'grey', 'grey', 'grey']
colors_variance = ['lightsteelblue', 'lightsteelblue', 'lightsteelblue', 'lightsteelblue']
colors_gene_error = ['royalblue', 'royalblue', 'royalblue', 'royalblue']
data_bias = [KI_rmse_noi0, KI_rmse_noi0, KI_rmse_noi0, KI_rmse_noi0]
data_variance = [0, KI_rmse_noi1_var, KI_rmse_noi3_var, KI_rmse_noi5_var]
data_gene_error =[KI_rmse_noi0, KI_rmse_noi1, KI_rmse_noi3, KI_rmse_noi5]

bar_width = 0.45
x_range = np.arange(0,8,2)
# rects0= plt.bar(x_range, data_bias, align='center', alpha=0.7, color=colors_bias, label='Bias$_{\\sigma=0.0}$', width=0.45)
rects0= plt.bar(x_range, data_bias, align='center', alpha=0.7, color=colors_bias, label='Bias', width=0.45)
rects1= plt.bar(x_range + bar_width, data_variance, align='center', alpha=0.7, color=colors_variance, label='Regularization error minus Bias', width=0.45)
rects2= plt.bar(x_range+ 2*bar_width, data_gene_error, align='center', alpha=0.7, color=colors_gene_error, label='Regularization error', width=0.45)

for a,b in zip(x_range,data_bias):
    plt.text(a,b,'%.3f'%b,ha='center',va='bottom',fontsize=10)
for a1,b1 in zip(x_range+ bar_width,data_variance):
    plt.text(a1,b1,'%.3f'%b1,ha='center',va='bottom',fontsize=10)
for a2,b2 in zip(x_range + 2*bar_width,data_gene_error):
    plt.text(a2,b2,'%.3f'%b2,ha='center',va='bottom',fontsize=10)


subjects = ('$\\sigma=0.0$', '$\\sigma=0.1$', '$\\sigma=0.3$', '$\\sigma=0.5$')
plt.xticks(x_range+ bar_width, subjects)
plt.legend(loc='upper left')
# plt.yscale('log')
# plt.ylim(-0.00001, 12)
# plt.title('Kernel Intepolation', fontsize='13')
# plt.title('Comparison of different approaches \n($|D|=1130$, $\\sigma=0.5$)')
plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/f2/Compare_histogram_KI.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
plt.show()

