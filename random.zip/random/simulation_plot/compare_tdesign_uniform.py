import os, time
from Spectral_algorithms import XYZ_from_matfile, fun_rotation_mat, generate_data, Predicted_KI, Predicted_KRR, \
    Predicted_KGD, Predicted_TSVD, KRR_condi_lambda, KGD_condi_step, TSVD_condi_nu, parameter_lambda_krr_forplot, \
    parameter_step_kgd_forplot, parameter_lambda_TSVD_forplot, parameter_lambda_krr, RMSE_parameter_krr, RMSE_parameter_kgd, RMSE_parameter_tsvd
import pandas as pd
from numpy import *
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib import rcParams
import matplotlib.gridspec as gridspec
from matplotlib.ticker import FuncFormatter
time_start = time.time()
config = {
    "font.family":'Times New Roman',
    "font.size": 16,
    "mathtext.fontset":'stix',
}
rcParams.update(config)



loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/f2_h3k_random.npy', allow_pickle=True)
f2_h3k_random = loadData.tolist()
print(f2_h3k_random.keys())

loadData1 = np.load(os.path.dirname(os.getcwd()) + '/Result_data/f2_h3k_tdesign.npy', allow_pickle=True)
f2_h3k_tdesign = loadData1.tolist()
print(f2_h3k_tdesign.keys())


fig = plt.figure(tight_layout=True)
colors_uniform = ['tan', 'tan']
colors_tdesign = ['brown', 'brown']

data_uniform_noi05_1200 = [np.mean(f2_h3k_random['KI_rmse_noi5_5trails'], axis=1)[11],
                           np.mean(f2_h3k_random['KRR_rmse_noi5_5trails'], axis=1)[11],
                           np.mean(f2_h3k_random['KGD_rmse_noi5_5trails'], axis=1)[11],
                           np.mean(f2_h3k_random['TSVD_rmse_noi5_5trails'], axis=1)[11]]

data_tdesign_noi05_1130 = [np.mean(f2_h3k_tdesign['KI_rmse_noi5_5trails'], axis=1)[11],
                           np.mean(f2_h3k_tdesign['KRR_rmse_noi5_5trails'], axis=1)[11],
                           np.mean(f2_h3k_tdesign['KGD_rmse_noi5_5trails'], axis=1)[11],
                           np.mean(f2_h3k_tdesign['TSVD_rmse_noi5_5trails'], axis=1)[11]]


bar_width = 0.85
x_range = np.arange(0,8,2)
rects0= plt.bar(x_range, data_uniform_noi05_1200, align='center', alpha=0.7, color=colors_uniform, label='uniform (|D|=1200)', width=0.85)
rects1= plt.bar(x_range + bar_width, data_tdesign_noi05_1130, align='center', alpha=0.7, color=colors_tdesign, label='$t$-design (|D|=1130, $t$=47)', width=0.85)

for a,b in zip(x_range,data_uniform_noi05_1200):
    plt.text(a,b,'%.3f'%b,ha='center',va='bottom',fontsize=13)
for a1,b1 in zip(x_range+ bar_width,data_tdesign_noi05_1130):
    plt.text(a1,b1,'%.3f'%b1,ha='center',va='bottom',fontsize=13)

plt.ylabel('RMSE($\sigma$=0.5)', fontsize='17')
# plt.xlabel('|D| = 2016, $\sigma = 50$', fontsize='13')
subjects = ('KI', 'Tikhonov', 'Landweber', 'Cut-off')
plt.xticks(x_range+ 0.5*bar_width, subjects)
plt.legend(loc='upper right')
plt.yscale('log')
# plt.ylim(100, 200)
# plt.title('Comparison of different approaches', fontsize='13')
plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/f2/Compare_sampling_method.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
plt.show()


















