import os, time
from Spectral_algorithms import XYZ_from_matfile, fun_rotation_mat, generate_data, Predicted_KI, Predicted_KRR, \
    Predicted_KGD, Predicted_TSVD, KRR_condi_lambda, KGD_condi_step, TSVD_condi_nu, parameter_lambda_krr_forplot, \
    parameter_step_kgd_forplot, parameter_lambda_TSVD_forplot, parameter_lambda_krr, RMSE_parameter_krr, RMSE_parameter_kgd, RMSE_parameter_tsvd
import pandas as pd
from numpy import *
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib import rcParams
import matplotlib.gridspec as gridspec
from matplotlib.ticker import FuncFormatter
time_start = time.time()
config = {
    "font.family":'Times New Roman',
    "font.size": 16,
    "mathtext.fontset":'stix',
}
rcParams.update(config)


'''0. set up'''
func = 'f2'  # from paper "DIVIDE AND CONQUER LEAST SQAURES FOR UNCERTAINTY OF KERNEL INTERPOLATION ON SPHERES"
f, d = 5, 3  # folds of corss-validation; dimension of the input X
test_size = (100, 3)
trails = 5


''''Histogram: 比较KI的5trail平均，KRR， KGD 和 TSVD的5-cv，5trail平均，选取几个N，做成柱状图,100， 1000， 2000
'''
loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/f2_h3k_random.npy', allow_pickle=True)
f2_h3k_random = loadData.tolist()
print(f2_h3k_random.keys())



'''------------------------- 转移数据 ---------------------------------------'''
# loadData1 = np.load(os.path.dirname(os.getcwd()) + '/Result_data/f2_h3k_random_KGD.npy', allow_pickle=True)
# f2_h3k_random_KGD = loadData1.tolist()
# print(f2_h3k_random_KGD.keys())
#
# loadData2 = np.load(os.path.dirname(os.getcwd()) + '/Result_data/f2_h3k_random_tsvd5.npy', allow_pickle=True)
# f2_h3k_random_tsvd5 = loadData2.tolist()
# print(f2_h3k_random_tsvd5.keys())
#
# f2_h3k_random['KGD_rmse_noi5_5trails'] = f2_h3k_random_KGD['KGD_rmse_noi5_5trails']
# # f2_h3k_random['KGD_rmse_noi3_5trails'] = f2_h3k_random_KGD['KGD_rmse_noi3_5trails']
# # f2_h3k_random['KGD_rmse_noi1_5trails'] = f2_h3k_random_KGD['KGD_rmse_noi1_5trails']
# #
# f2_h3k_random['TSVD_rmse_noi5_5trails'] = f2_h3k_random_tsvd5['TSVD_rmse_noi5_5trails']
# f2_h3k_random['TSVD_rmse_noi3_5trails'] = f2_h3k_random_tsvd5['TSVD_rmse_noi3_5trails']
# f2_h3k_random['TSVD_rmse_noi1_5trails'] = f2_h3k_random_tsvd5['TSVD_rmse_noi1_5trails']
#
# np.save(os.path.dirname(os.getcwd()) + '/Result_data/f2_h3k_random.npy', f2_h3k_random)
# print('save f2_h3k_random.npy done')
# print(f2_h3k_random.keys())



'''------------------------- 画图 ---------------------------------------'''
# KI
KI_rmse_noi5_100 = np.mean(f2_h3k_random['KI_rmse_noi5_5trails'], axis=1)[0]  
KI_rmse_noi5_1000 = np.mean(f2_h3k_random['KI_rmse_noi5_5trails'], axis=1)[9] 
KI_rmse_noi5_2000 = np.mean(f2_h3k_random['KI_rmse_noi5_5trails'], axis=1)[19]  

# KRR
KRR_rmse_noi5_mean_100 = np.mean(f2_h3k_random['KRR_rmse_noi5_5trails'], axis=1)[0]
KRR_rmse_noi5_mean_1000 = np.mean(f2_h3k_random['KRR_rmse_noi5_5trails'], axis=1)[9]
KRR_rmse_noi5_mean_2000 = np.mean(f2_h3k_random['KRR_rmse_noi5_5trails'], axis=1)[19]

# KGD
KGD_rmse_noi5_mean_100 = np.mean(f2_h3k_random['KGD_rmse_noi5_5trails'], axis=1)[0]
KGD_rmse_noi5_mean_1000 = np.mean(f2_h3k_random['KGD_rmse_noi5_5trails'], axis=1)[9]
KGD_rmse_noi5_mean_2000 = np.mean(f2_h3k_random['KGD_rmse_noi5_5trails'], axis=1)[19]

# TSVD
TSVD_rmse_noi5_mean_100 = np.mean(f2_h3k_random['TSVD_rmse_noi5_5trails'], axis=1)[0]
TSVD_rmse_noi5_mean_1000 = np.mean(f2_h3k_random['TSVD_rmse_noi5_5trails'], axis=1)[9]
TSVD_rmse_noi5_mean_2000 = np.mean(f2_h3k_random['TSVD_rmse_noi5_5trails'], axis=1)[19]

fig = plt.figure(tight_layout=True)
colors_KI = ['darkgray', 'darkgray', 'darkgray']
colors_KRR = ['tan', 'tan', 'tan']
colors_KGD = ['rosybrown', 'rosybrown', 'rosybrown']
colors_TSVD = ['brown', 'brown', 'brown']

data_KI = [KI_rmse_noi5_100, KI_rmse_noi5_1000, KI_rmse_noi5_2000]
data_KRR = [KRR_rmse_noi5_mean_100, KRR_rmse_noi5_mean_1000, KRR_rmse_noi5_mean_2000]
data_KGD =[KGD_rmse_noi5_mean_100, KGD_rmse_noi5_mean_1000, KGD_rmse_noi5_mean_2000]
data_TSVD =[TSVD_rmse_noi5_mean_100, TSVD_rmse_noi5_mean_1000, TSVD_rmse_noi5_mean_2000]

bar_width = 0.46
x_range = np.arange(0,6,2)
rects0= plt.bar(x_range, data_KI, align='center', alpha=0.7, color=colors_KI, label='KI', width=0.46)
rects1= plt.bar(x_range + bar_width, data_KRR, align='center', alpha=0.7, color=colors_KRR, label='Tikhonov', width=0.46)
rects2= plt.bar(x_range+ 2*bar_width, data_KGD, align='center', alpha=0.7, color=colors_KGD, label='Landweber', width=0.46)
rects3= plt.bar(x_range+ 3*bar_width, data_TSVD, align='center', alpha=0.7, color=colors_TSVD, label='Cut-off', width=0.46)

for a,b in zip(x_range,data_KI):
    plt.text(a,b,'%.2f'%b,ha='center',va='bottom',fontsize=13)
for a1,b1 in zip(x_range+ bar_width,data_KRR):
    plt.text(a1,b1,'%.2f'%b1,ha='center',va='bottom',fontsize=13)
for a2,b2 in zip(x_range + 2*bar_width,data_KGD):
    plt.text(a2,b2,'%.2f'%b2,ha='center',va='bottom',fontsize=13)
for a3,b3 in zip(x_range + 3*bar_width,data_TSVD):
    plt.text(a3,b3,'%.2f'%b3,ha='center',va='bottom',fontsize=13)


plt.ylabel('RMSE($\\sigma=0.5$)', fontsize='17')
subjects = ('|D|=100', '|D|=1000', '|D|=2000')
plt.xticks(x_range+ 1.5*bar_width, subjects)
plt.legend(loc='upper right')
plt.yscale('log')
plt.ylim(0.06, 4)
# plt.title('Comparison of different approaches', fontsize='13')
plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/f2/Compare_histogram_rmse_random.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
plt.show()







