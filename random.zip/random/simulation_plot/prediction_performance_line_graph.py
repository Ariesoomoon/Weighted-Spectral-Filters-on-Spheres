import os, time
from Spectral_algorithms_fortsvd import XYZ_from_matfile, fun_rotation_mat, generate_data, Predicted_KI, Predicted_KRR, \
    Predicted_KGD, Predicted_TSVD, KRR_condi_lambda, KGD_condi_step, TSVD_condi_nu, parameter_lambda_krr_forplot, \
    parameter_step_kgd_forplot, parameter_lambda_TSVD_forplot, parameter_lambda_krr, parameter_lambda_TSVD, RMSE_parameter_tsvd, \
    parameter_lambda_TSVD_noi03, parameter_lambda_TSVD_noi01
import pandas as pd
from numpy import *
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib import rcParams
import matplotlib.gridspec as gridspec
from matplotlib.ticker import FuncFormatter
time_start = time.time()
config = {
    "font.family":'Times New Roman',
    "font.size": 20,
    "mathtext.fontset":'stix',
}
rcParams.update(config)


loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/f2_h3k_random.npy', allow_pickle=True)
f2_h3k_random = loadData.tolist()
print(f2_h3k_random.keys())


'''-------------------------- KI --------------------------------------'''
sizes = f2_h3k_random['KI_sizes']
condis = f2_h3k_random['KI_condi']
KI_rmse_noi0 = f2_h3k_random['KI_rmse_noi0']
KI_rmse_noi1 = f2_h3k_random['KI_rmse_noi1']
KI_rmse_noi3 = f2_h3k_random['KI_rmse_noi3']
KI_rmse_noi5 = f2_h3k_random['KI_rmse_noi5']
print(KI_rmse_noi1)
print(sizes)

fig = plt.figure(tight_layout=True)
gs = gridspec.GridSpec(1, 1)
ax = fig.add_subplot(gs[0, 0])
ax.grid(linestyle='-.', axis="y")

ax.plot(sizes, KI_rmse_noi1, c='darkorange', marker='d',  linestyle='--', linewidth=1.2, markersize=5)
ax.plot(sizes, KI_rmse_noi3, c='forestgreen', marker='s', markersize=4,  linestyle='--', linewidth=1.2)
ax.plot(sizes, KI_rmse_noi5, c='royalblue', marker='o',  linestyle='--', linewidth=1.2, markersize=4)
ax.set_xlabel('$|D|$', fontsize='20')
ax.set_ylabel('RMSE', fontsize='20')
plt.yscale('log')
plt.ylim(0.05, 3)
# plt.title('Kernel Interpolation', fontsize='12')
plt.legend(['$\\sigma$=0.1',
            '$\\sigma$=0.3',
            '$\\sigma$=0.5'], ncol=3, loc='upper center', fontsize=16)

plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/f2/KI_RMSE_N(random2000).pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
plt.show()


#
# '''-------------------------- KRR --------------------------------------'''
# KRR_rmse_noi5_mean = np.mean(f2_h3k_random['KRR_rmse_noi5_5trails'], axis=1)
# KRR_rmse_noi3_mean = np.mean(f2_h3k_random['KRR_rmse_noi3_5trails'], axis=1)
# KRR_rmse_noi1_mean = np.mean(f2_h3k_random['KRR_rmse_noi1_5trails'], axis=1)
# sizes = f2_h3k_random['KI_sizes']
#
# fig = plt.figure(tight_layout=True)
# gs = gridspec.GridSpec(1, 1)
# ax = fig.add_subplot(gs[0, 0])
# ax.grid(linestyle='-.', axis="y")
#
# ax.plot(sizes, KRR_rmse_noi1_mean, c='darkorange', marker='d',  linestyle='--', linewidth=1.2, markersize=5)
# ax.plot(sizes, KRR_rmse_noi3_mean, c='forestgreen', marker='s', markersize=4,  linestyle='--', linewidth=1.2)
# ax.plot(sizes, KRR_rmse_noi5_mean, c='royalblue', marker='o',  linestyle='--', linewidth=1.2, markersize=4)
# ax.set_xlabel('$|D|$', fontsize='20')
# ax.set_ylabel('RMSE', fontsize='20')
# # plt.title('Tikhonov Regularization', fontsize='12')
# plt.yscale('log')
# plt.ylim(0.005, 0.9999)
# plt.legend(['$\\sigma$=0.1',
#             '$\\sigma$=0.3',
#             '$\\sigma$=0.5'], ncol=3, loc='upper center', fontsize=16)
#
# plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/f2/KRR_RMSE_N_(random).pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.show()
#
#
#
# '''-------------------------- KGD --------------------------------------'''
# KGD_rmse_noi5_mean = np.mean(f2_h3k_random['KGD_rmse_noi5_5trails'], axis=1)
# KGD_rmse_noi3_mean = np.mean(f2_h3k_random['KGD_rmse_noi3_5trails'], axis=1)
# KGD_rmse_noi1_mean = np.mean(f2_h3k_random['KGD_rmse_noi1_5trails'], axis=1)
# sizes = f2_h3k_random['KI_sizes']
# fig = plt.figure(tight_layout=True)
# gs = gridspec.GridSpec(1, 1)
# ax = fig.add_subplot(gs[0, 0])
# ax.grid(linestyle='-.', axis="y")
#
# ax.plot(sizes, KGD_rmse_noi1_mean, c='darkorange', marker='d',  linestyle='--', linewidth=1.2, markersize=5)
# ax.plot(sizes, KGD_rmse_noi3_mean, c='forestgreen', marker='s', markersize=4,  linestyle='--', linewidth=1.2)
# ax.plot(sizes, KGD_rmse_noi5_mean, c='royalblue', marker='o',  linestyle='--', linewidth=1.2, markersize=4)
# ax.set_xlabel('$|D|$', fontsize='20')
# ax.set_ylabel('RMSE', fontsize='20')
# # plt.title('Landweber Iteration', fontsize='13')
# plt.yscale('log')
# plt.ylim(0.009, 0.9)
#
# plt.legend(['$\\sigma$=0.1',
#             '$\\sigma$=0.3',
#             '$\\sigma$=0.5'], ncol=3, loc='upper center', fontsize=16)
#
# plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/f2/KGD_RMSE_N_(random).pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.show()
#
#
#
#
#
# '''-------------------------- TSVD --------------------------------------'''
# TSVD_rmse_noi5_mean = np.mean(f2_h3k_random['TSVD_rmse_noi5_5trails'], axis=1)
# TSVD_rmse_noi3_mean = np.mean(f2_h3k_random['TSVD_rmse_noi3_5trails'], axis=1)
# TSVD_rmse_noi1_mean = np.mean(f2_h3k_random['TSVD_rmse_noi1_5trails'], axis=1)
# sizes = f2_h3k_random['KI_sizes']
# print(TSVD_rmse_noi5_mean)
#
# fig = plt.figure(tight_layout=True)
# gs = gridspec.GridSpec(1, 1)
# ax = fig.add_subplot(gs[0, 0])
# ax.grid(linestyle='-.', axis="y")
#
# ax.plot(sizes, TSVD_rmse_noi1_mean, c='darkorange', marker='d',  linestyle='--', linewidth=1.2, markersize=5)
# ax.plot(sizes, TSVD_rmse_noi3_mean, c='forestgreen', marker='s', markersize=4,  linestyle='--', linewidth=1.2)
# ax.plot(sizes, TSVD_rmse_noi5_mean, c='royalblue', marker='o',  linestyle='--', linewidth=1.2, markersize=4)
# ax.set_xlabel('$|D|$', fontsize='20')
# ax.set_ylabel('RMSE', fontsize='20')
# # plt.title('Spectral Cut-off', fontsize='12')
# plt.yscale('log')
# plt.ylim(0.005, 0.9999)
# plt.legend(['$\\sigma$=0.1',
#             '$\\sigma$=0.3',
#             '$\\sigma$=0.5'], ncol=3, loc='upper center', fontsize=16)
#
# plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/f2/TSVD_RMSE_N_(random).pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.show()
#
#
