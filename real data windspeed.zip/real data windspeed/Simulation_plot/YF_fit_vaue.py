import os, time
from Spectral_algorithms_wind import XYZ_from_matfile, fun_rotation_mat, Predicted_KI, Predicted_KRR, \
    Predicted_KGD, Predicted_TSVD, KRR_condi_lambda, KGD_condi_step, TSVD_condi_nu, parameter_lambda_krr_forplot, \
    parameter_step_kgd_forplot, parameter_lambda_TSVD_forplot, parameter_lambda_krr
import pandas as pd
from numpy import *
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib import rcParams
import matplotlib.gridspec as gridspec
from matplotlib.ticker import FuncFormatter
time_start = time.time()
from sklearn.model_selection import train_test_split


loadData1 = np.load(os.path.dirname(os.getcwd()) + '/Result_data/wind2m.npy', allow_pickle=True)
wind2m = loadData1.tolist()
print(wind2m.keys())


# '''-------------------------- 5 trails 的fit values 平均  --------------------------------'''
# wind2m['KI_fit_2000_noi05_mean'] = np.mean(np.array(wind2m['KI_fit_2000_noi05']), axis=0)
# wind2m['TSVD_fit_2000_noi05_mean'] = np.mean(np.array(wind2m['TSVD_fit_2000_noi05']), axis=0)
#
# wind2m['KI_fit_2000_noi0_mean'] = np.mean(np.array(wind2m['KI_fit_2000_noi0']), axis=0)
# wind2m['TSVD_fit_2000_noi0_mean'] = np.mean(np.array(wind2m['TSVD_fit_2000_noi0']), axis=0)
#
# # wind2m['Ws_tes'] = wind2m['Ws_tes']
#
# print(wind2m['Ws_tes'].shape)
# print(wind2m['KI_fit_2000_noi05_mean'].shape)
# print(wind2m['KI_fit_2000_noi0_mean'].shape)
# print(wind2m['TSVD_fit_2000_noi05_mean'].shape)
# print(wind2m['TSVD_fit_2000_noi0_mean'].shape)
#
# np.save(os.path.dirname(os.getcwd()) + '/Result_data/wind2m.npy', wind2m)
# print('save wind2m.npy done')
# print(wind2m.keys())



# wind_fit_value = {}
# np.save('/Users/liuxiaotong/Documents/machine learning/4_Spectral approach on spheres/real data windspeed/Result_data/wind_fit_value.npy', wind_fit_value)
# print('save geo_fit_value.npy done')

loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/wind_fit_value.npy', allow_pickle=True)
wind_fit_value = loadData.tolist()
print(wind_fit_value.keys())

# wind_fit_value['TSVD_fit_2000_noi0_mean'] = wind2m['TSVD_fit_2000_noi0_mean']
# wind_fit_value['KI_fit_2000_noi0_mean'] = wind2m['KI_fit_2000_noi0_mean']
# wind_fit_value['KI_fit_2000_noi05_mean'] = wind2m['KI_fit_2000_noi05_mean']
# wind_fit_value['TSVD_fit_2000_noi05_mean'] = wind2m['TSVD_fit_2000_noi05_mean']
# wind_fit_value['Ws_tes'] = wind2m['Ws_tes']
wind_fit_value['Ws_tes'] = wind2m['Ws_tes']

np.save(os.path.dirname(os.getcwd()) + '/Result_data/wind_fit_value.npy', wind_fit_value)
print('save wind_fit_value.npy done')
print(wind_fit_value.keys())

print(wind_fit_value['Ws_tes'].shape)