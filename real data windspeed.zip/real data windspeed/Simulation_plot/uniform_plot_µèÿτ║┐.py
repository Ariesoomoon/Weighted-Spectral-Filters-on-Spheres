import os, time
from Spectral_algorithms_wind import XYZ_from_matfile, fun_rotation_mat, Predicted_KI, Predicted_KGD, \
    Predicted_KGD, Predicted_TSVD, KGD_condi_step, TSVD_condi_nu, parameter_lambda_krr_forplot, \
    parameter_step_kgd_forplot, parameter_lambda_TSVD_forplot, parameter_lambda_krr
import pandas as pd
from numpy import *
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib import rcParams
import matplotlib.gridspec as gridspec
from matplotlib.ticker import FuncFormatter
time_start = time.time()
from sklearn.model_selection import train_test_split
config = {
    "font.family":'Times New Roman',
    "font.size": 18,
    "mathtext.fontset":'stix',
}
rcParams.update(config)


loadData1 = np.load(os.path.dirname(os.getcwd()) + '/Result_data/wind2m.npy', allow_pickle=True)
wind2m = loadData1.tolist()
print(wind2m.keys())


'''----------------------------------- noise = 0.5-----------------------------'''
# KI_rmse_2000_noi05_mean = np.mean(wind2m['KI_rmse_2000_noi05'])
# KI_rmse_1600_noi05_mean = np.mean(wind2m['KI_rmse_1600_noi05'])
# KI_rmse_1200_noi05_mean = np.mean(wind2m['KI_rmse_1200_noi05'])
# KI_rmse_800_noi05_mean = np.mean(wind2m['KI_rmse_800_noi05'])
# KI_rmse_500_noi05_mean = np.mean(wind2m['KI_rmse_400_noi05'])
# KI_rmse_200_noi05_mean = np.mean(wind2m['KI_rmse_200_noi05'])
# KI_rmse_100_noi05_mean = np.mean(wind2m['KI_rmse_100_noi05'])
# KI_rmse_50_noi05_mean = np.mean(wind2m['KI_rmse_50_noi05'])
#
# TSVD_rmse_2000_noi05_mean = np.mean(wind2m['TSVD_rmse_2000_noi05'])
# TSVD_rmse_1600_noi05_mean = np.mean(wind2m['TSVD_rmse_1600_noi05'])
# TSVD_rmse_1200_noi05_mean = np.mean(wind2m['TSVD_rmse_1200_noi05'])
# TSVD_rmse_800_noi05_mean = np.mean(wind2m['TSVD_rmse_800_noi05'])
# TSVD_rmse_500_noi05_mean = np.mean(wind2m['TSVD_rmse_400_noi05'])
# TSVD_rmse_200_noi05_mean = np.mean(wind2m['TSVD_rmse_200_noi05'])
# TSVD_rmse_100_noi05_mean = np.mean(wind2m['TSVD_rmse_100_noi05'])
# TSVD_rmse_50_noi05_mean = np.mean(wind2m['TSVD_rmse_50_noi05'])
#
#
# wind2m['KI_rmse_mean_allsize_noi05'] = [KI_rmse_50_noi05_mean, KI_rmse_100_noi05_mean, KI_rmse_200_noi05_mean, KI_rmse_500_noi05_mean,
#                                         KI_rmse_800_noi05_mean, KI_rmse_1200_noi05_mean, KI_rmse_1600_noi05_mean, KI_rmse_2000_noi05_mean]
#
# wind2m['TSVD_rmse_mean_allsize_noi05'] = [TSVD_rmse_50_noi05_mean, TSVD_rmse_100_noi05_mean, TSVD_rmse_200_noi05_mean, TSVD_rmse_500_noi05_mean,
#                                         TSVD_rmse_800_noi05_mean, TSVD_rmse_1200_noi05_mean, TSVD_rmse_1600_noi05_mean, TSVD_rmse_2000_noi05_mean]


# np.save(os.path.dirname(os.getcwd()) + '/Result_data/wind2m.npy', wind2m)
# print('save wind2m.npy done')
# print(wind2m.keys())


'''----------------------------------- noise = 0.0-----------------------------'''
# KI_rmse_2000_noi0_mean = np.mean(wind2m['KI_rmse_2000_noi0'])
# KI_rmse_1600_noi0_mean = np.mean(wind2m['KI_rmse_1600_noi0'])
# KI_rmse_1200_noi0_mean = np.mean(wind2m['KI_rmse_1200_noi0'])
# KI_rmse_800_noi0_mean = np.mean(wind2m['KI_rmse_800_noi0'])
# KI_rmse_500_noi0_mean = np.mean(wind2m['KI_rmse_400_noi0'])
# KI_rmse_200_noi0_mean = np.mean(wind2m['KI_rmse_200_noi0'])
# KI_rmse_100_noi0_mean = np.mean(wind2m['KI_rmse_100_noi0'])
# KI_rmse_50_noi0_mean = np.mean(wind2m['KI_rmse_50_noi0'])
#
# TSVD_rmse_2000_noi0_mean = np.mean(wind2m['TSVD_rmse_2000_noi0'])
# TSVD_rmse_1600_noi0_mean = np.mean(wind2m['TSVD_rmse_1600_noi0'])
# TSVD_rmse_1200_noi0_mean = np.mean(wind2m['TSVD_rmse_1200_noi0'])
# TSVD_rmse_800_noi0_mean = np.mean(wind2m['TSVD_rmse_800_noi0'])
# TSVD_rmse_500_noi0_mean = np.mean(wind2m['TSVD_rmse_400_noi0'])
# TSVD_rmse_200_noi0_mean = np.mean(wind2m['TSVD_rmse_200_noi0'])
# TSVD_rmse_100_noi0_mean = np.mean(wind2m['TSVD_rmse_100_noi0'])
# TSVD_rmse_50_noi0_mean = np.mean(wind2m['TSVD_rmse_50_noi0'])
#
#
# wind2m['KI_rmse_mean_allsize_noi0'] = [KI_rmse_50_noi0_mean, KI_rmse_100_noi0_mean, KI_rmse_200_noi0_mean, KI_rmse_500_noi0_mean,
#                                         KI_rmse_800_noi0_mean, KI_rmse_1200_noi0_mean, KI_rmse_1600_noi0_mean, KI_rmse_2000_noi0_mean]
#
# wind2m['TSVD_rmse_mean_allsize_noi0'] = [TSVD_rmse_50_noi0_mean, TSVD_rmse_100_noi0_mean, TSVD_rmse_200_noi0_mean, TSVD_rmse_500_noi0_mean,
#                                         TSVD_rmse_800_noi0_mean, TSVD_rmse_1200_noi0_mean, TSVD_rmse_1600_noi0_mean, TSVD_rmse_2000_noi0_mean]
#
#
# np.save(os.path.dirname(os.getcwd()) + '/Result_data/wind2m.npy', wind2m)
# print('save wind2m.npy done')
# print(wind2m.keys())




# '''1.2. RMSE 为了画折线图---------------------------------------------------------------'''
# KI_rmse_mean_allsize_noi05 = wind2m['KI_rmse_mean_allsize_noi05']
# TSVD_rmse_mean_allsize_noi05 = wind2m['TSVD_rmse_mean_allsize_noi05']
# KI_rmse_mean_allsize_noi0 = wind2m['KI_rmse_mean_allsize_noi0']
# TSVD_rmse_mean_allsize_noi0 = wind2m['TSVD_rmse_mean_allsize_noi0']
# #
# print(KI_rmse_mean_allsize_noi05)
# print(TSVD_rmse_mean_allsize_noi05)
# print(KI_rmse_mean_allsize_noi0)
# print(TSVD_rmse_mean_allsize_noi0)
# data_size = wind2m['datasize']
# print(data_size)
#
# fig = plt.figure(tight_layout=True)
# gs = gridspec.GridSpec(1, 1)
# ax = fig.add_subplot(gs[0, 0])
# ax.grid(linestyle='-.', axis="y")
#
# ax.plot(data_size, KI_rmse_mean_allsize_noi0, c='tan', linestyle='--', linewidth=1.3)
# ax.plot(data_size, TSVD_rmse_mean_allsize_noi0, c='tan', linestyle='-', linewidth=1.4)
# ax.plot(data_size, KI_rmse_mean_allsize_noi05, c='brown', linestyle='--', linewidth=1.3)
# ax.plot(data_size, TSVD_rmse_mean_allsize_noi05, c='brown', linestyle='-', linewidth=1.4)
#
#
# ax.set_xlabel('|D|', fontsize='13')
# ax.set_ylabel('RMSE of 2-meter wind speed (m/s)', fontsize='13')
# plt.yscale('log')
# # plt.title('Tikhonov Regularization', fontsize='12')
# # plt.ylim(80, 25000)
# # plt.legend(['KI(uniform)', 'KI($t$-design)'], loc='upper right', fontsize='medium')
# # plt.legend(['KI','Cut-off'], loc='upper right', fontsize='medium')
#
# plt.legend(['KI($\sigma=0.0$)', 'Cut-off($\sigma=0.0$)', 'KI($\sigma=0.5$)','Cut-off($\sigma=0.5$)'], loc='upper right', fontsize='medium')
#
# # plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/f2/compare_datasize_noi05.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# # plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/f2/compare_datasize_noi0and05.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/f2/compare_datasize_noi0and05_adjustfit.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.show()




'''--------------------------------------fit强制调为0------------------------------------------------'''

'''----------------------------------- noise = 0.5-----------------------------'''
# KI_rmse_2000_noi05_mean = np.mean(wind2m['KI_rmse_2000_noi05_new'])
# KI_rmse_1600_noi05_mean = np.mean(wind2m['KI_rmse_1600_noi05_new'])
# KI_rmse_1200_noi05_mean = np.mean(wind2m['KI_rmse_1200_noi05_new'])
# KI_rmse_800_noi05_mean = np.mean(wind2m['KI_rmse_800_noi05_new'])
# KI_rmse_500_noi05_mean = np.mean(wind2m['KI_rmse_400_noi05_new'])
# KI_rmse_200_noi05_mean = np.mean(wind2m['KI_rmse_200_noi05_new'])
# KI_rmse_100_noi05_mean = np.mean(wind2m['KI_rmse_100_noi05_new'])
# KI_rmse_50_noi05_mean = np.mean(wind2m['KI_rmse_50_noi05_new'])
#
# TSVD_rmse_2000_noi05_mean = np.mean(wind2m['TSVD_rmse_2000_noi05_new'])
# TSVD_rmse_1600_noi05_mean = np.mean(wind2m['TSVD_rmse_1600_noi05_new'])
# TSVD_rmse_1200_noi05_mean = np.mean(wind2m['TSVD_rmse_1200_noi05_new'])
# TSVD_rmse_800_noi05_mean = np.mean(wind2m['TSVD_rmse_800_noi05_new'])
# TSVD_rmse_500_noi05_mean = np.mean(wind2m['TSVD_rmse_400_noi05_new'])
# TSVD_rmse_200_noi05_mean = np.mean(wind2m['TSVD_rmse_200_noi05_new'])
# TSVD_rmse_100_noi05_mean = np.mean(wind2m['TSVD_rmse_100_noi05_new'])
# TSVD_rmse_50_noi05_mean = np.mean(wind2m['TSVD_rmse_50_noi05_new'])
#
#
# wind2m['KI_rmse_mean_allsize_noi05_new'] = [KI_rmse_50_noi05_mean, KI_rmse_100_noi05_mean, KI_rmse_200_noi05_mean, KI_rmse_500_noi05_mean,
#                                         KI_rmse_800_noi05_mean, KI_rmse_1200_noi05_mean, KI_rmse_1600_noi05_mean, KI_rmse_2000_noi05_mean]
#
# wind2m['TSVD_rmse_mean_allsize_noi05_new'] = [TSVD_rmse_50_noi05_mean, TSVD_rmse_100_noi05_mean, TSVD_rmse_200_noi05_mean, TSVD_rmse_500_noi05_mean,
#                                         TSVD_rmse_800_noi05_mean, TSVD_rmse_1200_noi05_mean, TSVD_rmse_1600_noi05_mean, TSVD_rmse_2000_noi05_mean]
#
#
# np.save(os.path.dirname(os.getcwd()) + '/Result_data/wind2m.npy', wind2m)
# print('save wind2m.npy done')
# print(wind2m.keys())



'''----------------------------------- noise = 0.0-----------------------------'''
# KI_rmse_2000_noi0_mean = np.mean(wind2m['KI_rmse_2000_noi0_new'])
# KI_rmse_1600_noi0_mean = np.mean(wind2m['KI_rmse_1600_noi0_new'])
# KI_rmse_1200_noi0_mean = np.mean(wind2m['KI_rmse_1200_noi0_new'])
# KI_rmse_800_noi0_mean = np.mean(wind2m['KI_rmse_800_noi0_new'])
# KI_rmse_500_noi0_mean = np.mean(wind2m['KI_rmse_400_noi0_new'])
# KI_rmse_200_noi0_mean = np.mean(wind2m['KI_rmse_200_noi0_new'])
# KI_rmse_100_noi0_mean = np.mean(wind2m['KI_rmse_100_noi0_new'])
# KI_rmse_50_noi0_mean = np.mean(wind2m['KI_rmse_50_noi0_new'])
#
# TSVD_rmse_2000_noi0_mean = np.mean(wind2m['TSVD_rmse_2000_noi0_new'])
# TSVD_rmse_1600_noi0_mean = np.mean(wind2m['TSVD_rmse_1600_noi0_new'])
# TSVD_rmse_1200_noi0_mean = np.mean(wind2m['TSVD_rmse_1200_noi0_new'])
# TSVD_rmse_800_noi0_mean = np.mean(wind2m['TSVD_rmse_800_noi0_new'])
# TSVD_rmse_500_noi0_mean = np.mean(wind2m['TSVD_rmse_400_noi0_new'])
# TSVD_rmse_200_noi0_mean = np.mean(wind2m['TSVD_rmse_200_noi0_new'])
# TSVD_rmse_100_noi0_mean = np.mean(wind2m['TSVD_rmse_100_noi0_new'])
# TSVD_rmse_50_noi0_mean = np.mean(wind2m['TSVD_rmse_50_noi0_new'])
#
#
# wind2m['KI_rmse_mean_allsize_noi0_new'] = [KI_rmse_50_noi0_mean, KI_rmse_100_noi0_mean, KI_rmse_200_noi0_mean, KI_rmse_500_noi0_mean,
#                                         KI_rmse_800_noi0_mean, KI_rmse_1200_noi0_mean, KI_rmse_1600_noi0_mean, KI_rmse_2000_noi0_mean]
#
# wind2m['TSVD_rmse_mean_allsize_noi0_new'] = [TSVD_rmse_50_noi0_mean, TSVD_rmse_100_noi0_mean, TSVD_rmse_200_noi0_mean, TSVD_rmse_500_noi0_mean,
#                                         TSVD_rmse_800_noi0_mean, TSVD_rmse_1200_noi0_mean, TSVD_rmse_1600_noi0_mean, TSVD_rmse_2000_noi0_mean]
#
#
# np.save(os.path.dirname(os.getcwd()) + '/Result_data/wind2m.npy', wind2m)
# print('save wind2m.npy done')
# print(wind2m.keys())




'''1.2. RMSE 为了画折线图---------------------------------------------------------------'''
KI_rmse_mean_allsize_noi05 = wind2m['KI_rmse_mean_allsize_noi05_new']
TSVD_rmse_mean_allsize_noi05 = wind2m['TSVD_rmse_mean_allsize_noi05_new']
KI_rmse_mean_allsize_noi0 = wind2m['KI_rmse_mean_allsize_noi0_new']
TSVD_rmse_mean_allsize_noi0 = wind2m['TSVD_rmse_mean_allsize_noi0_new']
print(KI_rmse_mean_allsize_noi05)
print(TSVD_rmse_mean_allsize_noi05)
print(KI_rmse_mean_allsize_noi0)
print(TSVD_rmse_mean_allsize_noi0)
# [3.562374540475352, 3.1560583852948936, 3.1700520327150254, 2.4840025869162945, 2.1485148619794514, 2.0033470105183695, 1.8362199551555207, 1.7340068939167008]
# [3.147173209430138, 2.892132893725268, 2.7081014929260325, 2.278689359987846, 2.01623613860664, 1.8779877906403044, 1.7835615773805358, 1.5380649248604725]
data_size = wind2m['datasize']
print(data_size)

fig = plt.figure(tight_layout=True)
gs = gridspec.GridSpec(1, 1)
ax = fig.add_subplot(gs[0, 0])
ax.grid(linestyle='-.', axis="y")
ax.plot(data_size, KI_rmse_mean_allsize_noi0, c='royalblue', marker='o',  linestyle='--', linewidth=1.2, markersize=6)
ax.plot(data_size, TSVD_rmse_mean_allsize_noi0, c='royalblue', marker='o', markersize=6,  linestyle='-', linewidth=1.2)
ax.plot(data_size, KI_rmse_mean_allsize_noi05, c='brown', marker='s',  linestyle='--', linewidth=1.2, markersize=6)
ax.plot(data_size, TSVD_rmse_mean_allsize_noi05, c='brown', marker='s', markersize=6,  linestyle='-', linewidth=1.2)
ax.set_xlabel('|D|', fontsize='20')
ax.set_ylabel('RMSE of 2-meter wind speed (m/s)', fontsize='18')
plt.yscale('log')
plt.legend(['KI($\sigma=0.0$)', 'Cut-off($\sigma=0.0$)', 'KI($\sigma=0.5$)','Cut-off($\sigma=0.5$)'], loc='upper right', fontsize='16')
plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/f2/compare_datasize_noi0and05_adjustfit.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
plt.show()




