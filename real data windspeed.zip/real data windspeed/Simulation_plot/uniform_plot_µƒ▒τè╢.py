import os, time
from Spectral_algorithms_wind import XYZ_from_matfile, fun_rotation_mat, Predicted_KI, Predicted_KGD, \
    Predicted_KGD, Predicted_TSVD, KGD_condi_step, TSVD_condi_nu, parameter_lambda_krr_forplot, \
    parameter_step_kgd_forplot, parameter_lambda_TSVD_forplot, parameter_lambda_krr
import pandas as pd
from numpy import *
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib import rcParams
import matplotlib.gridspec as gridspec
from matplotlib.ticker import FuncFormatter
time_start = time.time()
from sklearn.model_selection import train_test_split
config = {
    "font.family":'Times New Roman',
    "font.size": 17,
    "mathtext.fontset":'stix',
}
rcParams.update(config)



loadData1 = np.load(os.path.dirname(os.getcwd()) + '/Result_data/wind2m.npy', allow_pickle=True)
wind2m = loadData1.tolist()
print(wind2m.keys())


# KI_rmse_2000_noi05_mean = np.mean(wind2m['KI_rmse_2000_noi05'])
# KRR_rmse_2000_noi05_mean = np.mean(wind2m['KRR_rmse_2000_noi05'])
# KGD_rmse_2000_noi05_mean = np.mean(wind2m['KGD_rmse_2000_noi05'])
# TSVD_rmse_2000_noi05_mean = np.mean(wind2m['TSVD_rmse_2000_noi05'])
#
# KI_rmse_2000_noi0_mean = np.mean(wind2m['KI_rmse_2000_noi0'])
# KRR_rmse_2000_noi0_mean = np.mean(wind2m['KRR_rmse_2000_noi0'])
# KGD_rmse_2000_noi0_mean = np.mean(wind2m['KGD_rmse_2000_noi0'])
# TSVD_rmse_2000_noi0_mean = np.mean(wind2m['TSVD_rmse_2000_noi0'])
# TSVD_rmse_2000_noi0_mean = 1.478

# print(KRR_rmse_2000_noi05_mean)
# print(KGD_rmse_2000_noi05_mean)
# # 1.6749491699083339
# # 1.5881555588290805


### fit强行调整为大于0之后
KI_rmse_2000_noi05_mean = np.mean(wind2m['KI_rmse_2000_noi05_new'])
KRR_rmse_2000_noi05_mean = np.mean(wind2m['KRR_rmse_2000_noi05_new'])
KGD_rmse_2000_noi05_mean = np.mean(wind2m['KGD_rmse_2000_noi05_new'])
TSVD_rmse_2000_noi05_mean = np.mean(wind2m['TSVD_rmse_2000_noi05_new'])

KI_rmse_2000_noi0_mean = np.mean(wind2m['KI_rmse_2000_noi0_new'])
KRR_rmse_2000_noi0_mean = np.mean(wind2m['KRR_rmse_2000_noi0_new'])
KGD_rmse_2000_noi0_mean = np.mean(wind2m['KGD_rmse_2000_noi0_new'])
TSVD_rmse_2000_noi0_mean = np.mean(wind2m['TSVD_rmse_2000_noi0_new'])
print(KRR_rmse_2000_noi05_mean)
print(KGD_rmse_2000_noi05_mean)
# 1.6749454123456882
# 1.5879036032594738



'''1.1.1 YF ----------------------------------'''
fig = plt.figure(tight_layout=True)
colors_KI = ['darkgray', 'darkgray', 'darkgray']
colors_KRR = ['tan', 'tan', 'tan']
colors_KGD = ['rosybrown', 'rosybrown', 'rosybrown']
colors_TSVD = ['brown', 'brown', 'brown']

data_uniform_KI = [KI_rmse_2000_noi05_mean, KI_rmse_2000_noi0_mean]
data_uniform_KRR = [KRR_rmse_2000_noi05_mean, KRR_rmse_2000_noi0_mean]
data_uniform_KGD = [KGD_rmse_2000_noi05_mean, KGD_rmse_2000_noi0_mean]
data_uniform_TSVD = [TSVD_rmse_2000_noi05_mean, TSVD_rmse_2000_noi0_mean]

bar_width = 0.4
x_range = np.arange(0,4,2)
rects0= plt.bar(x_range, data_uniform_KI, align='center', alpha=0.7, color=colors_KI, label='KI', width=0.4)
rects1= plt.bar(x_range + bar_width, data_uniform_KRR, align='center', alpha=0.7, color=colors_KRR, label='Tikhonov', width=0.4)
rects2= plt.bar(x_range + 2*bar_width, data_uniform_KGD, align='center', alpha=0.7, color=colors_KGD, label='Landweber', width=0.4)
rects3= plt.bar(x_range + 3*bar_width, data_uniform_TSVD, align='center', alpha=0.7, color=colors_TSVD, label='Cut-off', width=0.4)


for a,b in zip(x_range,data_uniform_KI):
    plt.text(a,b,'%.3f'%b,ha='center',va='bottom',fontsize=14)
for a1,b1 in zip(x_range+ bar_width,data_uniform_KRR):
    plt.text(a1,b1,'%.3f'%b1,ha='center',va='bottom',fontsize=14)
for a2,b2 in zip(x_range+2*bar_width,data_uniform_KGD):
    plt.text(a2,b2,'%.3f'%b2,ha='center',va='bottom',fontsize=14)
for a3,b3 in zip(x_range+3*bar_width,data_uniform_TSVD):
    plt.text(a3,b3,'%.3f'%b3,ha='center',va='bottom',fontsize=14)


plt.ylabel('RMSE of 2-meter wind speed (m/s)', fontsize='18')
# plt.xlabel('|D| = 2016, $\sigma = 50$', fontsize='13')
subjects = ('$\sigma$=0.5', '$\sigma$=0')
plt.xticks(x_range+ 1.5*bar_width, subjects)

plt.legend(loc='upper right')
plt.yscale('log')
# plt.yticks([1, 2])
# plt.ylim(0, 1.8)
# plt.title('Comparison of different approaches', fontsize='13')
# plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/f2/Compare_2m_2000_noi0and05.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/f2/Compare_2m_2000_noi0and05_adjustfit.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
plt.show()



# import matplotlib.pyplot as plt
#
# import matplotlib.pyplot as plt
#
# # 定义数据
# x = [1, 2, 3, 4, 5]
# y = [10, 20, 5, 30, 15]
#
# # 绘制折线图
# plt.plot(x, y)
#
# # 设置对数坐标轴，并只显示1和100的刻度
# plt.yscale('log')
# plt.yticks([1, 100])
#
# # 显示图形
# plt.show()


# import matplotlib.pyplot as plt
#
# # 定义数据
# x = [1, 2, 3, 4, 5]
# y = [10, 20, 5, 30, 15]
#
# # 绘制折线图
# plt.plot(x, y)
#
# # 设置纵坐标轴的范围，只显示最大值和最小值
# # plt.ylim(min(y), max(y))
# plt.yticks([min(y), max(y)])
# # 显示图形
# plt.show()




# import matplotlib.pyplot as plt
#
# # 定义数据
# x = ['A', 'B', 'C', 'D']
# y = [10, 20, 30, 40]
#
# # 绘制状状图
# fig, ax = plt.subplots()
# rects = ax.bar(x, y)
#
# # 在每个柱子上方添加数字
# for rect in rects:
#     height = rect.get_height()
#     ax.text(rect.get_x() + rect.get_width() / 2, height, '%d' % int(height),
#             ha='center', va='bottom', rotation=45)
#
# # 显示图形
# plt.show()









# bar_width = 0.8
# x_range = np.arange(0,8,2)
# rects0= plt.bar(x_range, data_uniform_noi500, align='center', alpha=0.7, color=colors_uniform, label='uniform', width=0.8)
# rects1= plt.bar(x_range + bar_width, data_tdesign_noi500, align='center', alpha=0.7, color=colors_tdesign, label='$t$-design', width=0.8)
#
# for a,b in zip(x_range,data_uniform_noi500):
#     plt.text(a,b,'%.3f'%b,ha='center',va='bottom',fontsize=10)
# for a1,b1 in zip(x_range+ bar_width,data_tdesign_noi500):
#     plt.text(a1,b1,'%.3f'%b1,ha='center',va='bottom',fontsize=10)
#
# plt.ylabel('RMSE of total intensity', fontsize='13')
# # plt.xlabel('|D| = 2016, $\sigma = 50$', fontsize='13')
# subjects = ('KI', 'Tikhonov', 'Landweber', 'Cut-off')
# plt.xticks(x_range+ 0.5*bar_width, subjects)
# plt.legend(loc='upper right')
# plt.yscale('log')
# plt.ylim(100, 2000)
# # plt.title('Comparison of different approaches', fontsize='13')
# plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/f2/Compare_histogram_YF_2016_noi500.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.show()



# bar_width = 0.8
# x_range = np.arange(0,8,2)
# rects0= plt.bar(x_range, data_uniform_noichange, align='center', alpha=0.7, color=colors_uniform, label='uniform', width=0.8)
# rects1= plt.bar(x_range + bar_width, data_tdesign_noichange, align='center', alpha=0.7, color=colors_tdesign, label='$t$-design', width=0.8)
#
# for a,b in zip(x_range,data_uniform_noichange):
#     plt.text(a,b,'%.3f'%b,ha='center',va='bottom',fontsize=10)
# for a1,b1 in zip(x_range+ bar_width,data_tdesign_noichange):
#     plt.text(a1,b1,'%.3f'%b1,ha='center',va='bottom',fontsize=10)
#
# plt.ylabel('$\\Delta$ RMSE', fontsize='13')
# # plt.xlabel('|D| = 2016, $\sigma = 50$', fontsize='13')
# subjects = ('KI', 'Tikhonov', 'Landweber', 'Cut-off')
# plt.xticks(x_range+ 0.5*bar_width, subjects)
# plt.legend(loc='upper right')
# plt.yscale('log')
# plt.ylim(50, 1500)
# plt.title('$\\Delta$ RMSE of total intensity under different noise level', fontsize='13')
# plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/f2/Compare_histogram_YF_2016_noichange.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.show()
