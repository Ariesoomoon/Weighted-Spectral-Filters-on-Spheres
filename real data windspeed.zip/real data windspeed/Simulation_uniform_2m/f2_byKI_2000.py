import os, time
from Spectral_algorithms_wind import XYZ_from_matfile, fun_rotation_mat, Predicted_KI, Predicted_KRR, \
    Predicted_KGD, Predicted_TSVD, KRR_condi_lambda, KGD_condi_step, TSVD_condi_nu, parameter_lambda_krr_forplot, \
    parameter_step_kgd_forplot, parameter_lambda_TSVD_forplot, parameter_lambda_krr
import pandas as pd
from numpy import *
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib import rcParams
import matplotlib.gridspec as gridspec
from matplotlib.ticker import FuncFormatter
time_start = time.time()
from sklearn.model_selection import train_test_split


'''0. set up'''
f, d = 5, 3
trails = 5


'''------------------------------------- 1. XYZ_train和Ws_train的抽取 -------------------------------------'''
# 训练的时候需要：XYZ_train和Ws_train，分别从XYZ_fortrain和Ws_fortrain中抽取
# 测试的需要：XYZ_tes，已经是固定好的2664个
#
# 画图的时候需要2664个测试样本对应的：LaLoWind_tes
# 或者：lat_list = [x for x in range(-90, 91, 5)]  # 纬度
#      lon_list = [x for x in range(-180, 180, 5)]  # 经度
#      和 Ws_tes


loadData1 = np.load(os.path.dirname(os.getcwd()) + '/Result_data/wind2m.npy', allow_pickle=True)
wind2m = loadData1.tolist()
print(wind2m.keys())

XYZ_tes = wind2m['XYZ_tes']
Ws_tes = wind2m['Ws_tes']
XYZ_fortrain = wind2m['XYZ_fortrain']
Ws_fortrain = wind2m['Ws_fortrain']

np.random.seed(0) # 只抽取一次，用5次noise作为5trails的数据
train_sample_size = 2000

indices = np.random.choice(XYZ_fortrain.shape[0], size = train_sample_size, replace=False)
XYZ_train, Ws_train = XYZ_fortrain[indices], Ws_fortrain[indices]
print(XYZ_train.shape)
print(Ws_train.shape)

# wind2m['XYZ_train'] = XYZ_train
# wind2m['Ws_train'] = Ws_train
#
# np.save(os.path.dirname(os.getcwd()) + '/Result_data/wind2m.npy', wind2m)
# print('save wind2m.npy done')
# print(wind2m.keys())


'''------------------------------------- 2. 计算 -------------------------------------'''
std_Ws = np.std(Ws_train, ddof=1)
print(std_Ws)
m_Ws = np.mean(Ws_train)
print(m_Ws)
std_ws_noise = 0.5


data_sizes, condis_YF, rmses_YF, rmses_YD, rmses_YI, fits_YF, fits_YD, fits_YI = [], [], [], [], [], [], [], []
for th in range(trails):
    np.random.seed(th)
    print('                                                                                  trail:', th + 1)
    noise_Ws = np.random.normal(0, std_ws_noise, len(Ws_train))
    Ws_train = Ws_train + noise_Ws

    Pred_YF = Predicted_KI(XYZ_train, Ws_train, XYZ_tes, Ws_tes, d)
    fits_YF.append(Pred_YF[0])
    rmses_YF.append(Pred_YF[1])
    condis_YF.append(Pred_YF[2])

    print('rmses_YF:', rmses_YF)
    print('condis:', condis_YF)
    print('data_sizes:', data_sizes)

wind2m['KI_fit_2000_noi05_new'] = fits_YF
wind2m['KI_rmse_2000_noi05_new'] = rmses_YF
wind2m['condi_2000'] = condis_YF
np.save(os.path.dirname(os.getcwd()) + '/Result_data/wind2m.npy', wind2m)
print('save wind2m.npy done')
print(wind2m.keys())
time_total = time.time() - time_start
print('runing time:', time_total)


print('condi:', np.mean(wind2m['condi_2000'])) # 26853180.97402812
print(wind2m['KI_rmse_2000_noi05'])
print(wind2m['KI_rmse_2000_noi05_new'])
# [1.5528795297789413, 1.6722184113101937, 1.8015295969595673, 1.8468862679187006, 1.9595953270279818]
# [1.528567693597082, 1.637506247061569, 1.7688530344163187, 1.8134076610039243, 1.9216998335046098]





'''----------------------------- 专门计算 wind speed 的RMSE, 强制让风速fit大于0-----------------------------------'''
# def RMSE_new(y_fit, y_tes):
#     y_fit = np.where(y_fit >= 0, y_fit, 0)
#     average_error = np.sum((y_fit - y_tes) ** 2) / len(y_tes)
#     return math.sqrt(average_error)
#
#
# RMSE = []
# for th in range(trails):
#     y_fit = wind2m['KI_fit_2000_noi05'][th]
#     RMSE.append(RMSE_new(y_fit, Ws_tes))
#
# wind2m['KI_rmse_2000_noi05_new'] = RMSE
#
# np.save(os.path.dirname(os.getcwd()) + '/Result_data/wind2m.npy', wind2m)
# print('save wind2m.npy done')
# print(wind2m.keys())
#
# print(wind2m['KI_rmse_2000_noi05'])
# print(wind2m['KI_rmse_2000_noi05_new'])
# # [1.5528795297789413, 1.6722184113101937, 1.8015295969595673, 1.8468862679187006, 1.9595953270279818]
# # [1.528567693597082, 1.637506247061569, 1.7688530344163187, 1.8134076610039243, 1.9216998335046098]





