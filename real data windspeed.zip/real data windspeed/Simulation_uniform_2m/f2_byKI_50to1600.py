import os, time
from Spectral_algorithms_wind import XYZ_from_matfile, fun_rotation_mat, Predicted_KI, Predicted_KRR, \
    Predicted_KGD, Predicted_TSVD, KRR_condi_lambda, KGD_condi_step, TSVD_condi_nu, parameter_lambda_krr_forplot, \
    parameter_step_kgd_forplot, parameter_lambda_TSVD_forplot, parameter_lambda_krr
import pandas as pd
from numpy import *
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib import rcParams
import matplotlib.gridspec as gridspec
from matplotlib.ticker import FuncFormatter
time_start = time.time()
from sklearn.model_selection import train_test_split


'''0. set up'''
f, d = 5, 3
trails = 5


'''------------------------------------- 1. XYZ_train和Ws_train的抽取 -------------------------------------'''
# 训练的时候需要：XYZ_train和Ws_train，分别从XYZ_fortrain和Ws_fortrain中抽取
# 测试的需要：XYZ_tes，已经是固定好的2664个
#
# 画图的时候需要2664个测试样本对应的：LaLoWind_tes
# 或者：lat_list = [x for x in range(-90, 91, 5)]  # 纬度
#      lon_list = [x for x in range(-180, 180, 5)]  # 经度
#      和 Ws_tes


loadData1 = np.load(os.path.dirname(os.getcwd()) + '/Result_data/wind2m.npy', allow_pickle=True)
wind2m = loadData1.tolist()
print(wind2m.keys())

XYZ_tes = wind2m['XYZ_tes']
Ws_tes = wind2m['Ws_tes']
XYZ_fortrain = wind2m['XYZ_fortrain']
Ws_fortrain = wind2m['Ws_fortrain']

np.random.seed(0) # 只抽取一次，用5次noise作为5trails的数据
train_sample_size = 50

indices = np.random.choice(XYZ_fortrain.shape[0], size = train_sample_size, replace=False)
XYZ_train, Ws_train = XYZ_fortrain[indices], Ws_fortrain[indices]
print(XYZ_train.shape)
print(Ws_train.shape)


# wind2m['XYZ_train'] = XYZ_train
# wind2m['Ws_train'] = Ws_train


wind2m['datasize'] = [50, 100, 200, 400, 800, 1200, 1600, 2000]
np.save(os.path.dirname(os.getcwd()) + '/Result_data/wind2m.npy', wind2m)
print('save wind2m.npy done')
print(wind2m.keys())



'''------------------------------------- 2. 计算 -------------------------------------'''
std_Ws = np.std(Ws_train, ddof=1)
print(std_Ws)
m_Ws = np.mean(Ws_train)
print(m_Ws)
std_ws_noise = 0.5


data_sizes, condis_YF, rmses_YF, rmses_YD, rmses_YI, fits_YF, fits_YD, fits_YI = [], [], [], [], [], [], [], []
for th in range(trails):
    np.random.seed(th)
    print('                                                                                  trail:', th + 1)
    # noise_Ws = np.random.normal(0, std_ws_noise, len(Ws_train))
    # print(Ws_train[:6])
    # print(noise_Ws[:6])
    #
    # Ws_train = Ws_train + noise_Ws
    # print(Ws_train[:6])


    Pred_YF = Predicted_KI(XYZ_train, Ws_train, XYZ_tes, Ws_tes, d)
    fits_YF.append(Pred_YF[0])
    rmses_YF.append(Pred_YF[1])
    condis_YF.append(Pred_YF[2])

    print('rmses_YF:', rmses_YF)
    print('condis:', condis_YF)
    print('data_sizes:', data_sizes)

# wind2m['KI_fit_1000_noi05'] = fits_YF
# wind2m['KI_rmse_1000_noi05'] = rmses_YF
# wind2m['condi_1000'] = condis_YF
wind2m['KI_fit_50_noi0'] = fits_YF
wind2m['KI_rmse_50_noi0'] = rmses_YF
np.save(os.path.dirname(os.getcwd()) + '/Result_data/wind2m.npy', wind2m)
print('save wind2m.npy done')
print(wind2m.keys())
time_total = time.time() - time_start
print('runing time:', time_total)









'''----------------------------------- noise = 0.5 ---------------------------------------'''
# print('condi:', np.mean(wind2m['condi_50'])) # 26853180.97402812
# print(wind2m['KI_rmse_50_noi05'])
# print('condi:', np.mean(wind2m['condi_100'])) # 26853180.97402812
# print(wind2m['KI_rmse_100_noi05'])
# print('condi:', np.mean(wind2m['condi_200'])) # 26853180.97402812
# print(wind2m['KI_rmse_200_noi05'])
# print('condi:', np.mean(wind2m['condi_400'])) # 26853180.97402812
# print(wind2m['KI_rmse_400_noi05'])
# print('condi:', np.mean(wind2m['condi_800'])) # 26853180.97402812
# print(wind2m['KI_rmse_800_noi05'])
# print('condi:', np.mean(wind2m['condi_1000'])) # 26853180.97402812
# print(wind2m['KI_rmse_1000_noi05'])
#
# print('condi:', np.mean(wind2m['condi_1200'])) # 26853180.97402812
# print(wind2m['KI_rmse_1200_noi05'])
#
# print('condi:', np.mean(wind2m['condi_1600'])) # 26853180.97402812
# print(wind2m['KI_rmse_1600_noi05'])
# print('condi:', np.mean(wind2m['condi_2000'])) # 26853180.97402812
# print(wind2m['KI_rmse_2000_noi05'])



# condi: 690.4277663322431
# [3.5853971494436117, 3.7007726606594256, 3.7464779900760097, 3.983222561849243, 3.8541093347526694]
# condi: 31097.40456324594
# [3.124251133861377, 3.149571904562539, 3.130709434767585, 3.287777924044428, 3.3347580318942507]
# condi: 1035297.9230118614
# [2.993400193351366, 3.3325022830680915, 3.2325671933664273, 3.1890809663099935, 3.2568741558830254]
# condi: 1.2676970596469294e+16
# [2.4059570542346482, 2.4474988997942804, 2.5160714200672873, 2.6148314412910074, 2.7221996186743436]
# condi: 1.2801821320865966e+16
# [2.0125780899276817, 2.1451653957080996, 2.1939606667578704, 2.3096155868218364, 2.4322880216430796]
# condi: 1.2806001007483184e+16
# [1.934314378561218, 2.023797084372575, 2.0590929330540058, 2.1633385919516765, 2.293034047625737]
# condi: 1.2168259151180414e+16
# [1.6911215727255255, 1.7784002049232632, 1.8571969604509297, 1.9711580732147702, 2.0618471759522135]
# condi: 1.2782444855329718e+16
# [1.5528795297789413, 1.6722184113101937, 1.8015295969595673, 1.8468862679187006, 1.9595953270279818]






















## noise = 0
# condi: 1.2782444855329718e+16
# [1.5840743944825133, 1.5840743944825133, 1.5840743944825133, 1.5840743944825133, 1.5840743944825133]


# [1.5528795297789413, 1.6722184113101937, 1.8015295969595673, 1.8468862679187006, 1.9595953270279818]
# [1.4857962671606655, 1.528186940289749, 1.5427068897552556, 1.5663372914118467, 1.5968340686435432]
# [1.6737209601003626, 1.6734462040821159, 1.6725319620203938, 1.6749832421234983, 1.6100634812152992]




'''转换数据'''

# loadData3 = np.load(os.path.dirname(os.getcwd()) + '/Result_data/wind2m_forkrr.npy', allow_pickle=True)
# wind2m_forkrr = loadData3.tolist()
# print(wind2m_forkrr.keys())
#
#
# loadData1 = np.load(os.path.dirname(os.getcwd()) + '/Result_data/wind2m_forkgd.npy', allow_pickle=True)
# wind2m_forkgd = loadData1.tolist()
# print(wind2m_forkgd.keys())
#
# loadData2 = np.load(os.path.dirname(os.getcwd()) + '/Result_data/wind2m_fortsvd.npy', allow_pickle=True)
# wind2m_fortsvd = loadData2.tolist()
# print(wind2m_fortsvd.keys())
#
# wind2m['KGD_rmse_YF_500'] = wind2m_forkgd['KGD_rmse_YF_500']
# wind2m['step_YF_KGD_500'] = wind2m_forkgd['step_YF_KGD_500']
# wind2m['KGD_fit_YF_500'] = wind2m_forkgd['KGD_fit_YF_500']
#
#
# wind2m['KRR_rmse_YF_500'] = wind2m_forkrr['KRR_rmse_YF_500']
# wind2m['lambda_YF_KRR_500'] = wind2m_forkrr['lambda_YF_KRR_500']
# wind2m['KRR_fit_YF_500'] = wind2m_forkrr['KRR_fit_YF_500']
#
#
# wind2m['TSVD_rmse_YF_500'] = wind2m_fortsvd['TSVD_rmse_YF_500']
# wind2m['lambda_YF_TSVD_500'] = wind2m_fortsvd['lambda_YF_TSVD_500']
# wind2m['TSVD_fit_YF_500'] = wind2m_fortsvd['TSVD_fit_YF_500']
#
# np.save(os.path.dirname(os.getcwd()) + '/Result_data/wind2m.npy', wind2m)
# print('save wind2m.npy done')
# print(wind2m.keys())
# time_total = time.time() - time_start
# print('runing time:', time_total)



