import os, time
from Spectral_algorithms_wind import XYZ_from_matfile, fun_rotation_mat, Predicted_KI, Predicted_KRR, \
    Predicted_KGD, Predicted_TSVD, KRR_condi_lambda, KGD_condi_step, TSVD_condi_nu, parameter_lambda_krr_forplot, \
    parameter_step_kgd_forplot, parameter_lambda_TSVD_forplot, parameter_lambda_krr, parameter_step_kgd, RMSE_parameter_kgd
import pandas as pd
from numpy import *
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib import rcParams
import matplotlib.gridspec as gridspec
from sklearn.model_selection import train_test_split
from matplotlib.ticker import FuncFormatter
time_start = time.time()
config = {
    "font.family":'Times New Roman',
    "font.size": 13,
#     "mathtext.fontset":'stix',
}
rcParams.update(config)



'''0. set up'''
f, d = 5, 3
trails = 5


'''------------------------------------- 1. XYZ_train和Ws_train的抽取 -------------------------------------'''
# 训练的时候需要：XYZ_train和Ws_train，分别从XYZ_fortrain和Ws_fortrain中抽取
# 测试的需要：XYZ_tes，已经是固定好的2664个
#
# 画图的时候需要2664个测试样本对应的：LaLoWind_tes
# 或者：lat_list = [x for x in range(-90, 91, 5)]  # 纬度
#      lon_list = [x for x in range(-180, 180, 5)]  # 经度
#      和 Ws_tes


loadData1 = np.load(os.path.dirname(os.getcwd()) + '/Result_data/wind2m.npy', allow_pickle=True)
wind2m = loadData1.tolist()
print(wind2m.keys())

XYZ_tes = wind2m['XYZ_tes']
Ws_tes = wind2m['Ws_tes']
XYZ_fortrain = wind2m['XYZ_fortrain']
Ws_fortrain = wind2m['Ws_fortrain']

np.random.seed(0) # 只抽取一次，用5次noise作为5trails的数据
train_sample_size = 2000

indices = np.random.choice(XYZ_fortrain.shape[0], size = train_sample_size, replace=False)
XYZ_train, Ws_train = XYZ_fortrain[indices], Ws_fortrain[indices]
print(XYZ_train.shape)
print(Ws_train.shape)


# wind2m['XYZ_train'] = XYZ_train
# wind2m['Ws_train'] = Ws_train
#
# np.save(os.path.dirname(os.getcwd()) + '/Result_data/wind2m.npy', wind2m)
# print('save wind2m.npy done')
# print(wind2m.keys())


print(XYZ_train[:2])
# [[-0.95488271 -0.05213248  0.2923717 ]
#  [ 0.65414736  0.05004679  0.75470958]]

'''------------------------------------- 2. 计算 -------------------------------------'''
std_Ws = np.std(Ws_train, ddof=1)
print(std_Ws)
m_Ws = np.mean(Ws_train)
print(m_Ws)



''' 2. KGD makes the RMSE(prediction error) smaller. 5 trail, 5-cv'''
'''2.1: test first the range the optimal regularization parameter may located in, 1 trail, 5-cv'''
# for th in range(1):
#     np.random.seed(th)
#     print('                                                                                  trail:', th + 1)
#     # noise_Ws = np.random.normal(0, std_ws_noise, len(Ws_train))
#     # Ws_train = Ws_train + noise_Ws
#
# pred_YF = parameter_step_kgd_forplot(XYZ_train, Ws_train, f, d)
# errors_YF, steps_YF = pred_YF[0], pred_YF[1]
#
# fig = plt.figure(tight_layout=True)
# gs = gridspec.GridSpec(1, 1)
# ax = fig.add_subplot(gs[0, 0])
# ax.grid(linestyle='-.')
# ax.plot(steps_YF, errors_YF, c='black', linestyle='-.', linewidth=1.4)
# ax.set_xlabel('$\\mu$ (total intensity)', fontsize='13')
# ax.set_ylabel('RMSE of YF (uniform)', fontsize='13')
# plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/f2_test_para_range/KGD_2m_cv_test_noi0.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.show()
# time_total = time.time() - time_start
# print('runing time:', time_total)
#
# wind2m['cv_errors_KGD0'] = errors_YF
# wind2m['cv_steps_KGD0'] = steps_YF
# np.save(os.path.dirname(os.getcwd()) + '/Result_data/wind2m.npy', wind2m)
# print('save wind2m.npy done')
# print(wind2m.keys())



# loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/wind2m.npy', allow_pickle=True)
# wind2m = loadData.tolist()
# print(wind2m.keys())
# steps_YF = wind2m['cv_steps_KGD0']
# errors_YF = wind2m['cv_errors_KGD0']
# print(steps_YF)
# print(errors_YF)
#
# fig = plt.figure(tight_layout=True)
# gs = gridspec.GridSpec(1, 1)
# ax = fig.add_subplot(gs[0, 0])
# ax.grid(linestyle='-.')
# ax.plot(steps_YF[:5], errors_YF[:5], c='black', linestyle='-.', linewidth=1.4)
# ax.set_xlabel('$\\mu$', fontsize='13')
# ax.set_ylabel('RMSE of windspeed (uniform)', fontsize='13')
# plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/f2_test_para_range/KGD_2m_cv_test_noi0.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.show()
# time_total = time.time() - time_start
# print('runing time:', time_total)



'''2.2: RMSE for 5 trails, 5-cv '''
fits_YF, fits_YD, fits_YI = [], [], []
rmses_kgd_YF, rmses_kgd_YD, rmses_kgd_YI, step_opt_YFs, step_opt_YDs, step_opt_YIs = [], [], [], [], [], []
for th in range(trails):
    np.random.seed(th)
    print('                                                                                  trail:', th + 1)

    step_opt_YF = parameter_step_kgd(XYZ_train, Ws_train, f, d)
    Pred_result_YF = Predicted_KGD(XYZ_train, Ws_train, XYZ_tes, Ws_tes, d, step_opt_YF)
    Pred_YF = Pred_result_YF[1]
    fits_YF.append(Pred_result_YF[0])

    rmses_kgd_YF.append(Pred_YF)
    step_opt_YFs.append(step_opt_YF)
    print('rmses_kgd_YF:', rmses_kgd_YF)

    time_total = time.time() - time_start
    print('runing time for 1 trail:', time_total)

wind2m['KGD_rmse_2000_noi0'] = rmses_kgd_YF
wind2m['step_KGD_2000_noi0'] = step_opt_YFs
wind2m['KGD_fit_2000_noi0'] = fits_YF
np.save(os.path.dirname(os.getcwd()) + '/Result_data/wind2m.npy', wind2m)
print('save wind2m.npy done')
print(wind2m.keys())
time_total = time.time() - time_start
print('runing time:', time_total)


# print(wind2m['KI_rmse_2000_noi0'])
# print(wind2m['TSVD_rmse_2000_noi0'])
# print(wind2m['KRR_rmse_2000_noi0'])  #### 检查最优参数是否在范围内⚠️
# print(wind2m['KGD_rmse_2000_noi0'])  #### 检查最优参数是否在范围内⚠️
# print(wind2m['step_KGD_2000_noi0'])  #### 检查最优参数是否在范围内⚠️
#
# print(wind2m['Ws_tes'][200:207])
# print(wind2m['TSVD_fit_2000_noi0'][1][200:207])
# print(wind2m['KRR_fit_2000_noi0'][1][200:207])
# print(wind2m['KGD_fit_2000_noi0'][1][200:207])
# print(wind2m['KI_fit_2000_noi0'][1][200:207])









