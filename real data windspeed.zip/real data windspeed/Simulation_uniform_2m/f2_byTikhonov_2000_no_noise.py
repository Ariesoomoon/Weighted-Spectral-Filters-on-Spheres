import os, time
from Spectral_algorithms_wind import XYZ_from_matfile, fun_rotation_mat, Predicted_KI, Predicted_KRR, \
    Predicted_KGD, Predicted_TSVD, KRR_condi_lambda, KGD_condi_step, TSVD_condi_nu, parameter_lambda_krr_forplot, \
    parameter_step_kgd_forplot, parameter_lambda_TSVD_forplot, parameter_lambda_krr, RMSE_parameter_krr, RMSE_parameter_kgd, RMSE_parameter_tsvd
import pandas as pd
from numpy import *
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib import rcParams
import matplotlib.gridspec as gridspec
from sklearn.model_selection import train_test_split
from matplotlib.ticker import FuncFormatter
time_start = time.time()
config = {
    "font.family":'Times New Roman',
    "font.size": 13,
#     "mathtext.fontset":'stix',
}
rcParams.update(config)


'''0. set up'''
f, d = 5, 3
trails = 5


'''------------------------------------- 1. XYZ_train和Ws_train的抽取 -------------------------------------'''
# 训练的时候需要：XYZ_train和Ws_train，分别从XYZ_fortrain和Ws_fortrain中抽取
# 测试的需要：XYZ_tes，已经是固定好的2664个
#
# 画图的时候需要2664个测试样本对应的：LaLoWind_tes
# 或者：lat_list = [x for x in range(-90, 91, 5)]  # 纬度
#      lon_list = [x for x in range(-180, 180, 5)]  # 经度
#      和 Ws_tes


loadData1 = np.load(os.path.dirname(os.getcwd()) + '/Result_data/wind2m.npy', allow_pickle=True)
wind2m = loadData1.tolist()
print(wind2m.keys())

XYZ_tes = wind2m['XYZ_tes']
Ws_tes = wind2m['Ws_tes']
XYZ_fortrain = wind2m['XYZ_fortrain']
Ws_fortrain = wind2m['Ws_fortrain']

np.random.seed(0) # 只抽取一次，用5次noise作为5trails的数据
train_sample_size = 2000

indices = np.random.choice(XYZ_fortrain.shape[0], size = train_sample_size, replace=False)
XYZ_train, Ws_train = XYZ_fortrain[indices], Ws_fortrain[indices]
print(XYZ_train.shape)
print(Ws_train.shape)


# wind2m['XYZ_train'] = XYZ_train
# wind2m['Ws_train'] = Ws_train
#
# np.save(os.path.dirname(os.getcwd()) + '/Result_data/wind2m.npy', wind2m)
# print('save wind2m.npy done')
# print(wind2m.keys())


print(XYZ_train[:2])
# [[-0.95488271 -0.05213248  0.2923717 ]
#  [ 0.65414736  0.05004679  0.75470958]]

'''------------------------------------- 2. 计算 -------------------------------------'''
std_Ws = np.std(Ws_train, ddof=1)
print(std_Ws)
m_Ws = np.mean(Ws_train)
print(m_Ws)


''' 2. KRR makes the RMSE(prediction error) smaller. 5 trail, 5-cv'''
'''2.1: test first the range the optimal regularization parameter may located in, 1 trail, 5-cv'''
for th in range(3,4):
    np.random.seed(th)
    print('                                                                                  trail:', th + 1)

pred_YF = parameter_lambda_krr_forplot(XYZ_train, Ws_train, f, d)
errors_YF, lambdas_YF = pred_YF[0], pred_YF[1]

wind2m['cv_errors_KRR'] = errors_YF
wind2m['cv_lambdas_KRR'] = lambdas_YF
np.save(os.path.dirname(os.getcwd()) + '/Result_data/wind2m.npy', wind2m)
print('save wind2m.npy done')
print(wind2m.keys())

loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/wind2m.npy', allow_pickle=True)
wind2m = loadData.tolist()
print(wind2m.keys())
lambdas_YF = wind2m['cv_lambdas_KRR']
errors_YF = wind2m['cv_errors_KRR']
print(lambdas_YF)
print(errors_YF)

fig = plt.figure(tight_layout=True)
gs = gridspec.GridSpec(1, 1)
ax = fig.add_subplot(gs[0, 0])
ax.grid(linestyle='-.')
ax.plot(lambdas_YF, errors_YF, c='black', linestyle='-.', linewidth=1.4)
ax.set_xlabel('$\\mu$ (total intensity)', fontsize='13')
ax.set_ylabel('RMSE of YF (uniform)', fontsize='13')
plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/f2_test_para_range/KRR_2m_cv_test_noi0.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
plt.show()
time_total = time.time() - time_start
print('runing time:', time_total)


'''2.2: RMSE for 5 trails, 5-cv '''
fits_YF, fits_YD, fits_YI = [], [], []
rmses_krr_YF, rmses_krr_YD, rmses_krr_YI, lambda_opt_YFs, lambda_opt_YDs, lambda_opt_YIs = [], [], [], [], [], []
for th in range(trails):
    np.random.seed(th)
    print('                                                                                  trail:', th + 1)

    lambda_opt_YF = parameter_lambda_krr(XYZ_train, Ws_train, f, d)
    Pred_result_YF = Predicted_KRR(XYZ_train, Ws_train, XYZ_tes, Ws_tes, d, lambda_opt_YF)
    Pred_YF = Pred_result_YF[1]
    fits_YF.append(Pred_result_YF[0])

    rmses_krr_YF.append(Pred_YF)
    lambda_opt_YFs.append(lambda_opt_YF)
    print('rmses_krr_YF:', rmses_krr_YF)

    time_total = time.time() - time_start
    print('runing time for 1 trail:', time_total)


wind2m['KRR_rmse_2000_noi0'] = rmses_krr_YF
wind2m['lambda_KRR_2000_noi0'] = lambda_opt_YFs
wind2m['KRR_fit_2000_noi0'] = fits_YF

np.save(os.path.dirname(os.getcwd()) + '/Result_data/wind2m.npy', wind2m)
print('save wind2m.npy done')
print(wind2m.keys())
time_total = time.time() - time_start
print('runing time:', time_total)




