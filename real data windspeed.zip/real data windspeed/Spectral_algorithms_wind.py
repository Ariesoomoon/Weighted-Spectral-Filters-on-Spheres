import pandas as pd
from numpy import *
import numpy as np
import math
import h5py
from sklearn.model_selection import KFold
import os, time
import requests
import xmljson
import json
import xmltodict
import time
import pandas as pd
from numpy import *
import math
import h5py
from sklearn.model_selection import KFold
time_start = time.time()

'''---------------------------------------------- 0. 转化经、纬度、海拔到笛卡尔坐标系---------------------------------------------------
https://blog.csdn.net/dulingwen/article/details/96868530?ops_request_misc=%257B%2522request%255Fid%2522%253A%2522168534334416800188566915%2522%252C%2522scm%2522%253A%252220140713.130102334.pc%255Fall.%2522%257D&request_id=168534334416800188566915&biz_id=0&utm_medium=distribute.pc_search_result.none-task-blog-2~all~first_rank_ecpm_v1~rank_v31_ecpm-2-96868530-null-null.142^v88^insert_down1,239^v2^insert_chatgpt&utm_term=%E5%9F%BA%E4%BA%8EPython%E7%9A%84%E7%BB%8F%E7%BA%AC%E5%BA%A6%E6%B5%B7%E6%8B%94%E4%B8%8Exyz%E5%9D%90%E6%A0%87%E7%B3%BB%E7%9B%B8%E4%BA%92%E8%BD%AC%E6%8D%A2&spm=1018.2226.3001.4187
'''

print('------------------------------------------------------------------------------ real data: geo')





'''---------------------------------------------- 1. Generate data for experiments ---------------------------------------------------'''
'''1.1 by t-design: transform data in .mat file to array'''
def XYZ_from_matfile(ss_value):
    if ss_value < 10:
        file_name = 'ss00' + str(ss_value)
    elif ss_value < 100:
        file_name = 'ss0' + str(ss_value)
    else:
        file_name = 'ss' + str(ss_value)
    # RMSE_parameter_kgd
    path = '/geo_data/'+file_name +'.mat'
    # print(path)
    mat = h5py.File(os.path.dirname(os.getcwd()) + path,  mode='r')
    data_dn = np.array(mat['data'])
    data_nd = data_dn.T
    # print(data_nd.shape)
    return data_nd


'''1.2 by rotation matrix: '''
def fun_rotation_mat(mat_ori, rotation_total_times, rotation_times):
    if rotation_times == 0:
        mat_new = mat_ori
    else:
        mat_new = mat_ori
        for i in range(1,rotation_times+1):
            radian_i = math.pi*i/rotation_total_times
            rotation_i = np.array([[math.cos(radian_i), -math.sin(radian_i), 0], [math.sin(radian_i), math.cos(radian_i), 0], [0, 0, 1]])
            mat_new = np.vstack((mat_new,np.dot(mat_ori, rotation_i)))
    return mat_new



'''1.3. function for generating the output y of data set'''
# f_1 in paper "Distirbuted semi-supervised learning with kernel ridge regression"
def create_y_g1(X_tra):
    x1, x2, x3 = X_tra[:, 0], X_tra[:, 1], X_tra[:, 2]
    y = 0.75 * np.exp(-(9*x1-2)**2/4 - (9*x2-2)**2/4 - (9*x3-2)**2/4) + \
        0.75 * np.exp(-(9*x1+1)**2/49 - (9*x2+1)/10 - (9*x3+1)/10) + \
        0.5 * np.exp(-(9*x1-7)**2/4 - (9*x2-3)**2/4 - (9*x3-5)**2/4) - \
        0.2 * np.exp(-(9*x1-4)**2 - (9*x2-7)**2 - (9*x3-5)**2)
    return y


# f_2 in paper "DIVIDE AND CONQUER LEAST SQAURES FOR UNCERTAINTY OF KERNEL INTERPOLATION ON SPHERES"
Z_tra = np.array([[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]])
def function_fai(x):
    if 1-x >= 0:
        result = (1 - x) ** 8 * (((32 * x + 25) * x + 8) * x + 1)
    else:
        result = 0.0
    return result

Z_tra = np.array([[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]])
def create_y_g2(XYZ_tra, Z_tra):
    n, t = len(XYZ_tra), len(Z_tra)              # t= 6
    Z_tra_1 = np.reshape(Z_tra, (t, 1, 3))       # (6, 1, 3)
    Z_tra_1 = np.repeat(Z_tra_1, n, axis=1)      # (6, n, 3)
    XYZ_tra_1 = np.reshape(XYZ_tra, (1, n, 3))   # (1, n, 3)
    XYZ_tra_1 = np.repeat(XYZ_tra_1, t, axis=0)  # (6, n, 3)

    dis = XYZ_tra_1 - Z_tra_1

    dis_norm = np.linalg.norm(dis, axis=2)
    function_fai_vector = np.vectorize(function_fai)
    fai_xz = function_fai_vector(dis_norm)      # (6,n)
    sum_fai_xz = np.sum(fai_xz, axis=0)         # (n,)
    return sum_fai_xz


'''1.4. generate or sample data'''
Z_tra = np.array([[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]])
'''
--------------------------------------------------取出单位球的随机采样点--------------------------------------------------
'''

'''
以6378137.0，即地球赤道平均半径为基准，随机采样，这个采样是正方体
'''
def sample(train_size, test_size):
    np.random.seed(0)

    XYZ_train = np.random.uniform(-6378137.0, 6378137.0, train_size)
    # print(XYZ_train[:4])
    XYZ_train = (XYZ_train / np.linalg.norm(XYZ_train, axis=1, keepdims=True)) * 6378137.0 # 随机从半径为赤道半径的球上采样
    print(XYZ_train[:4])
    aa = np.linalg.norm(XYZ_train, axis=1, keepdims=True)
    # print(aa[:4])

    XYZ_tes = np.random.uniform(-6378137.0, 6378137.0, test_size)
    # print(XYZ_tes[:4])
    XYZ_tes = (XYZ_tes / np.linalg.norm(XYZ_tes, axis=1, keepdims=True)) * 6378137.0
    print(XYZ_tes[:4])
    bb = np.linalg.norm(XYZ_tes, axis=1, keepdims=True)
    # print(bb[:4])

    # np.random.seed(trail)
    # noise = np.random.normal(0, noise_sd, len(XYZ_train))

    return XYZ_train.shape, XYZ_train, XYZ_tes.shape, XYZ_tes




'''
将采样点转化为大地坐标系，然后进行爬数据
'''
# latitude:纬度 longitude:经度 altitude:海拔

def LLA_to_XYZ(lon_la_al):
    # 经纬度的余弦值
    longitude = np.reshape(lon_la_al[:, 0], (len(lon_la_al), 1))
    latitude = np.reshape(lon_la_al[:, 1], (len(lon_la_al), 1))
    altitude = np.reshape(lon_la_al[:, 2], (len(lon_la_al), 1))

    vector1= np.vectorize(math.cos)
    cosLat = vector1(latitude * math.pi / 180)
    vector2 = np.vectorize(math.sin)
    sinLat = vector2(latitude * math.pi / 180)
    vector3 = np.vectorize(math.cos)
    cosLon = vector3(longitude * math.pi / 180)
    vector4 = np.vectorize(math.sin)
    sinLon = vector4(longitude * math.pi / 180)

    # WGS84坐标系的参数 6371
    rad = 6378137.0  # 地球赤道平均半径（椭球长半轴：a）
    f = 1.0 / 298.257224  # WGS84椭球扁率 :f = (a-b)/a
    vector5 = np.vectorize(math.sqrt)
    C = 1.0 / vector5(cosLat * cosLat + (1 - f) * (1 - f) * sinLat * sinLat)
    S = (1 - f) * (1 - f) * C
    h = altitude

    # 计算XYZ坐标
    X = (rad * C + h) * cosLat * cosLon
    Y = (rad * C + h) * cosLat * sinLon
    Z = (rad * S + h) * sinLat

    XY1 = np.append(X, Y, axis=1)
    XYZ1 = np.append(XY1, Z, axis=1)
    return XYZ1



def XYZ_to_LLA(XYZ):
    # X, Y, Z = XYZ[:,0], XYZ[:,1], XYZ[:,2]

    X = np.reshape(XYZ[:, 0], (len(XYZ), 1))
    Y = np.reshape(XYZ[:, 1], (len(XYZ), 1))
    Z = np.reshape(XYZ[:, 2], (len(XYZ), 1))

    # WGS84坐标系的参数
    a = 6378137.0  # 椭球长半轴
    b = 6356752.314245  # 椭球短半轴

    vector1 = np.vectorize(math.sqrt)
    vector2 = np.vectorize(np.arctan2)
    vector3= np.vectorize(math.cos)
    vector4 = np.vectorize(math.sin)

    ea = np.sqrt((a ** 2 - b ** 2) / a ** 2)
    eb = np.sqrt((a ** 2 - b ** 2) / b ** 2)
    p = np.sqrt(X ** 2 + Y ** 2)
    theta = vector2(Z * a, p * b)

    # 计算经纬度及海拔
    longitude = vector2(Y, X)
    latitude = vector2(Z + eb ** 2 * b * vector4(theta) ** 3, p - ea ** 2 * a * vector3(theta) ** 3)
    N = a / np.sqrt(1 - ea ** 2 * vector4(latitude) ** 2)
    altitude = p / vector3(latitude) - N

    lon_la = np.append(np.degrees(longitude), np.degrees(latitude), axis=1)
    lon_la_al = np.append(lon_la, altitude, axis=1)

    # print('longitude', longitude)
    # print('latitude', latitude)
    # print('altitude', altitude)
    # print('lon_la', lon_la)
    # print('lon_la_al\n', lon_la_al)
    return lon_la_al



def requests_geomag_data(latitude, longitude, altitude, date):
    res = requests.get(
        url=f'https://geomag.bgs.ac.uk/web_service/GMModels/igrf/13/?latitude={latitude}&longitude={longitude}&'
            f'altitude={altitude}&date={date}&format=xml')
    # print(res.text)
    xml_dict = xmltodict.parse(res.text)
    json_str = json.dumps(xml_dict)
    json_data = json.loads(json_str)
    return json_data


def parse_heads():
    heads = [
        'model', 'date',

        'latitude', 'longitude', 'altitude',

        'total_intensity', 'declination', 'inclination', 'north_intensity', 'east_intensity', 'vertical_intensity',
        'horizontal_intensity',

        'total_intensity_variation', 'declination_variation', 'inclination_variation', 'north_intensity_variation',
        'east_intensity_variation', 'vertical_intensity_variation', 'horizontal_intensity_variation',
    ]
    return heads


def parse_json_data_to_list(json_data):
    model = json_data['geomagnetic-field-model-result']['model']['#text']
    date = json_data['geomagnetic-field-model-result']['date']

    latitude = json_data['geomagnetic-field-model-result']['coordinates']['latitude']['#text']
    longitude = json_data['geomagnetic-field-model-result']['coordinates']['longitude']['#text']
    altitude = json_data['geomagnetic-field-model-result']['coordinates']['altitude']['#text']

    total_intensity = json_data['geomagnetic-field-model-result']['field-value']['total-intensity']['#text']
    declination = json_data['geomagnetic-field-model-result']['field-value']['declination']['#text']
    inclination = json_data['geomagnetic-field-model-result']['field-value']['inclination']['#text']
    north_intensity = json_data['geomagnetic-field-model-result']['field-value']['north-intensity']['#text']
    east_intensity = json_data['geomagnetic-field-model-result']['field-value']['east-intensity']['#text']
    vertical_intensity = json_data['geomagnetic-field-model-result']['field-value']['vertical-intensity']['#text']
    horizontal_intensity = json_data['geomagnetic-field-model-result']['field-value']['horizontal-intensity']['#text']

    total_intensity_variation = json_data['geomagnetic-field-model-result']['secular-variation']['total-intensity'][
        '#text']
    declination_variation = json_data['geomagnetic-field-model-result']['secular-variation']['declination']['#text']
    inclination_variation = json_data['geomagnetic-field-model-result']['secular-variation']['inclination']['#text']
    north_intensity_variation = json_data['geomagnetic-field-model-result']['secular-variation']['north-intensity'][
        '#text']
    east_intensity_variation = json_data['geomagnetic-field-model-result']['secular-variation']['east-intensity'][
        '#text']
    vertical_intensity_variation = \
        json_data['geomagnetic-field-model-result']['secular-variation']['vertical-intensity']['#text']
    horizontal_intensity_variation = \
        json_data['geomagnetic-field-model-result']['secular-variation']['horizontal-intensity']['#text']

    data_list = [
        model,
        date,

        float(latitude),
        float(longitude),
        float(altitude),

        float(total_intensity),
        float(declination),
        float(inclination),
        float(north_intensity),
        float(east_intensity),
        float(vertical_intensity),
        float(horizontal_intensity),

        float(total_intensity_variation),
        float(declination_variation),
        float(inclination_variation),
        float(north_intensity_variation),
        float(east_intensity_variation),
        float(vertical_intensity_variation),
        float(horizontal_intensity_variation),
    ]
    return data_list




'''
相关参考网页
https://geomag.bgs.ac.uk/
https://www.ngdc.noaa.gov/IAGA/vmod/igrf.html
https://geomag.bgs.ac.uk/research/modelling/IGRF.html
https://geomag.bgs.ac.uk/data_service/models_compass/igrf_calc.html


4. ---------------------------------------将爬取的数据（对应YF, YD, YI），存入npy文件--------------------------------------------------
float(total_intensity),
float(declination),
float(inclination)
https://wdc.kugi.kyoto-u.ac.jp/element/eleexp.html

Since geomagnetic field is a vector field, at least three elements (components) are necessary to represent the field. The elements describing the direction
 of the field are declination (D), inclination (I). D and I are measured in units of degrees. D is the angle between magnetic north and true north and positive
  when the angle measured is east of true north and negative when west. I is the angle between the horizontal plane and the total field vector. Elements describing
   the field intensity is the total intensity (F), horizontal component (H), vertical component (Z), and the north (X) and east (Y) components of the horizontal 
   intensity. These elements are generally expressed in units of in nanoTesla (10-9 Tesla / 10-5 Gauss or 1 Gamma in CGS). Combinations of the three elements 
   frequently used in geomagnetism are HDZ, XYZ and FDI.
'''



'''---------------------------------------------- 2. Calculate the kernel matrix  ---------------------------------------------------'''
# this kernel is used when dimension of input is 1
def kernel_d1(x,y):
    n,t = len(x), len(y)
    mat_1 = np.ones((t,n))
    y_1 = np.reshape(y, (t, 1), order='A')  # (t, 1)
    y_1 = np.repeat(y_1, n, axis=1)         # (t, n)
    x_1 = np.reshape(x, (1, n), order='A')  # (1, n)
    x_1 = np.repeat(x_1, t, axis=0)         # (t, n)
    kermatrix = np.minimum(x_1, y_1) + mat_1
    return kermatrix



# this kernel is used when dimension of input is 3
# (or >=1, at this time, we need to change the y_1 = np.reshape(y, (t, 1, 3)) in function "kernel_d3(x,y)")
# (1) this kernel function is from paper "Distirbuted semi-supervised learning with kernel ridge regression"
def h3_k(x):
    if x >= 0 and x <= 1:
        result = (1 - x) ** 4 * (4*x+1)
    else:
        result = 0.0
    return result

# (2) gaussian kernel
def gaussian_k(x):
    result = math.exp(-x**2)
    return result


def kernel_d3(x,y):
    n, t = len(x), len(y)
    y_1 = np.reshape(y, (t, 1, 3))
    y_1 = np.repeat(y_1, n, axis=1)  # (t,n,3)
    x_1 = np.reshape(x, (1, n, 3))
    x_1 = np.repeat(x_1, t, axis=0)  # (t,n,3)
    dis = x_1 - y_1
    dis_norm = np.linalg.norm(dis, axis=2)   # (t,n)
    # for kernel defined in "h3_k()"
    h3_k_vector = np.vectorize(h3_k)
    kermatrix = h3_k_vector(dis_norm)

    # for kernel defined in "function_fai()"
    # function_fai_vector = np.vectorize(function_fai)
    # kermatrix = function_fai_vector(dis_norm)

    # for kernel defined in "gaussian_k()"
    # width_k = 0.01 # width parameter of gaussian kernel
    # gaussian_k_vector = np.vectorize(gaussian_k)
    # kermatrix = gaussian_k_vector(dis_norm/width_k)

    return kermatrix



'''-------------------------- 3. Calculate the coefficient %\alpha% of kernel methods and calculate the condition number  ---------------------------'''
# 1. kernel interpolation(KI),
# 2. kernel ridge regression(KRR) or Tikhonov regularization,
# 3. Iterative landweber (KGD),
# 4. Spectral cut-off or truncated singular values decomposition (TSVD)
# 5 Semi-Iterative regularization, or nu method
# 6.1 Iterated Tikhonov (with regularization parameter lambda)
# 6.2 Iterated Tikhonov (with regularization parameter nu)

'''3.1 for kernel interpolation(KI) '''
def Alpha_KI(X_tra, y_tra, d):
    n = len(X_tra)
    ker = kernel_d1(X_tra, X_tra) if d == 1 else kernel_d3(X_tra, X_tra)
    U, S, V = np.linalg.svd(ker)
    condition_n = np.max(S) / np.min(S)

    S = 1 / S                             # (n, )
    S = np.reshape(S, (1, n), order='A')  # (1, n)
    S = np.repeat(S, n, axis=0)           # (n, n)
    US = np.multiply(U, S)
    ker_inverse = np.dot(US, V)
    alpha = np.dot(ker_inverse, np.reshape(y_tra, (len(y_tra), 1)))
    return alpha, condition_n


'''3.2 for kernel ridge regression (KRR) '''
def Alpha_KRR(X_tra, y_tra, d, lambda_krr):
    n = len(X_tra)
    ker = kernel_d1(X_tra, X_tra) if d == 1 else kernel_d3(X_tra, X_tra)
    U, S, V = np.linalg.svd(ker)
    S_lambda = S + n * lambda_krr
    condition_n = np.max(S_lambda) / np.min(S_lambda)

    S_lambda = 1 / S_lambda                             # (n, )
    S_lambda = np.reshape(S_lambda, (1, n), order='A')  # (1, n)
    S_lambda = np.repeat(S_lambda, n, axis=0)           # (n, n)
    US = np.multiply(U, S_lambda)
    ker_inverse = np.dot(US, V)
    alpha = np.dot(ker_inverse, np.reshape(y_tra, (len(y_tra), 1)))  # Wd diag 💎
    return alpha, condition_n


'''3.3 for Iterative landweber (KGD) '''
'''3.3.1: if add "ker1 = ker/np.max(S)" as in paper "stabilizing kernel interpolation on spheres: psectral approach and beyond", i.e., \tao=1/maximal eigenvalue'''
# def Alpha_KGD(X_tra, y_tra, d, step_kgd):
#     ker = kernel_d1(X_tra, X_tra) if d == 1 else kernel_d3(X_tra, X_tra)
#     U, S, V = np.linalg.svd(ker)
#     step_size = 50 / np.max(S)
#
#     # step_size = 1           # as in Spectral paper
#     n = len(X_tra)
#     y_tra = np.reshape(y_tra, (n, 1))
#     alpha = np.reshape(np.zeros(n), (n, 1))   # ⚠️ not the alpha= np.empty(shape=n)
#     for i in range(step_kgd):
#         alpha = alpha + (step_size / n) * (y_tra - np.dot(ker, alpha))   # Wd diag 💎
#     return alpha



def Alpha_KGD(X_tra, y_tra, d, step_kgd):
    ker = kernel_d1(X_tra, X_tra) if d == 1 else kernel_d3(X_tra, X_tra)
    U, S, V = np.linalg.svd(ker)
    # step_size = 1 / np.max(S)

    # print('np.max(S):', np.max(S))
    # step_size = 100 / np.max(S) # KGD加大stepsize
    #
    # print('old step_size:', 1 / np.max(S))
    # print('new step_size:', step_size)

    step_size = 2           # as in Spectral paper
    n = len(X_tra)
    y_tra = np.reshape(y_tra, (n, 1))
    alpha = np.reshape(np.zeros(n), (n, 1))   # ⚠️ not the alpha= np.empty(shape=n)
    for i in range(step_kgd):
        alpha = alpha + (step_size / n) * (y_tra - np.dot(ker, alpha))   # Wd diag 💎
    return alpha




def Condi_KGD(X_tra, step_kgd):
    n = len(X_tra)
    mat_I = np.identity(n)
    if step_kgd == 1:
        ker_neum = mat_I
    else:
        ker = kernel_d3(X_tra, X_tra)
        U, S, V = np.linalg.svd(ker)
        ker1 = ker/np.max(S)
        ker_neum, IK_new = mat_I, mat_I

        for i in range(1, step_kgd):
            IK_new = np.dot(IK_new, mat_I - ker1)
            ker_neum = ker_neum + IK_new
    U, S, V = np.linalg.svd(ker_neum)
    condition_n = np.max(S) / np.min(S)
    return condition_n



'''3.3.2: if there is no "\tao=1/maximal eigenvalue"'''
# def Alpha_KGD(X_tra, y_tra, d, step_kgd):
#     step_size = 1  # as in Spectral paper
#     n = len(X_tra)
#     y_tra = np.reshape(y_tra, (n, 1))
#     alpha = np.reshape(np.zeros(n), (n, 1))
#     ker = kernel_d1(X_tra, X_tra) if d == 1 else kernel_d3(X_tra, X_tra)
#     for i in range(step_kgd):
#         alpha = alpha + (step_size/n) * (y_tra - np.dot(ker, alpha))
#     return alpha
#
#
# def Condi_KGD(X_tra, step_kgd):
#     n = len(X_tra)
#     mat_I = np.identity(n)
#     if step_kgd == 1:
#         ker_neum = mat_I
#     else:
#         ker = kernel_d3(X_tra, X_tra)
#         ker_neum = mat_I
#         for i in range(1, step_kgd):
#             ker_neum = ker_neum + matrixPow(mat_I - ker,i)  # calculation in this way is very slow
#
#     U, S, V = np.linalg.svd(ker_neum)
#     condition_n = np.max(S) / np.min(S)
#     return condition_n
#
#
# def matrixPow(Matrix,n):
#     Matrix = np.mat(Matrix)
#     if(n==1):
#         return Matrix
#     else:
#         return np.matmul(Matrix,matrixPow(Matrix,n-1))



'''3.4 for Spectral cut-off '''
def Alpha_SpecCut(X_tra, y_tra, d, lambda_cut):
    n = len(X_tra)
    ker = kernel_d1(X_tra, X_tra) if d == 1 else kernel_d3(X_tra, X_tra)
    U, S, V = np.linalg.svd(ker)
    S= np.where(S >= lambda_cut, 1 / S, 0)
    condition_n = max(filter(lambda x: x > 0, S)) / S[0]

    S = np.reshape(S, (1, n), order='A')
    S = np.repeat(S, n, axis=0)
    US = np.multiply(U, S)
    ker_inverse = np.dot(US, V)
    alpha = np.dot(ker_inverse, np.reshape(y_tra, (len(y_tra), 1)))
    return alpha, condition_n


# def Alpha_SpecCut(X_tra, y_tra, d, lambda_cut):
#     n = len(X_tra)
#     ker = kernel_d1(X_tra, X_tra) if d == 1 else kernel_d3(X_tra, X_tra)
#     U, S, V = np.linalg.svd(ker)
#     S= np.where(S >= lambda_cut, 1 / S, 0)
#     # condition_n = max(filter(lambda x: x > 0, S)) / S[0]
#
#     # print('np.max(S)-----------------------------------', np.max(S))
#
#     S = np.reshape(S, (1, n), order='A')
#     S = np.repeat(S, n, axis=0)
#     US = np.multiply(U, S)
#     ker_inverse = np.dot(US, V)
#     alpha = np.dot(ker_inverse, np.reshape(y_tra, (len(y_tra), 1)))
#     return alpha, alpha



'''3.5 for Semi-Iterative regularization, or nu method '''
def Alpha_SemiIter(X_tra, y_tra, d, step_semi):
    nu = 5
    n = len(X_tra)
    y_tra = np.reshape(y_tra, (n, 1))
    alpha_i1, alpha_i2 = np.reshape(np.zeros(n), (n, 1)), np.reshape(np.zeros(n), (n, 1))
    ker = kernel_d1(X_tra, X_tra) if d == 1 else kernel_d3(X_tra, X_tra)
    for i in range(step_semi):
        u = ((i - 1) * (2 * i - 3) * (2 * i + 2 * nu - 1)) / ((i + 2 * nu - 1) * (2 * i + 4 * nu - 1) * (2 * i + 2 * nu - 3))
        w = 4 * ((2 * i + 2 * nu - 1) * (i + nu - 1)) / ((i + 2 * nu - 1) * (2 * i + 4 * nu - 1))
        alpha = alpha_i1 + u*(alpha_i1 - alpha_i2) + (w/n) * (y_tra - np.dot(ker, alpha_i1))
        alpha_i2 = alpha_i1
        alpha_i1 = alpha
    return alpha


'''3.6 for Iterated Tikhonov '''
'''3.6.1 if lambda is the regularization parameter'''
def Alpha_IterTik_lambda(X_tra, y_tra, d, lambda_tik):
    nu = 2
    n = len(X_tra)
    y_tra = np.reshape(y_tra, (n, 1))
    alpha_i1 = np.reshape(np.zeros(n), (n, 1))
    ker = kernel_d1(X_tra, X_tra) if d == 1 else kernel_d3(X_tra, X_tra)
    U, S, V = np.linalg.svd(ker)
    for i in range(nu):
        S_lambda = 1 / (S + n * lambda_tik)
        S_lambda = np.reshape(S_lambda, (1, n), order='A')
        S_lambda = np.repeat(S_lambda, n, axis=0)

        US = np.multiply(U, S_lambda)
        ker_inverse = np.dot(US, V)
        alpha = np.dot(ker_inverse, (y_tra + n * lambda_tik * alpha_i1))
        alpha_i1 = alpha
    return alpha


def Condi_IterTik_lambda(X_tra, lambda1):
    nu1 = 5
    ker = kernel_d3(X_tra, X_tra)
    U, S, V = np.linalg.svd(ker)
    sigma1, sigman = np.max(S), np.min(S)

    gn = ((sigman + lambda1) ** nu1 - lambda1 ** nu1) / (sigman * (sigman + lambda1) ** nu1)
    g1 = ((sigma1 + lambda1) ** nu1 - lambda1 ** nu1) / (sigma1 * (sigma1 + lambda1) ** nu1)
    condition_n = gn / g1
    return condition_n


'''3.6.2 if nu is the regularization parameter'''
def Alpha_IterTik_nu(X_tra, y_tra, d, step_nu):
    lambda_tik = 0.002
    n = len(X_tra)
    y_tra = np.reshape(y_tra, (n, 1))
    alpha_i1 = np.reshape(np.zeros(n), (n, 1))
    ker = kernel_d1(X_tra, X_tra) if d == 1 else kernel_d3(X_tra, X_tra)
    U, S, V = np.linalg.svd(ker)
    for i in range(step_nu):
        S_lambda = 1 / (S + n * lambda_tik)
        S_lambda = np.reshape(S_lambda, (1, n), order='A')
        S_lambda = np.repeat(S_lambda, n, axis=0)

        US = np.multiply(U, S_lambda)
        ker_inverse = np.dot(US, V)
        alpha = np.dot(ker_inverse, (y_tra + n * lambda_tik * alpha_i1))
        alpha_i1 = alpha
    return alpha


def Condi_IterTik_nu(X_tra, nu1):
    lambda1 = 0.04  # f1
    #lambda1 = 0.005  # f2
    ker = kernel_d3(X_tra, X_tra)
    U, S, V = np.linalg.svd(ker)
    sigma1, sigman = np.max(S), np.min(S)

    gn = ((sigman + lambda1) ** nu1 - lambda1 ** nu1) / (sigman * (sigman + lambda1) ** nu1)
    g1 = ((sigma1 + lambda1) ** nu1 - lambda1 ** nu1) / (sigma1 * (sigma1 + lambda1) ** nu1)
    condition_n = gn / g1
    return condition_n



'''---------------------------------------------- 4. Evaluate the prediction performance (RMSE)  ---------------------------------------------------'''
'''4.1 for KI'''
# def Predicted_KI(x_tra, y_tra, x_tes, y_tes, d):
#     n, t = len(x_tra), len(x_tes)
#     pred = Alpha_KI(x_tra, y_tra, d)
#     pred_alpha, pred_condition = pred[0], pred[1]
#     if d == 1:
#         pred_ker = kernel_d1(x_tra, x_tes)
#         y_fit = np.dot(pred_ker, pred_alpha)
#         y_fit = np.squeeze(y_fit)
#     else:
#         pred_ker = kernel_d3(x_tra, x_tes)
#         y_fit = np.dot(pred_ker, pred_alpha)
#         y_fit = np.squeeze(y_fit)
#
#     average_error = np.sum((y_fit - y_tes) ** 2) / t  # mean squared error
#     return y_fit, math.sqrt(average_error), pred_condition

# average_error
# math.sqrt(average_error)


# wind speed没有负值，所以这里强制为0
def Predicted_KI(x_tra, y_tra, x_tes, y_tes, d):
    n, t = len(x_tra), len(x_tes)
    pred = Alpha_KI(x_tra, y_tra, d)
    pred_alpha, pred_condition = pred[0], pred[1]
    if d == 1:
        pred_ker = kernel_d1(x_tra, x_tes)
        y_fit = np.dot(pred_ker, pred_alpha)
        y_fit = np.squeeze(y_fit)
    else:
        pred_ker = kernel_d3(x_tra, x_tes)
        y_fit = np.dot(pred_ker, pred_alpha)
        y_fit = np.squeeze(y_fit)

    # print(y_fit.shape)
    # y_fit = np.where(y_fit >= 0, y_fit, 0)
    # print('new:', y_fit.shape)

    average_error = np.sum((y_fit - y_tes) ** 2) / t  # mean squared error
    return y_fit, math.sqrt(average_error), pred_condition






'''4.2 for KRR'''
def Predicted_KRR(x_tra, y_tra, x_tes, y_tes, d, regular_para):
    n, t = len(x_tra), len(x_tes)
    pred = Alpha_KRR(x_tra, y_tra, d, regular_para)
    pred_alpha, pred_condition = pred[0], pred[1]
    if d == 1:
        pred_ker = kernel_d1(x_tra, x_tes)
        y_fit = np.dot(pred_ker, pred_alpha)
        y_fit = np.squeeze(y_fit)
    else:
        pred_ker = kernel_d3(x_tra, x_tes)
        y_fit = np.dot(pred_ker, pred_alpha)
        y_fit = np.squeeze(y_fit)

    # # print(y_fit.shape)
    # y_fit = np.where(y_fit >= 0, y_fit, 0)
    # # print('new:', y_fit.shape)

    average_error = np.sum((y_fit - y_tes) ** 2) / t
    return y_fit, math.sqrt(average_error), pred_condition


'''4.3 for KGD'''
def Predicted_KGD(x_tra, y_tra, x_tes, y_tes, d, regular_para):
    n, t = len(x_tra), len(x_tes)
    pred_alpha = Alpha_KGD(x_tra, y_tra, d, regular_para)
    if d == 1:
        pred_ker = kernel_d1(x_tra, x_tes)
        y_fit = np.dot(pred_ker, pred_alpha)
        y_fit = np.squeeze(y_fit)
    else:
        pred_ker = kernel_d3(x_tra, x_tes)
        y_fit = np.dot(pred_ker, pred_alpha)
        y_fit = np.squeeze(y_fit)

    # # print(y_fit.shape)
    # y_fit = np.where(y_fit >= 0, y_fit, 0)
    # # print('new:', y_fit.shape)

    average_error = np.sum((y_fit - y_tes) ** 2) / t
    return y_fit, math.sqrt(average_error)


'''4.4 for TSVD '''
# def Predicted_TSVD(x_tra, y_tra, x_tes, y_tes, d, regular_para):
#     n, t = len(x_tra), len(x_tes)
#     pred = Alpha_SpecCut(x_tra, y_tra, d, regular_para)
#     pred_alpha, pred_condition = pred[0], pred[1]
#     if d == 1:
#         pred_ker = kernel_d1(x_tra, x_tes)
#         y_fit = np.dot(pred_ker, pred_alpha)
#         y_fit = np.squeeze(y_fit)
#     else:
#         pred_ker = kernel_d3(x_tra, x_tes)
#         y_fit = np.dot(pred_ker, pred_alpha)
#         y_fit = np.squeeze(y_fit)
#
#     average_error = np.sum((y_fit - y_tes) ** 2) / t
#     return y_fit, math.sqrt(average_error), pred_condition


def Predicted_TSVD(x_tra, y_tra, x_tes, y_tes, d, regular_para):
    n, t = len(x_tra), len(x_tes)
    pred = Alpha_SpecCut(x_tra, y_tra, d, regular_para)
    pred_alpha = pred[0]
    if d == 1:
        pred_ker = kernel_d1(x_tra, x_tes)
        y_fit = np.dot(pred_ker, pred_alpha)
        y_fit = np.squeeze(y_fit)
    else:
        pred_ker = kernel_d3(x_tra, x_tes)
        y_fit = np.dot(pred_ker, pred_alpha)
        y_fit = np.squeeze(y_fit)

    average_error = np.sum((y_fit - y_tes) ** 2) / t
    return y_fit, math.sqrt(average_error)


'''4.5 for Semi-Iterative regularization, or nu method'''
def Predicted_SemiIter(x_tra, y_tra, x_tes, y_tes, d, regular_para):
    n, t = len(x_tra), len(x_tes)
    pred_alpha = Alpha_SemiIter(x_tra, y_tra, d, regular_para)
    if d == 1:
        pred_ker = kernel_d1(x_tra, x_tes)
        y_fit = np.dot(pred_ker, pred_alpha)
        y_fit = np.squeeze(y_fit)
    else:
        pred_ker = kernel_d3(x_tra, x_tes)
        y_fit = np.dot(pred_ker, pred_alpha)
        y_fit = np.squeeze(y_fit)

    average_error = np.sum((y_fit - y_tes) ** 2) / t
    return y_fit, math.sqrt(average_error)


'''4.6.1 for Iterated Tikhonov (with regularization parameter lambda)'''
def Predicted_IterTik_lambda(x_tra, y_tra, x_tes, y_tes, d, regular_para):
    n, t = len(x_tra), len(x_tes)
    pred_alpha = Alpha_IterTik_lambda(x_tra, y_tra, d, regular_para)
    if d == 1:
        pred_ker = kernel_d1(x_tra, x_tes)
        y_fit = np.dot(pred_ker, pred_alpha)
        y_fit = np.squeeze(y_fit)
    else:
        pred_ker = kernel_d3(x_tra, x_tes)
        y_fit = np.dot(pred_ker, pred_alpha)
        y_fit = np.squeeze(y_fit)

    average_error = np.sum((y_fit - y_tes) ** 2) / t
    return y_fit, math.sqrt(average_error)


'''4.6.2 for Iterated Tikhonov (with regularization parameter nu)'''
def Predicted_IterTik_nu(x_tra, y_tra, x_tes, y_tes, d, regular_para):
    n, t = len(x_tra), len(x_tes)
    pred_alpha = Alpha_IterTik_nu(x_tra, y_tra, d, regular_para)
    if d == 1:
        pred_ker = kernel_d1(x_tra, x_tes)
        y_fit = np.dot(pred_ker, pred_alpha)
        y_fit = np.squeeze(y_fit)
    else:
        pred_ker = kernel_d3(x_tra, x_tes)
        y_fit = np.dot(pred_ker, pred_alpha)
        y_fit = np.squeeze(y_fit)

    average_error = np.sum((y_fit - y_tes) ** 2) / t
    return y_fit, math.sqrt(average_error)


'''---------------------------------------------- 5. Train regularization parameters via 5 folds cross-validation  ---------------------------------------------------'''
'''5.1 KI has no regularization parameter'''
'''5.2 for KRR'''
def cv_lambda_krr(x, y, f, d, lambda_krr):
    kf = KFold(n_splits=f, shuffle=True)
    # kf = KFold(n_splits=f)
    error, condition_n = [], []
    for train_index, test_index in kf.split(x):
        x_train, x_test = x[train_index], x[test_index]
        y_train, y_test = y[train_index], y[test_index]
        result = Predicted_KRR(x_train, y_train, x_test, y_test, d, lambda_krr)
        error.append(result[1])
        condition_n.append(result[2])
    return sum(error)/f, sum(condition_n)/f



def parameter_lambda_krr(x_tra, y_tra, f, d):
    cv_errors, lambda_opts = [], []


    for i in range(7): # noise0.5用11
        lambda_i = 0.0 + 0.0001 * i



    # for i in range(10):
    #     lambda_i = 0.0 + 0.0005 * i
    # for i in range(20):
    #     lambda_i = 0.0 + 0.0002 * i

        print('i:', i)
        print('lambda_i:', lambda_i)
        cv_error = cv_lambda_krr(x_tra, y_tra, f, d, lambda_i)[0]
        cv_errors.append(cv_error)
        lambda_opts.append(lambda_i)

    index = cv_errors.index(min(cv_errors))
    lambda_opt = lambda_opts[index]
    return lambda_opt


# Test how the error changes with the parameter lambda when use cv
def parameter_lambda_krr_forplot(x_tra, y_tra, f, d):
    errors, condition_ns, lambda_opts = [], [], []
    # for i in range(10):
    #     lambda_i = 0.0 + 0.0005 * i

    for i in range(11):
        lambda_i = 0.0 + 0.0001 * i

    # for i in range(20):
    #     lambda_i = 0.0 + 0.0002 * i

        # lambda_i = 0.0000005 + 0.0001 * i
        print('lambda_i:', lambda_i)
        cv = cv_lambda_krr(x_tra, y_tra, f, d, lambda_i)
        errors.append(cv[0])
        condition_ns.append(cv[1])
        lambda_opts.append(lambda_i)
        print(cv[0])
    return errors, lambda_opts, condition_ns



'''5.3 for KGD'''
def cv_step_kgd(x, y, f, d, step_kgd):
    kf = KFold(n_splits=f, shuffle=True)
    error, condition_n = [], []
    for train_index, test_index in kf.split(x):
        x_train, x_test = x[train_index], x[test_index]
        y_train, y_test = y[train_index], y[test_index]
        result = Predicted_KGD(x_train, y_train, x_test, y_test, d, step_kgd)[1]
        error.append(result)
        # condition_n1 = Condi_KGD(x_train, step_kgd)
        # condition_n.append(condition_n1)
    return sum(error)/f
    # return sum(error)/f, sum(condition_n)/f


# def parameter_step_kgd(x_tra, y_tra, f, d, step_sta, step_end):
#     cv_errors, step_opts = [], []
#     for step in range(step_sta, step_end):
#         print('step:', step)
#         cv_error = cv_step_kgd(x_tra, y_tra, f, d, step)
#         cv_errors.append(cv_error)
#         step_opts.append(step)
#
#     index = cv_errors.index(min(cv_errors))
#     step_opt = step_opts[index]
#     return step_opt



def parameter_step_kgd(x_tra, y_tra, f, d):
    errors, step_opts = [], []
    len_x = len(x_tra)

    for i in range(16): # noise0.5用16
        step = 200 + 1000 * i

    # for i in range(71):
    #     step = 50 + 200 * i

        print(step)
        cv = cv_step_kgd(x_tra, y_tra, f, d, step)
        errors.append(cv)
        step_opts.append(step)

    index = errors.index(min(errors))
    step_opt = step_opts[index]
    return step_opt





# just for test
def parameter_step_kgd_forplot(x_tra, y_tra, f, d):
    errors, condition_ns, step_opts = [], [], []
    # for i in range(10):
    #     step = 30 + 1500* i

    # for i in range(10):
    #     step = 50000 + 20000*

    for i in range(11):
        step = 200 + 1000* i
    #
    # for i in range(31):
    #     step = 50 + 200* i

    # for i in range(71):
    #     step = 50 + 200 * i

        print(step)
        cv = cv_step_kgd(x_tra, y_tra, f, d, step)
        errors.append(cv)
        step_opts.append(step)
    return errors, step_opts
    # return errors, step_opts, condition_ns


'''5.4 for TSVD '''
# def cv_lambda_TSVD(x, y, f, d, lambda_cut):
#     kf = KFold(n_splits=f, shuffle=True)
#     #kf = KFold(n_splits=f)
#     error, condition_n = [], []
#     for train_index, test_index in kf.split(x):
#         x_train, x_test = x[train_index], x[test_index]
#         y_train, y_test = y[train_index], y[test_index]
#         result = Predicted_TSVD(x_train, y_train, x_test, y_test, d, lambda_cut)
#         error.append(result[1])
#         condition_n.append(result[2])
#     return sum(error)/f, sum(condition_n)/f


# no condition number
def cv_lambda_TSVD(x, y, f, d, lambda_cut):
    kf = KFold(n_splits=f, shuffle=True)
    #kf = KFold(n_splits=f)
    error, condition_n = [], []
    for train_index, test_index in kf.split(x):
        x_train, x_test = x[train_index], x[test_index]
        y_train, y_test = y[train_index], y[test_index]
        result = Predicted_TSVD(x_train, y_train, x_test, y_test, d, lambda_cut)
        error.append(result[1])
        # condition_n.append(result[2])
    return sum(error)/f


# def parameter_lambda_TSVD(x_tra, y_tra, f, d):
#     cv_errors, lambda_opts = [], []
#     for i in range(51):
#         lambda_i = 1 + 0.01 * i
#         print('lambda_i:', lambda_i)
#         cv_error = cv_lambda_TSVD(x_tra, y_tra, f, d, lambda_i)[0]
#         cv_errors.append(cv_error)
#         lambda_opts.append(lambda_i)
#
#     index = cv_errors.index(min(cv_errors))
#     lambda_opt = lambda_opts[index]
#     return lambda_opt


def parameter_lambda_TSVD(x_tra, y_tra, f, d, t_design):
    cv_errors, lambda_opts = [], []

    if t_design <= 47:
        for i in range(51):
            lambda_i = 0.0 + 0.2 * i
            print('lambda_i:', lambda_i)
            cv_error = cv_lambda_TSVD(x_tra, y_tra, f, d, lambda_i)
            cv_errors.append(cv_error)
            lambda_opts.append(lambda_i)

    if t_design > 47 and t_design <= 59:
        for i in range(101):
            lambda_i = 0.0 + 0.2 * i
            print('lambda_i:', lambda_i)
            cv_error = cv_lambda_TSVD(x_tra, y_tra, f, d, lambda_i)
            cv_errors.append(cv_error)
            lambda_opts.append(lambda_i)

    if t_design > 59 and t_design <= 63:
        for i in range(126):
            lambda_i = 0.0 + 0.2 * i
            print('lambda_i:', lambda_i)
            cv_error = cv_lambda_TSVD(x_tra, y_tra, f, d, lambda_i)
            cv_errors.append(cv_error)
            lambda_opts.append(lambda_i)

    index = cv_errors.index(min(cv_errors))
    lambda_opt = lambda_opts[index]
    return lambda_opt



# just for test
# def parameter_lambda_TSVD_forplot(x_tra, y_tra, f, d):
#     errors, condition_ns, lambda_opts = [], [], []
#     # for i in range(20):    # f1
#     #     lambda_i = 0.005 + 1 * i
#     # for i in range(20):  # f2
#     #     lambda_i = 0.0005 + 0.1 * i
#     for i in range(20):  # f2
#         lambda_i = 0.0 + 0.6 * i
#
#         print('lambda_i:', lambda_i)
#         cv = cv_lambda_TSVD(x_tra, y_tra, f, d, lambda_i)
#         errors.append(cv[0])
#         condition_ns.append(cv[1])
#         lambda_opts.append(lambda_i)
#         print(cv)
#     return errors, lambda_opts, condition_ns

# just for test, no condition number
def parameter_lambda_TSVD_forplot(x_tra, y_tra, f, d):
    errors, condition_ns, lambda_opts = [], [], []
    # for i in range(20):    # f1
    #     lambda_i = 0.005 + 1 * i
    # for i in range(20):  # f2
    #     lambda_i = 0.0005 + 0.1 * i
    for i in range(21):  # f2
        lambda_i = 0.0 + 2 * i

        print('lambda_i:', lambda_i)
        cv = cv_lambda_TSVD(x_tra, y_tra, f, d, lambda_i)
        errors.append(cv)
        # condition_ns.append(cv[1])
        lambda_opts.append(lambda_i)
        print(cv)
    return errors, lambda_opts



'''5.5 for Semi-Iterative regularization, or nu method'''
def cv_step_semi(x, y, f, d, step_semi):
    kf = KFold(n_splits=f, shuffle=True)
    error = []
    for train_index, test_index in kf.split(x):
        x_train, x_test = x[train_index], x[test_index]
        y_train, y_test = y[train_index], y[test_index]
        error_validation = Predicted_SemiIter(x_train, y_train, x_test, y_test, d, step_semi)[1]
        error.append(error_validation)
    return sum(error)/f


def parameter_step_semi(x_tra, y_tra, f, d, step_sta, step_end):
    cv_errors, step_opts = [], []
    for step in range(step_sta, step_end):
        print('step:', step)
        cv_error = cv_step_semi(x_tra, y_tra, f, d, step)
        cv_errors.append(cv_error)
        step_opts.append(step)
    index = cv_errors.index(min(cv_errors))
    step_opt = step_opts[index]
    return step_opt


def parameter_step_semi_forplot(x_tra, y_tra, f, d):
    cv_errors, step_opts = [], []
    for i in range(20):
        step = 30 + 15 * i
        print('step:', step)
        cv_error = cv_step_semi(x_tra, y_tra, f, d, step)
        cv_errors.append(cv_error)
        step_opts.append(step)
        print(cv_error)
    return cv_errors, step_opts


'''5.6.1 for Iterated Tikhonov (with regularization parameter lambda)'''
def cv_lambda_IterTik(x, y, f, d, lambda_tik):
    kf = KFold(n_splits=f, shuffle=True)
    error = []
    for train_index, test_index in kf.split(x):
        x_train, x_test = x[train_index], x[test_index]
        y_train, y_test = y[train_index], y[test_index]
        error_validation = Predicted_IterTik_lambda(x_train, y_train, x_test, y_test, d, lambda_tik)[1]
        error.append(error_validation)
    return sum(error)/f


def parameter_lambda_IterTik(x_tra, y_tra, f, d):
    cv_errors, lambda_opts = [], []
    for i in range(16):
        lambda_i = 0.015 + 0.001 * i
        print('lambda_i:', lambda_i)
        cv_error = cv_lambda_IterTik(x_tra, y_tra, f, d, lambda_i)
        cv_errors.append(cv_error)
        lambda_opts.append(lambda_i)
    index = cv_errors.index(min(cv_errors))
    lambda_opt = lambda_opts[index]
    return lambda_opt


def parameter_lambda_IterTik_forplot(x_tra, y_tra, f, d):
    cv_errors, lambda_opts = [], []
    # for i in range(20):    # f1
    #     lambda_i = 0.00005 + 0.01 * i
    for i in range(20):  # f2
        lambda_i = 0.00005 + 0.001 * i
        print('lambda_i:', lambda_i)
        cv_error = cv_lambda_IterTik(x_tra, y_tra, f, d, lambda_i)
        print(cv_error)
        cv_errors.append(cv_error)
        lambda_opts.append(lambda_i)
    return cv_errors, lambda_opts


'''5.6.2 for Iterated Tikhonov (with regularization parameter nu)'''
def cv_nu_IterTik(x, y, f, d, step_nu):
    kf = KFold(n_splits=f, shuffle=True)
    error = []
    for train_index, test_index in kf.split(x):
        x_train, x_test = x[train_index], x[test_index]
        y_train, y_test = y[train_index], y[test_index]
        error_validation = Predicted_IterTik_nu(x_train, y_train, x_test, y_test, d, step_nu)[1]
        error.append(error_validation)
    return sum(error)/f


def parameter_nu_IterTik(x_tra, y_tra, f, d, step_sta, step_end):
    cv_errors, step_opts = [], []
    for i in range(16):
        step = 10 + 2*i
        print('step:', step)
        cv_error = cv_nu_IterTik(x_tra, y_tra, f, d, step)
        cv_errors.append(cv_error)
        step_opts.append(step)

    index = cv_errors.index(min(cv_errors))
    step_opt = step_opts[index]
    return step_opt


def parameter_nu_IterTik_forplot(x_tra, y_tra, f, d):
    cv_errors, step_opts = [], []
    # for i in range(20): # f1
    #     step = 1 + 4*i
    # for i in range(20):   # f2
    #     step = 15+15*i
    for i in range(20):   # f2
        step = 1+2*i
        print('step:', step)
        cv_error = cv_nu_IterTik(x_tra, y_tra, f, d, step)
        cv_errors.append(cv_error)
        step_opts.append(step)
        print(cv_error)
    return cv_errors, step_opts



'''-----------------------6. observe how condition number changes with the regularization parameter ------------------'''
# fix |D|=1130(t=47)
# no 5-cv, just 1 trail
'''6.1 for KRR'''
def KRR_condi_lambda(x_tra, y_tra, d):
    condis, lambdas = [], []
    for i in range(20):
        lambda_i = 0.0 + 0.0001 * i  # lambda_i = 0.0, 0.0001, 0.0002, ..., 0.0018, 0.0019
        # lambda_i = 0.0000005 + 0.0001 * i
        print('lambda_i:', lambda_i)
        condi = Alpha_KRR(x_tra, y_tra, d, lambda_i)[1]
        condis.append(condi)
        lambdas.append(lambda_i)
    return lambdas, condis


'''6.2 for KGD'''
def KGD_condi_step(x_tra, y_tra, d):
    condis, steps = [], []
    # for i in range(20):
    #     step = 15 + 40 * i
    # for i in range(20):  # f2
    #     step = 100 + 400 * i

    for i in range(10):  # f2
        step = 100 + 400 * i
        print('step:', step)

        condi = Condi_KGD(x_tra, step)
        condis.append(condi)
        steps.append(step)
        print(steps)
        print(condis)
    return steps, condis


def TSVD_condi_nu(x_tra, y_tra, d):
    condis, nus = [], []
    for i in range(20):  # f2
        nu_i = 0.0 + 0.1 * i
        print('nu:', nu_i)

        condi = Alpha_SpecCut(x_tra, y_tra, d, nu_i)[1]
        condis.append(condi)
        nus.append(nu_i)
        print(nus)
        print(condis)
    return nus, condis



'''-----------------------7. observe how RMSE changes with the regularization parameter, no cv ------------------'''
# fix |D|=1130(t=47)
# no 5-cv, just 1 trail
'''7.1 for KRR'''
def RMSE_parameter_krr(x_tra, y_tra, x_tes, y_tes, d):
    errors, lambda_opts = [], []
    # for i in range(40):  # 5-cv use
    #     lambda_i = 0.0 + 0.0005 * i

    for i in range(40):   # 球面fit use, noise=0.1, 0.5
        lambda_i = 0.0 + 0.005 * i

        print('lambda_i:', lambda_i)
        error = Predicted_KRR(x_tra, y_tra, x_tes, y_tes, d, lambda_i)[1]
        errors.append(error)
        lambda_opts.append(lambda_i)
    return lambda_opts, errors





'''7.2 for KGD'''
# if t_design > 43 and t_design <= 47:
#     for i in range(151):
#         step = 3000 + 20 * i # the range used in 5-cv
#         print(step)

## 球面fit
# step_list = [1,2,5,10, 50, 550, 1050, 1550, 2050, 2550, 3050, 3550, 4050, 4550, 5050, 5550, 6050, 6550, 7050] # noise=0.5
# step_list = [1000, 2000, 10000, 20000, 30000, 40000, 60000, 80000, 100000] # noise=0.3
# step_list = [1000, 2000, 10000, 20000, 30000, 40000, 60000, 80000, 100000] # noise=0.1
# step_list = [1000, 2000, 10000, 50000, 100000, 150000, 200000] # noise=0.01

def RMSE_parameter_kgd(x_tra, y_tra, x_tes, y_tes, d, step_list):
    errors, steps = [], []
    for i in range(len(step_list)):
        step = step_list[i]
        print('step:', step)
        error = Predicted_KGD(x_tra, y_tra, x_tes, y_tes, d, step)[1]
        errors.append(error)
        steps.append(step)
    return steps, errors



'''7.3 for TSVD'''
# if t_design <= 47:
#     for i in range(51):
#         lambda_i = 0.0 + 0.2 * i

def RMSE_parameter_tsvd(x_tra, y_tra, x_tes, y_tes, d):
    errors, nu_opts = [], []
    for i in range(81):
        nu_i = 0.0 + 0.25 * i
        print('nu_i:', nu_i)
        error = Predicted_TSVD(x_tra, y_tra, x_tes, y_tes, d, nu_i)[1]
        errors.append(error)
        nu_opts.append(nu_i)
    return nu_opts, errors






