import os, time
from Spectral_algorithms_wind import XYZ_from_matfile, fun_rotation_mat, Predicted_KI, Predicted_KRR, \
    Predicted_KGD, Predicted_TSVD, KRR_condi_lambda, KGD_condi_step, TSVD_condi_nu, parameter_lambda_krr_forplot, \
    parameter_step_kgd_forplot, parameter_lambda_TSVD_forplot, parameter_lambda_krr, RMSE_parameter_krr, RMSE_parameter_kgd, RMSE_parameter_tsvd
import pandas as pd
from numpy import *
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib import rcParams
import matplotlib.gridspec as gridspec
from sklearn.model_selection import train_test_split
from matplotlib.ticker import FuncFormatter
time_start = time.time()



'''-------------------------------------1.load and check the data-------------------------------------'''

# data = pd.read_csv('wind2m_speed_dataset.csv') # 跑的时候，不要设置根目录
# print('\n output the first 5 data -----------------------------------------------------------------\n', data.head())
#
# print('the number of different values of longtitude：', data.longitude.nunique())
# print('the number of different values of latitude：', data.latitude.nunique())  # unique()是获取不同的数值
# print('the number of different values of wind2m_speed：', data.wind2m_speed.nunique())
# # different values of longtitude： 576
# # the number of different values of latitude： 361
# # different values of wind2m_speed： 206779
# # print('different values of longtitude：', data.longitude.unique())
# # print('different values of latitude：', data.latitude.unique())


# data = pd.read_csv('wind10m_speed_dataset.csv') # 207936个数据
# print('\n output the first 5 data -----------------------------------------------------------------\n', data.head())
# print('the number of different values of longtitude：', data.longitude.nunique())
# print('the number of different values of latitude：', data.latitude.nunique())  # unique()是获取不同的数值
# print('the number of different values of wind2m_speed：', data.wind10m_speed.nunique())
# # the number of different values of longtitude： 576
# # the number of different values of latitude： 361
# # the number of different values of wind2m_speed： 206739
# # print('different values of longtitude：', data.longitude.unique())
# # print('different values of latitude：', data.latitude.unique())


data = pd.read_csv('wind50m_speed_dataset.csv') # 207936个数据
print('\n output the first 5 data -----------------------------------------------------------------\n', data.head())
print('the number of different values of longtitude：', data.longitude.nunique())
print('the number of different values of latitude：', data.latitude.nunique())  # unique()是获取不同的数值
print('the number of different values of wind2m_speed：', data.wind50m_speed.nunique())
# the number of different values of longtitude： 576
# the number of different values of latitude： 361
# the number of different values of wind2m_speed： 206594



'''------------------------------------- 2. 筛选出风速数据，用来预测-------------------------------------'''
lat_list = [x for x in range(-90, 91, 5)]  # 纬度, 37
lon_list = [x for x in range(-180, 180, 5)]  # 经度, 60;  = 2200
# print(lat_list)
# print(lon_list)
# print(len(lat_list))# 37
# print(len(lon_list))# 72
# print(len(lon_list)*len(lat_list))# 2664

query_str = 'longitude in @lon_list and latitude in @lat_list'
filtered_df = data.query(query_str)

# windspeed_test = filtered_df["wind2m_speed"]           # -----------⚠️ 换风速1
# windspeed_test = filtered_df["wind10m_speed"]
windspeed_test = filtered_df["wind50m_speed"]
# print(len(windspeed_test))  # 2664
# print(type(windspeed_test)) # <class 'pandas.core.series.Series'>


## 除去测试用的风速
# unfiltered_df = data.query('not (longitude in @lon_list and latitude in @lat_list)')
# windspeed_unfiltered = unfiltered_df["wind2m_speed"]      # -----------⚠️ 换风速2
# # windspeed_unfiltered = unfiltered_df["wind10m_speed"]
# # windspeed_unfiltered = unfiltered_df["wind50m_speed"]
# print(len(windspeed_unfiltered))  # 2664
# print(type(windspeed_unfiltered)) # <class 'pandas.core.series.Series'>


'''------------------------------------- 3. 准备2664个预测数据：LLW_tes -------------------------------------'''
lat_test = [num for num in lat_list for i in range(72)] # 37 * 72
lon_test = lon_list*37  # 72 * 37
lat_test = np.array(lat_test)
lon_test = np.array(lon_test)

windspeed_test = windspeed_test.to_numpy()
LaLoWind_tes = np.column_stack((lat_test, lon_test, windspeed_test))  # 注意顺序：测试数据和地磁数据的测试数据一样，第一列是latitude

# # print(lat_test)
# # print(lon_test)
# # print(windspeed_test)
# # print(lat_test.shape)
# # print(lon_test.shape)
# # print(windspeed_test.shape)
# #
# # print(LaLoWind_tes)
# # print(LaLoWind_tes.shape)
#
#
# ## 保存2664测试数据：
# # np.savetxt('wind2m_test.csv', LaLoWind_tes, delimiter=',', header='latitude,logitude,wind50m_speed', comments='')  # -----------⚠️ 换风速3
# # # with open('wind2m_test.csv', 'r') as f:
# # #     print(f.read())
#
#
# # np.savetxt('wind10m_test.csv', LaLoWind_tes, delimiter=',', header='latitude,logitude,wind50m_speed', comments='')  #
# # # with open('wind10m_test.csv', 'r') as f:
# # #     print(f.read())
#
#
# # np.savetxt('wind50m_test.csv', LaLoWind_tes, delimiter=',', header='latitude,logitude,wind50m_speed', comments='')  #
# # with open('wind50m_test.csv', 'r') as f:
# #     print(f.read())



'''------------------------------------- 4. 准备训练和测试的数据，存入npy文件-------------------------------------'''
# #把dataframe转为array数据
windsppeed = data.wind50m_speed  # ----------------------------------------------------------------------------------------------------⚠️ 换风速4
windsppeed = np.array(windsppeed)
lat = data.latitude
lat = np.array(lat)
lon = data.longitude
lon = np.array(lon)

LaLoWind_total = np.column_stack((lat, lon, windsppeed))  # 注意顺序：测试数据和地磁数据的测试数据一样，第一列是latitude
LaLoWind_fortrain = np.array([row for row in LaLoWind_total if not np.any(np.all(row == LaLoWind_tes, axis=1))])

print('LaLoWind_total.shape:', LaLoWind_total.shape)
print('LaLoWind_fortrain.shape:', LaLoWind_fortrain.shape)
print('LaLoWind_tes.shape:', LaLoWind_tes.shape)
# LaLoWind_total.shape: (207936, 3)
# LaLoWind_fortrain.shape: (205272, 3)
# LaLoWind_tes.shape: (2664, 3)



'''------------------------------------- 4.1 2m -------------------------------------'''
# # wind2m = {}
# # np.save('/Users/liuxiaotong/Documents/machine learning/4_Spectral approach on spheres/real data windspeed/Result_data/wind2m.npy', wind2m)
# # print('save wind2m.npy done')
#
# loadData1 = np.load(os.path.dirname(os.getcwd()) + '/real data windspeed/Result_data/wind2m.npy', allow_pickle=True)
# wind2m = loadData1.tolist()
# print(wind2m.keys())
#
# # wind2m['LaLoWind_total'] = LaLoWind_total
# # wind2m['LaLoWind_fortrain'] = LaLoWind_fortrain
# # wind2m['LaLoWind_tes'] = LaLoWind_tes
# #
# # np.save(os.path.dirname(os.getcwd()) + '/real data windspeed/Result_data/wind2m.npy', wind2m)
# # print('save wind2m.npy done')
# # print(wind2m.keys())
#
# print(wind2m['LaLoWind_total'].shape)
# print(wind2m['LaLoWind_fortrain'].shape)
# print(wind2m['LaLoWind_tes'].shape)
# print(wind2m['LaLoWind_tes'])
# # (207936, 3)
# # (205272, 3)
# # (2664, 3)


'''------------------------------------- 4.2 10m -------------------------------------'''
# # wind10m = {}
# # np.save('/Users/liuxiaotong/Documents/machine learning/4_Spectral approach on spheres/real data windspeed/Result_data/wind10m.npy', wind10m)
# # print('save wind10m.npy done')
#
# loadData1 = np.load(os.path.dirname(os.getcwd()) + '/real data windspeed/Result_data/wind10m.npy', allow_pickle=True)
# wind10m = loadData1.tolist()
# print(wind10m.keys())
#
# # wind10m['LaLoWind_total'] = LaLoWind_total
# # wind10m['LaLoWind_fortrain'] = LaLoWind_fortrain
# # wind10m['LaLoWind_tes'] = LaLoWind_tes
# #
# # np.save(os.path.dirname(os.getcwd()) + '/real data windspeed/Result_data/wind10m.npy', wind10m)
# # print('save wind10m.npy done')
# # print(wind10m.keys())


'''------------------------------------- 4.3 50m -------------------------------------'''
# # wind50m = {}
# # np.save('/Users/liuxiaotong/Documents/machine learning/4_Spectral approach on spheres/real data windspeed/Result_data/wind50m.npy', wind50m)
# # print('save wind50m.npy done')
#
# loadData1 = np.load(os.path.dirname(os.getcwd()) + '/real data windspeed/Result_data/wind50m.npy', allow_pickle=True)
# wind50m = loadData1.tolist()
# print(wind50m.keys())
#
# wind50m['LaLoWind_total'] = LaLoWind_total
# wind50m['LaLoWind_fortrain'] = LaLoWind_fortrain
# wind50m['LaLoWind_tes'] = LaLoWind_tes
#
# np.save(os.path.dirname(os.getcwd()) + '/real data windspeed/Result_data/wind50m.npy', wind50m)
# print('save wind50m.npy done')
# print(wind50m.keys())




'''------------------------------------- 5.  LaLoWind_train从LaLoWind_fortrain中抽取 -------------------------------------'''

loadData1 = np.load(os.path.dirname(os.getcwd()) + '/real data windspeed/Result_data/wind2m.npy', allow_pickle=True)
wind2m = loadData1.tolist()
print(wind2m.keys())

LaLoWind_fortrain = wind2m['LaLoWind_fortrain']
LaLoWind_tes = wind2m['LaLoWind_tes']

train_length = 2000
indices = np.random.choice(LaLoWind_fortrain.shape[0], size = train_length, replace=False)
LaLoWind_train = LaLoWind_fortrain[indices]
# print(indices)
print(LaLoWind_train)
print(LaLoWind_train.shape)
print(LaLoWind_tes)
print(LaLoWind_tes.shape)










