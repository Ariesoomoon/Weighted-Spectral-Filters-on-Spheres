import os, time
from Spectral_algorithms_wind import XYZ_from_matfile, fun_rotation_mat, Predicted_KI, Predicted_KRR, \
    Predicted_KGD, Predicted_TSVD, KRR_condi_lambda, KGD_condi_step, TSVD_condi_nu, parameter_lambda_krr_forplot, \
    parameter_step_kgd_forplot, parameter_lambda_TSVD_forplot, parameter_lambda_krr, RMSE_parameter_krr, RMSE_parameter_kgd, RMSE_parameter_tsvd
import pandas as pd
from numpy import *
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib import rcParams
import matplotlib.gridspec as gridspec
from sklearn.model_selection import train_test_split
from matplotlib.ticker import FuncFormatter
time_start = time.time()


def LL_to_XYZ(lalowind_data):
    # 经纬度的余弦值
    longitude = np.reshape(lalowind_data[:, 1], (len(lalowind_data), 1))
    latitude = np.reshape(lalowind_data[:, 0], (len(lalowind_data), 1))

    vector1= np.vectorize(math.cos)
    cosLat = vector1(latitude * math.pi / 180)
    vector2 = np.vectorize(math.sin)
    sinLat = vector2(latitude * math.pi / 180)
    vector3 = np.vectorize(math.cos)
    cosLon = vector3(longitude * math.pi / 180)
    vector4 = np.vectorize(math.sin)
    sinLon = vector4(longitude * math.pi / 180)

    # 计算XYZ坐标
    X = cosLat * cosLon
    Y = cosLat * sinLon
    Z = sinLat

    XY1 = np.append(X, Y, axis=1)
    XYZ1 = np.append(XY1, Z, axis=1)
    return XYZ1


'''------------------------------------- 1. 将LaLoWind数据转为单位球体上的数据 -------------------------------------'''
# # LaLoWind_fortrain中的latitude,logitude信息 --> XYZ_fortrain
# # 中的风速信息 --> Ws_fortrain
# #
# # LaLoWind_tes中的latitude,logitude信息 --> XYZ_tes
# # 中的风速信息 --> Ws_tes
# #
# # phi: latitude； theta: logitude
#
loadData1 = np.load(os.path.dirname(os.getcwd()) + '/real data windspeed/Result_data/wind2m.npy', allow_pickle=True)
wind2m = loadData1.tolist()
print(wind2m.keys())

LaLoWind_fortrain = wind2m['LaLoWind_fortrain']
LaLoWind_tes = wind2m['LaLoWind_tes']

# XYZ_fortrain = LL_to_XYZ(LaLoWind_fortrain)
# print(XYZ_fortrain.shape) # (205272, 3)
# XYZ_tes = LL_to_XYZ(LaLoWind_tes)
# print(XYZ_tes.shape) # (2664, 3)

# wind2m['XYZ_fortrain'] = XYZ_fortrain
# wind2m['XYZ_tes'] = XYZ_tes
# wind2m['Ws_fortrain'] = LaLoWind_fortrain[:,2]
wind2m['Ws_tes'] = LaLoWind_tes[:,2]

np.save(os.path.dirname(os.getcwd()) + '/real data windspeed/Result_data/wind2m.npy', wind2m)
print('save wind2m.npy done')
print(wind2m.keys())



'''------------------------------------- 2. XYZ_train和Ws_train的抽取 -------------------------------------'''
# 训练的时候需要：XYZ_train和Ws_train，分别从XYZ_fortrain和Ws_fortrain中抽取
# 测试的需要：XYZ_tes，已经是固定好的2664个
#
# 画图的时候需要2664个测试样本对应的：LaLoWind_tes
# 或者：lat_list = [x for x in range(-90, 91, 5)]  # 纬度
#      lon_list = [x for x in range(-180, 180, 5)]  # 经度
#      和 Ws_tes


# loadData1 = np.load(os.path.dirname(os.getcwd()) + '/real data windspeed/Result_data/wind2m.npy', allow_pickle=True)
# wind2m = loadData1.tolist()
# print(wind2m.keys())
#
# XYZ_fortrain = wind2m['XYZ_fortrain']
# Ws_fortrain = wind2m['Ws_fortrain']
# # print(XYZ_fortrain.shape) # (205272, 3)
# # print(Ws_fortrain.shape)  # (205272,)
#
#
# np.random.seed(0)
# train_sample_size = 2000
# indices = np.random.choice(XYZ_fortrain.shape[0], size = train_sample_size, replace=False)
# XYZ_train, Ws_train = XYZ_fortrain[indices], Ws_fortrain[indices]
# # print(indices)
# # print(XYZ_train)
# print(XYZ_train.shape)
# # print(Ws_train)
# print(Ws_train.shape)



'''  -----------------------------------------------  测试  ------------------------------------------------
LL=LaLoWind_tes
XYZ = LL_to_XYZ(LL)
XYZ_norm = np.linalg.norm(XYZ, axis=1)   # (t,n)
print(XYZ.shape)
print(LaLoWind_tes[1000:1002])
print(XYZ[1000:1002])
print(XYZ_norm)
# (2664, 3)
# [[-25.        140.          1.9320048]
#  [-25.        145.          2.0632577]]
# [[-0.69427204  0.58256342 -0.42261826]
#  [-0.74240388  0.51983679 -0.42261826]]
# [1. 1. 1. ... 1. 1. 1.]


[[-25.        140.          1.9320048]
[[-0.69427204  0.58256342 -0.42261826]

ss = math.cos(-25* math.pi / 180)*math.cos(140* math.pi / 180)
print(ss) # -0.6942720440148837


print(wind2m['LaLoWind_fortrain'][:5]) # (2664, 3)
print(wind2m['Ws_fortrain'][:5]) # (2664, 3)

print(wind2m['LaLoWind_tes'][:5]) # (2664, 3)
print(wind2m['Ws_tes'][:5]) # (2664, 3)
[[ -90.        -179.375        2.8299754]
 [ -90.        -178.75         2.8398638]
 [ -90.        -178.125        2.8498173]
 [ -90.        -177.5          2.8601162]
 [ -90.        -176.875        2.8706758]]
[2.8299754 2.8398638 2.8498173 2.8601162 2.8706758]
[[ -90.        -180.           2.8203518]
 [ -90.        -175.           2.90363  ]
 [ -90.        -170.           3.0019085]
 [ -90.        -165.           3.1156614]
 [ -90.        -160.           3.2459886]]
[2.8203518 2.90363   3.0019085 3.1156614 3.2459886]
'''






# wind2m_KI = {}
# np.save('/Users/liuxiaotong/Documents/machine learning/4_Spectral approach on spheres/real data windspeed/Result_data/wind2m_KI.npy', wind2m_KI)
# print('save wind2m_KI.npy done')
#
# loadData = np.load(os.path.dirname(os.getcwd()) + '/real data windspeed/Result_data/wind2m_KI.npy', allow_pickle=True)
# wind2m_KI = loadData.tolist()
# print(wind2m_KI.keys())


# wind2m_other = {}
# np.save('/Users/liuxiaotong/Documents/machine learning/4_Spectral approach on spheres/real data windspeed/Result_data/wind2m_other.npy', wind2m_other)
# print('save wind2m_other.npy done')


# loadData = np.load(os.path.dirname(os.getcwd()) + '/real data windspeed/Result_data/wind2m_other.npy', allow_pickle=True)
# wind2m_other = loadData.tolist()
# print(wind2m_other.keys())
#
#
# loadData1 = np.load(os.path.dirname(os.getcwd()) + '/real data windspeed/Result_data/wind2m.npy', allow_pickle=True)
# wind2m = loadData1.tolist()
# print(wind2m.keys())
#
# XYZ_tes = wind2m['XYZ_tes']
# Ws_tes = wind2m['Ws_tes']
# XYZ_fortrain = wind2m['XYZ_fortrain']
# Ws_fortrain = wind2m['Ws_fortrain']
#
#
# wind2m_other['XYZ_tes'] = wind2m['XYZ_tes']
# wind2m_other['Ws_tes'] = wind2m['Ws_tes']
# wind2m_other['XYZ_fortrain'] = wind2m['XYZ_fortrain']
# wind2m_other['Ws_fortrain'] = wind2m['Ws_fortrain']
#
#
# np.save(os.path.dirname(os.getcwd()) + '/real data windspeed/Result_data/wind2m_other.npy', wind2m_other)
# print('save wind2m_other.npy done')
# print(wind2m_other.keys())
# time_total = time.time() - time_start
# print('runing time:', time_total)
