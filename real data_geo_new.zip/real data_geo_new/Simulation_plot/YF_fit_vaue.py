import os, time
from Spectral_algorithms import XYZ_from_matfile, fun_rotation_mat, Predicted_KI, Predicted_KRR, \
    Predicted_KGD, Predicted_TSVD, KRR_condi_lambda, KGD_condi_step, TSVD_condi_nu, parameter_lambda_krr_forplot, \
    parameter_step_kgd_forplot, parameter_lambda_TSVD_forplot, parameter_lambda_krr
import pandas as pd
from numpy import *
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib import rcParams
import matplotlib.gridspec as gridspec
from matplotlib.ticker import FuncFormatter
time_start = time.time()
from sklearn.model_selection import train_test_split


'''-------------------------- 转移数据： 2016， tdesign， uniform的KI和TSVD的fit  --------------------------------'''
# geo_fit_value = {}
# np.save('/Users/liuxiaotong/Documents/machine learning/4_Spectral approach on spheres/real data_geo_new/Result_data/geo_fit_value.npy', geo_fit_value)
# print('save geo_fit_value.npy done')

# loadData1 = np.load(os.path.dirname(os.getcwd()) + '/Result_data/geo_fit_value.npy', allow_pickle=True)
# geo_fit_value = loadData1.tolist()
# print(geo_fit_value.keys())

'''uniform '''
# loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/geo_uniform_2016.npy', allow_pickle=True)
# geo_uniform_2016 = loadData.tolist()
# print(geo_uniform_2016.keys())

# geo_fit_value['KI_fit_YF_noi50_2016_uniform'] = geo_uniform_2016['KI_fit_YF_50']
# geo_fit_value['KI_fit_YF_noi500_2016_uniform'] = geo_uniform_2016['KI_fit_YF_500']
# geo_fit_value['TSVD_fit_YF_noi50_2016_uniform'] = geo_uniform_2016['TSVD_fit_YF_50']
# geo_fit_value['TSVD_fit_YF_noi500_2016_uniform'] = geo_uniform_2016['TSVD_fit_YF_500']


'''t-deisgn'''
# loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/geo_t63_2016.npy', allow_pickle=True)
# geo_t63_2016 = loadData.tolist()
# print(geo_t63_2016.keys())

# geo_fit_value['KI_fit_YF_noi50_2016_tdesign'] = geo_t63_2016['KI_fit_YF_50']
# geo_fit_value['KI_fit_YF_noi500_2016_tdesign'] = geo_t63_2016['KI_fit_YF_500']
# geo_fit_value['TSVD_fit_YF_noi50_2016_tdesign'] = geo_t63_2016['TSVD_fit_YF_50']
# geo_fit_value['TSVD_fit_YF_noi500_2016_tdesign'] = geo_t63_2016['TSVD_fit_YF_500']
#
# geo_fit_value['LLA_tes'] = geo_t63_2016['LLA_tes']
# geo_fit_value['YF_tes'] = np.squeeze(geo_t63_2016['YF_tes'])
#
# np.save(os.path.dirname(os.getcwd()) + '/Result_data/geo_fit_value.npy', geo_fit_value)
# print('save geo_fit_value.npy done')
# print(geo_fit_value.keys())





'''-------------------------- 5 trails 的fit values 平均  --------------------------------'''
# loadData1 = np.load(os.path.dirname(os.getcwd()) + '/Result_data/geo_fit_value.npy', allow_pickle=True)
# geo_fit_value = loadData1.tolist()
# print(geo_fit_value.keys())
#
# geo_fit_value['KI_fit_YF_noi50_2016_tdesign_mean'] = np.mean(np.array(geo_fit_value['KI_fit_YF_noi50_2016_tdesign']), axis=0)
# geo_fit_value['KI_fit_YF_noi500_2016_tdesign_mean'] = np.mean(np.array(geo_fit_value['KI_fit_YF_noi500_2016_tdesign']), axis=0)
# geo_fit_value['TSVD_fit_YF_noi50_2016_tdesign_mean'] = np.mean(np.array(geo_fit_value['TSVD_fit_YF_noi50_2016_tdesign']), axis=0)
# geo_fit_value['TSVD_fit_YF_noi500_2016_tdesign_mean'] = np.mean(np.array(geo_fit_value['TSVD_fit_YF_noi500_2016_tdesign']), axis=0)
#
# geo_fit_value['KI_fit_YF_noi50_2016_uniform_mean'] = np.mean(np.array(geo_fit_value['KI_fit_YF_noi50_2016_uniform']), axis=0)
# geo_fit_value['KI_fit_YF_noi500_2016_uniform_mean'] = np.mean(np.array(geo_fit_value['KI_fit_YF_noi500_2016_uniform']), axis=0)
# geo_fit_value['TSVD_fit_YF_noi50_2016_uniform_mean'] = np.mean(np.array(geo_fit_value['TSVD_fit_YF_noi50_2016_uniform']), axis=0)
# geo_fit_value['TSVD_fit_YF_noi500_2016_uniform_mean'] = np.mean(np.array(geo_fit_value['TSVD_fit_YF_noi500_2016_uniform']), axis=0)
#
# # print(geo_fit_value['TSVD_fit_YF_noi500_2016_uniform_mean'])
# # print(geo_fit_value['TSVD_fit_YF_noi500_2016_uniform_mean'].shape)
#
# np.save(os.path.dirname(os.getcwd()) + '/Result_data/geo_fit_value.npy', geo_fit_value)
# print('save geo_fit_value.npy done')
# print(geo_fit_value.keys())

