import os, time
from Spectral_algorithms import XYZ_from_matfile, fun_rotation_mat, Predicted_KI, Predicted_KRR, \
    Predicted_KGD, Predicted_TSVD, KRR_condi_lambda, KGD_condi_step, TSVD_condi_nu, parameter_lambda_krr_forplot, \
    parameter_step_kgd_forplot, parameter_lambda_TSVD_forplot, parameter_lambda_krr
import pandas as pd
from numpy import *
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib import rcParams
import matplotlib.gridspec as gridspec
from matplotlib.ticker import FuncFormatter
time_start = time.time()
from sklearn.model_selection import train_test_split
import seaborn as sns
import numpy as np
from numpy.random import randn
import matplotlib as mpl
import matplotlib.pyplot as plt
from scipy import stats

loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/geo_uniform_2016.npy', allow_pickle=True)
geo_uniform_2016 = loadData.tolist()
print(geo_uniform_2016.keys())
X_train = geo_uniform_2016['XYZ_train_unit']
X_test = geo_uniform_2016['XYZ_tes_unit']
YF_train = np.squeeze(geo_uniform_2016['YF_train'])
YD_train = np.squeeze(geo_uniform_2016['YD_train'])
YI_train = np.squeeze(geo_uniform_2016['YI_train'])
YF_test = np.squeeze(geo_uniform_2016['YF_tes'])
YD_test = np.squeeze(geo_uniform_2016['YD_tes'])
YI_test = np.squeeze(geo_uniform_2016['YI_tes'])

# style set 这里只是一些简单的style设置
sns.set_palette('deep', desat=.6)
sns.set_context(rc={'figure.figsize': (8, 5)})
# np.random.seed(1425)
#
# data = randn(75)


# plt.hist(YF_train)
# # plt.xlabel('RMSE of total intensity', fontsize='13')
# plt.title('Histogram of YF', fontsize='13')
# plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/f2_test_para_range/distribution_YF_uniform.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.show()



# plt.hist(YD_train)
# plt.title('Histogram of YD', fontsize='13')
# plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/f2_test_para_range/distribution_YD_uniform.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.show()

plt.hist(YD_train)
plt.title('Histogram of YD', fontsize='13')
plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/f2_test_para_range/distribution_YD_uniform.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
plt.show()

aa = np.array([1, 3, 5, 256])
bb = np.log(aa)
print(bb.shape)


# plt.hist(YI_train)
# plt.title('Histogram of YI', fontsize='13')
# plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/f2_test_para_range/distribution_YI_uniform.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.show()
#
