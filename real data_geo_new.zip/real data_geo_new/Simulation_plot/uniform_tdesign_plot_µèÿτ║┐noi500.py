import os, time
from Spectral_algorithms import XYZ_from_matfile, fun_rotation_mat, Predicted_KI, Predicted_KGD, \
    Predicted_KGD, Predicted_TSVD, KGD_condi_step, TSVD_condi_nu, parameter_lambda_krr_forplot, \
    parameter_step_kgd_forplot, parameter_lambda_TSVD_forplot, parameter_lambda_krr
import pandas as pd
from numpy import *
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib import rcParams
import matplotlib.gridspec as gridspec
from matplotlib.ticker import FuncFormatter
time_start = time.time()
from sklearn.model_selection import train_test_split
config = {
    "font.family":'Times New Roman',
    "font.size": 20,
    "mathtext.fontset":'stix',
}
rcParams.update(config)



'''  ------------------------------------  uniform 结果保存 ------------------------------------ '''
# loadData_uniform = np.load(os.path.dirname(os.getcwd()) + '/Result_data/geo_uniform_allsize.npy', allow_pickle=True)
# geo_uniform_allsize = loadData_uniform.tolist()
# print(geo_uniform_allsize.keys())
#
# # loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/geo_uniform_46.npy', allow_pickle=True)
# # geo_uniform_46 = loadData.tolist()
# # print(geo_uniform_46.keys())
# #
# #
# # geo_uniform_allsize['KI_rmse_YF_500_46'] = geo_uniform_46['KI_rmse_YF_500']
# # geo_uniform_allsize['TSVD_rmse_YF_500_46'] = geo_uniform_46['TSVD_rmse_YF_500']
#
# geo_uniform_allsize['uniform_KI_rmse_YF_mean_allsize_noi500'] = [np.mean(geo_uniform_allsize['KI_rmse_YF_500_46']), np.mean(geo_uniform_allsize['KI_rmse_YF_500_118']),
#                                                           np.mean(geo_uniform_allsize['KI_rmse_YF_500_232']), np.mean(geo_uniform_allsize['KI_rmse_YF_500_436']),
#                                                           np.mean(geo_uniform_allsize['KI_rmse_YF_500_862']), np.mean(geo_uniform_allsize['KI_rmse_YF_500_1226']),
#                                                           np.mean(geo_uniform_allsize['KI_rmse_YF_500_1654']), np.mean(geo_uniform_allsize['KI_rmse_YF_500_2016'])]
#
#
# geo_uniform_allsize['uniform_TSVD_rmse_YF_mean_allsize_noi500'] = [np.mean(geo_uniform_allsize['TSVD_rmse_YF_500_46']), np.mean(geo_uniform_allsize['TSVD_rmse_YF_500_118']),
#                                                           np.mean(geo_uniform_allsize['TSVD_rmse_YF_500_232']), np.mean(geo_uniform_allsize['TSVD_rmse_YF_500_436']),
#                                                           np.mean(geo_uniform_allsize['TSVD_rmse_YF_500_862']), np.mean(geo_uniform_allsize['TSVD_rmse_YF_500_1226']),
#                                                           np.mean(geo_uniform_allsize['TSVD_rmse_YF_500_1654']), np.mean(geo_uniform_allsize['TSVD_rmse_YF_500_2016'])]
#
#
# np.save(os.path.dirname(os.getcwd()) + '/Result_data/geo_uniform_allsize.npy', geo_uniform_allsize)
# print('save geo_uniform_allsize.npy done')
# print(geo_uniform_allsize.keys())



''' ------------------------------------ t-design 结果保存 ------------------------------------ '''
# loadData_tdesign = np.load(os.path.dirname(os.getcwd()) + '/Result_data/geo_tdesign_allsize.npy', allow_pickle=True)
# geo_tdesign_allsize = loadData_tdesign.tolist()
# print(geo_tdesign_allsize.keys())
# #
# # # loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/geo_t9_46.npy', allow_pickle=True)
# # # geo_t9_46 = loadData.tolist()
# # # print(geo_t9_46.keys())
# # #
# # # geo_tdesign_allsize['KI_rmse_YF_500_46'] = geo_t9_46['KI_rmse_YF_500']
# # # geo_tdesign_allsize['TSVD_rmse_YF_500_46'] = geo_t9_46['TSVD_rmse_YF_500']
# #
# geo_tdesign_allsize['tdesign_KI_rmse_YF_mean_allsize_noi500'] = [np.mean(geo_tdesign_allsize['KI_rmse_YF_500_46']), np.mean(geo_tdesign_allsize['KI_rmse_YF_500_118']),
#                                                           np.mean(geo_tdesign_allsize['KI_rmse_YF_500_232']),
#                                                           np.mean(geo_tdesign_allsize['KI_rmse_YF_500_436']), np.mean(geo_tdesign_allsize['KI_rmse_YF_500_862']),
#                                                           np.mean(geo_tdesign_allsize['KI_rmse_YF_500_1226']), np.mean(geo_tdesign_allsize['KI_rmse_YF_500_1654']),
#                                                           np.mean(geo_tdesign_allsize['KI_rmse_YF_500_2016'])]
#
# geo_tdesign_allsize['tdesign_TSVD_rmse_YF_mean_allsize_noi500'] = [np.mean(geo_tdesign_allsize['TSVD_rmse_YF_500_46']), np.mean(geo_tdesign_allsize['TSVD_rmse_YF_500_118']),
#                                                           np.mean(geo_tdesign_allsize['TSVD_rmse_YF_500_232']),
#                                                           np.mean(geo_tdesign_allsize['TSVD_rmse_YF_500_436']), np.mean(geo_tdesign_allsize['TSVD_rmse_YF_500_862']),
#                                                           np.mean(geo_tdesign_allsize['TSVD_rmse_YF_500_1226']), np.mean(geo_tdesign_allsize['TSVD_rmse_YF_500_1654']),
#                                                           np.mean(geo_tdesign_allsize['TSVD_rmse_YF_500_2016'])]
#
#
# np.save(os.path.dirname(os.getcwd()) + '/Result_data/geo_tdesign_allsize.npy', geo_tdesign_allsize)
# print('save geo_tdesign_allsize.npy done')
# print(geo_tdesign_allsize.keys())



'''1.2. RMSE 为了画折线图---------------------------------------------------------------'''
loadData_tdesign = np.load(os.path.dirname(os.getcwd()) + '/Result_data/geo_tdesign_allsize.npy', allow_pickle=True)
geo_tdesign_allsize = loadData_tdesign.tolist()
print(geo_tdesign_allsize.keys())

loadData_uniform = np.load(os.path.dirname(os.getcwd()) + '/Result_data/geo_uniform_allsize.npy', allow_pickle=True)
geo_uniform_allsize = loadData_uniform.tolist()
print(geo_uniform_allsize.keys())


tdesign_KI_rmse_YF_mean_allsize = geo_tdesign_allsize['tdesign_KI_rmse_YF_mean_allsize_noi500']
tdesign_TSVD_rmse_YF_mean_allsize = geo_tdesign_allsize['tdesign_TSVD_rmse_YF_mean_allsize_noi500']

uniform_KI_rmse_YF_mean_allsize = geo_uniform_allsize['uniform_KI_rmse_YF_mean_allsize_noi500']
uniform_TSVD_rmse_YF_mean_allsize = geo_uniform_allsize['uniform_TSVD_rmse_YF_mean_allsize_noi500']


print(tdesign_KI_rmse_YF_mean_allsize)
print(uniform_KI_rmse_YF_mean_allsize)
print(tdesign_TSVD_rmse_YF_mean_allsize)
print(uniform_TSVD_rmse_YF_mean_allsize)

data_size = [46, 118, 232, 436, 862, 1226, 1654, 2016]

'''1.2.1 YF ----------------------------------'''
fig = plt.figure(tight_layout=True)
gs = gridspec.GridSpec(1, 1)
ax = fig.add_subplot(gs[0, 0])
ax.grid(linestyle='-.', axis="y")

ax.plot(data_size, uniform_KI_rmse_YF_mean_allsize, c='royalblue', marker='o',  linestyle='--', linewidth=1.2, markersize=6)
ax.plot(data_size, uniform_TSVD_rmse_YF_mean_allsize, c='royalblue', marker='o', markersize=6,  linestyle='-', linewidth=1.2)
ax.plot(data_size, tdesign_KI_rmse_YF_mean_allsize, c='brown', marker='s',  linestyle='--', linewidth=1.2, markersize=6)
ax.plot(data_size, tdesign_TSVD_rmse_YF_mean_allsize, c='brown', marker='s', markersize=6,  linestyle='-', linewidth=1.2)

ax.set_xlabel('|D|', fontsize='20')
ax.set_ylabel('RMSE of total intensity', fontsize='20')
plt.yscale('log')
plt.ylim(100, 28000)
plt.legend(['KI(uniform)', 'Cut-off(uniform)', 'KI($t$-design)','Cut-off($t$-design)'], loc='upper right', fontsize='16')
plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/f2/compare_datasize_YF_noi500.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
plt.show()







