import os, time
from Spectral_algorithms import XYZ_from_matfile, fun_rotation_mat, Predicted_KI, Predicted_KGD, \
    Predicted_KGD, Predicted_TSVD, KGD_condi_step, TSVD_condi_nu, parameter_lambda_krr_forplot, \
    parameter_step_kgd_forplot, parameter_lambda_TSVD_forplot, parameter_lambda_krr
import pandas as pd
from numpy import *
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib import rcParams
import matplotlib.gridspec as gridspec
from matplotlib.ticker import FuncFormatter
time_start = time.time()
from sklearn.model_selection import train_test_split
config = {
    "font.family":'Times New Roman',
    "font.size": 17,
    "mathtext.fontset":'stix',
}
rcParams.update(config)



loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/geo_uniform_2016.npy', allow_pickle=True)
geo_uniform_2016 = loadData.tolist()
print(geo_uniform_2016.keys())


loadData2 = np.load(os.path.dirname(os.getcwd()) + '/Result_data/geo_t63_2016.npy', allow_pickle=True)
geo_t63_2016 = loadData2.tolist()
print(geo_t63_2016.keys())

## uniform ---------------------
# YF
uniform_KI_rmse_noi50_mean = np.mean(geo_uniform_2016['KI_rmse_YF_50'])
uniform_KRR_rmse_noi50_mean = np.mean(geo_uniform_2016['KRR_rmse_YF_50'])
uniform_KGD_rmse_noi50_mean = np.mean(geo_uniform_2016['KGD_rmse_YF_50'])
uniform_TSVD_rmse_noi50_mean = np.mean(geo_uniform_2016['TSVD_rmse_YF_50'])

uniform_KI_rmse_noi500_mean = np.mean(geo_uniform_2016['KI_rmse_YF_500'])
uniform_KRR_rmse_noi500_mean = np.mean(geo_uniform_2016['KRR_rmse_YF_500'])
uniform_KGD_rmse_noi500_mean = np.mean(geo_uniform_2016['KGD_rmse_YF_500'])
uniform_TSVD_rmse_noi500_mean = np.mean(geo_uniform_2016['TSVD_rmse_YF_500'])


## tdesign ---------------------
# YF
tdesign_KI_rmse_noi50_mean = np.mean(geo_t63_2016['KI_rmse_YF_50'])
tdesign_KRR_rmse_noi50_mean = np.mean(geo_t63_2016['KRR_rmse_YF_50'])
tdesign_KGD_rmse_noi50_mean = np.mean(geo_t63_2016['KGD_rmse_YF_50'])
tdesign_TSVD_rmse_noi50_mean = np.mean(geo_t63_2016['TSVD_rmse_YF_50'])

tdesign_KI_rmse_noi500_mean = np.mean(geo_t63_2016['KI_rmse_YF_500'])
tdesign_KRR_rmse_noi500_mean = np.mean(geo_t63_2016['KRR_rmse_YF_500'])
tdesign_KGD_rmse_noi500_mean = np.mean(geo_t63_2016['KGD_rmse_YF_500'])
tdesign_TSVD_rmse_noi500_mean = np.mean(geo_t63_2016['TSVD_rmse_YF_500'])




'''1.1.1 YF ----------------------------------'''
fig = plt.figure(tight_layout=True)
colors_uniform = ['tan', 'tan']
colors_tdesign = ['brown', 'brown']

data_uniform_noi50 = [uniform_KI_rmse_noi50_mean, uniform_KRR_rmse_noi50_mean, uniform_KGD_rmse_noi50_mean, uniform_TSVD_rmse_noi50_mean]
data_tdesign_noi50 = [tdesign_KI_rmse_noi50_mean, tdesign_KRR_rmse_noi50_mean, tdesign_KGD_rmse_noi50_mean, tdesign_TSVD_rmse_noi50_mean]

data_uniform_noi500 = [uniform_KI_rmse_noi500_mean, uniform_KRR_rmse_noi500_mean, uniform_KGD_rmse_noi500_mean, uniform_TSVD_rmse_noi500_mean]
data_tdesign_noi500 = [tdesign_KI_rmse_noi500_mean, tdesign_KRR_rmse_noi500_mean, tdesign_KGD_rmse_noi500_mean, tdesign_TSVD_rmse_noi500_mean]

data_uniform_noichange = [uniform_KI_rmse_noi500_mean-uniform_KI_rmse_noi50_mean, uniform_KRR_rmse_noi500_mean-uniform_KRR_rmse_noi50_mean,
                          uniform_KGD_rmse_noi500_mean-uniform_KGD_rmse_noi50_mean, uniform_TSVD_rmse_noi500_mean-uniform_TSVD_rmse_noi50_mean]
data_tdesign_noichange = [tdesign_KI_rmse_noi500_mean-tdesign_KI_rmse_noi50_mean, tdesign_KRR_rmse_noi500_mean-tdesign_KRR_rmse_noi50_mean,
                          tdesign_KGD_rmse_noi500_mean-tdesign_KGD_rmse_noi50_mean, tdesign_TSVD_rmse_noi500_mean-tdesign_TSVD_rmse_noi50_mean]



bar_width = 0.86
x_range = np.arange(0,8,2)
rects0= plt.bar(x_range, data_uniform_noi500, align='center', alpha=0.7, color=colors_uniform, label='uniform', width=0.86)
rects1= plt.bar(x_range + bar_width, data_tdesign_noi500, align='center', alpha=0.7, color=colors_tdesign, label='$t$-design', width=0.86)

for a,b in zip(x_range,data_uniform_noi500):
    plt.text(a,b,'%.2f'%b,ha='center',va='bottom',fontsize=13)
for a1,b1 in zip(x_range+ bar_width,data_tdesign_noi500):
    plt.text(a1,b1,'%.2f'%b1,ha='center',va='bottom',fontsize=13)

plt.ylabel('RMSE of total intensity', fontsize='17')
# plt.xlabel('|D| = 2016, $\sigma = 50$', fontsize='13')
subjects = ('KI', 'Tikhonov', 'Landweber', 'Cut-off')
plt.xticks(x_range+ 0.5*bar_width, subjects)
plt.legend(loc='upper right')
plt.yscale('log')
plt.ylim(100, 2000)
# plt.title('Comparison of different approaches', fontsize='13')
plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/f2/Compare_histogram_YF_2016_noi500.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
plt.show()









# bar_width = 0.8
# x_range = np.arange(0,8,2)
# rects0= plt.bar(x_range, data_uniform_noichange, align='center', alpha=0.7, color=colors_uniform, label='uniform', width=0.8)
# rects1= plt.bar(x_range + bar_width, data_tdesign_noichange, align='center', alpha=0.7, color=colors_tdesign, label='$t$-design', width=0.8)
#
# for a,b in zip(x_range,data_uniform_noichange):
#     plt.text(a,b,'%.3f'%b,ha='center',va='bottom',fontsize=10)
# for a1,b1 in zip(x_range+ bar_width,data_tdesign_noichange):
#     plt.text(a1,b1,'%.3f'%b1,ha='center',va='bottom',fontsize=10)
#
# plt.ylabel('$\\Delta$ RMSE', fontsize='13')
# # plt.xlabel('|D| = 2016, $\sigma = 50$', fontsize='13')
# subjects = ('KI', 'Tikhonov', 'Landweber', 'Cut-off')
# plt.xticks(x_range+ 0.5*bar_width, subjects)
# plt.legend(loc='upper right')
# plt.yscale('log')
# plt.ylim(50, 1500)
# plt.title('$\\Delta$ RMSE of total intensity under different noise level', fontsize='13')
# plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/f2/Compare_histogram_YF_2016_noichange.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.show()
