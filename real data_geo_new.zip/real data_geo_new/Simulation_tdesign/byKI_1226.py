import os, time
from Spectral_algorithms import XYZ_from_matfile, fun_rotation_mat, Predicted_KI, Predicted_KRR, \
    Predicted_KGD, Predicted_TSVD, KRR_condi_lambda, KGD_condi_step, TSVD_condi_nu, parameter_lambda_krr_forplot, \
    parameter_step_kgd_forplot, parameter_lambda_TSVD_forplot, parameter_lambda_krr
import pandas as pd
from numpy import *
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib import rcParams
import matplotlib.gridspec as gridspec
from matplotlib.ticker import FuncFormatter
time_start = time.time()
from sklearn.model_selection import train_test_split


loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/geo_t49_1226.npy', allow_pickle=True)
geo_t49_1226 = loadData.tolist()
print(geo_t49_1226.keys())
X_train = geo_t49_1226['XYZ_train_unit']
X_test = geo_t49_1226['XYZ_tes_unit']
YF_train = np.squeeze(geo_t49_1226['YF_train'])
YF_test = np.squeeze(geo_t49_1226['YF_tes'])


# ------------------------------------------------------------------------------------------------------------
'''0. set up'''
f, d = 5, 3  # folds of corss-validation; dimension of the input X
trails = 5
print(YF_train.shape[0])
std_YF_noise = 500


'''1: RMSE for 5 trails, 5-cv '''
'''条件数检测
条件数小的时候四个算法差别不大，条件大时提升才明显'''
data_sizes, condis_YF, rmses_YF, rmses_YD, rmses_YI, fits_YF, fits_YD, fits_YI = [], [], [], [], [], [], [], []
for th in range(trails):
    np.random.seed(th)
    print('                                                                                  trail:', th + 1)
    noise_YF = np.random.normal(0, std_YF_noise, len(YF_train))
    YF_train = YF_train + noise_YF

    Pred_YF = Predicted_KI(X_train, YF_train, X_test, YF_test, d)
    fits_YF.append(Pred_YF[0])
    rmses_YF.append(Pred_YF[1])
    condis_YF.append(Pred_YF[2])
    print('rmses_YF:', rmses_YF)


geo_t49_1226['KI_fit_YF_500'] = fits_YF
geo_t49_1226['KI_rmse_YF_500'] = rmses_YF
np.save(os.path.dirname(os.getcwd()) + '/Result_data/geo_t49_1226.npy', geo_t49_1226)
print('save geo_t49_1226.npy done')
print(geo_t49_1226.keys())
time_total = time.time() - time_start
print('runing time:', time_total)


print(geo_t49_1226['KI_rmse_YF_500'])
# print(geo_t49_1226['KI_rmse_YD'])
# print(geo_t49_1226['KI_rmse_YI'])
# print(geo_t49_1226['KI_condi'])




'''2. 检验结果'''
# print('---------------------- RMSE of YF')
# print('KI:\n', geo_t49_1226['KI_rmse_YF_50'])
# print('KRR:\n', geo_t49_1226['KRR_rmse_YF_50'])
# print('TSVD:\n', geo_t49_1226['TSVD_rmse_YF_50'])
# print('KGD:\n', geo_t49_1226['KGD_rmse_YF_50'])
# print('mean RMSE of KI in 5 trails:', np.mean(geo_t49_1226['KI_rmse_YF_50']))
# print('mean RMSE of KRR in 5 trails:', np.mean(geo_t49_1226['KRR_rmse_YF_50']))
# print('mean RMSE of TSVD in 5 trails:', np.mean(geo_t49_1226['TSVD_rmse_YF_50']))
# print('mean RMSE of KGD in 5 trails:', np.mean(geo_t49_1226['KGD_rmse_YF_50']))
