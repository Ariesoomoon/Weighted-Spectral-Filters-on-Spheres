import os, time
from Spectral_algorithms import XYZ_from_matfile, fun_rotation_mat, Predicted_KI, Predicted_KRR, \
    Predicted_KGD, Predicted_TSVD, KRR_condi_lambda, KGD_condi_step, TSVD_condi_nu, parameter_lambda_krr_forplot, \
    parameter_step_kgd_forplot, parameter_lambda_TSVD_forplot, parameter_lambda_krr
import pandas as pd
from numpy import *
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib import rcParams
import matplotlib.gridspec as gridspec
from matplotlib.ticker import FuncFormatter
time_start = time.time()
from sklearn.model_selection import train_test_split


loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/geo_t63_2016.npy', allow_pickle=True)
geo_t63_2016 = loadData.tolist()
print(geo_t63_2016.keys())
X_train = geo_t63_2016['XYZ_train_unit']
X_test = geo_t63_2016['XYZ_tes_unit']
YF_train = np.squeeze(geo_t63_2016['YF_train'])
YF_test = np.squeeze(geo_t63_2016['YF_tes'])


# ------------------------------------------------------------------------------------------------------------
'''0. set up'''
f, d = 5, 3  # folds of corss-validation; dimension of the input X
trails = 5
print(YF_train.shape[0])

# std_YF = np.std(YF_train, ddof=1)
# print(std_YF)
# # 11192.919180291137
# std_YF_noise = 0.005*std_YF
# print(std_YF_noise)
# # 55.96459590145569

std_YF_noise = 50



'''1: RMSE for 5 trails, 5-cv '''
'''条件数检测
条件数小的时候四个算法差别不大，条件大时提升才明显'''
data_sizes, condis_YF, rmses_YF, rmses_YD, rmses_YI, fits_YF, fits_YD, fits_YI = [], [], [], [], [], [], [], []
for th in range(trails):
    np.random.seed(th)
    print('                                                                                  trail:', th + 1)
    noise_YF = np.random.normal(0, std_YF_noise, len(YF_train))
    YF_train = YF_train + noise_YF

    Pred_YF = Predicted_KI(X_train, YF_train, X_test, YF_test, d)
    fits_YF.append(Pred_YF[0])
    rmses_YF.append(Pred_YF[1])
    condis_YF.append(Pred_YF[2])


    print('rmses_YF:', rmses_YF)
    # print('condis:', condis_YF)
    # print('data_sizes:', data_sizes)

geo_t63_2016['KI_fit_YF_50'] = fits_YF
geo_t63_2016['KI_rmse_YF_50'] = rmses_YF
geo_t63_2016['KI_condi'] = condis_YF
np.save(os.path.dirname(os.getcwd()) + '/Result_data/geo_t63_2016.npy', geo_t63_2016)
print('save geo_t63_2016.npy done')
print(geo_t63_2016.keys())
time_total = time.time() - time_start
print('runing time:', time_total)


print(geo_t63_2016['KI_rmse_YF_50'])
print('condi:', np.mean(geo_t63_2016['KI_condi'])) # condi: 47124.942758265686








'''2.1 检验结果 -- noise 50'''
# print('---------------------- RMSE of YF, when std of noise is 50')
# print('KI:\n', geo_t63_2016['KI_rmse_YF_50'])
# print('KRR:\n', geo_t63_2016['KRR_rmse_YF_50'])
# print('TSVD:\n', geo_t63_2016['TSVD_rmse_YF_50'])
# print('KGD:\n', geo_t63_2016['KGD_rmse_YF_50'])
# print('mean RMSE of KI in 5 trails:', np.mean(geo_t63_2016['KI_rmse_YF_50']))
# print('mean RMSE of KRR in 5 trails:', np.mean(geo_t63_2016['KRR_rmse_YF_50']))
# print('mean RMSE of TSVD in 5 trails:', np.mean(geo_t63_2016['TSVD_rmse_YF_50']))
# print('mean RMSE of KGD in 5 trails:', np.mean(geo_t63_2016['KGD_rmse_YF_50']))


'''2.2 检验结果 -- noise 500'''
# print('---------------------- RMSE of YF, when std of noise is 500')
# print('KI:\n', geo_t63_2016['KI_rmse_YF_500'])
# print('KRR:\n', geo_t63_2016['KRR_rmse_YF_500'])
# print('TSVD:\n', geo_t63_2016['TSVD_rmse_YF_500'])
# print('KGD:\n', geo_t63_2016['KGD_rmse_YF_500'])
# print('mean RMSE of KI in 5 trails:', np.mean(geo_t63_2016['KI_rmse_YF_500']))
# print('mean RMSE of KRR in 5 trails:', np.mean(geo_t63_2016['KRR_rmse_YF_500']))
# print('mean RMSE of TSVD in 5 trails:', np.mean(geo_t63_2016['TSVD_rmse_YF_500']))
# print('mean RMSE of KGD in 5 trails:', np.mean(geo_t63_2016['KGD_rmse_YF_500']))





'''转换数据'''

# loadData3 = np.load(os.path.dirname(os.getcwd()) + '/Result_data/geo_t63_2016_forkrr.npy', allow_pickle=True)
# geo_t63_2016_forkrr = loadData3.tolist()
# print(geo_t63_2016_forkrr.keys())
#
#
# loadData1 = np.load(os.path.dirname(os.getcwd()) + '/Result_data/geo_t63_2016_forkgd.npy', allow_pickle=True)
# geo_t63_2016_forkgd = loadData1.tolist()
# print(geo_t63_2016_forkgd.keys())
#
# loadData2 = np.load(os.path.dirname(os.getcwd()) + '/Result_data/geo_t63_2016_fortsvd.npy', allow_pickle=True)
# geo_t63_2016_fortsvd = loadData2.tolist()
# print(geo_t63_2016_fortsvd.keys())
#
# geo_t63_2016['KGD_rmse_YF_500'] = geo_t63_2016_forkgd['KGD_rmse_YF_500']
# geo_t63_2016['step_YF_KGD_500'] = geo_t63_2016_forkgd['step_YF_KGD_500']
# geo_t63_2016['KGD_fit_YF_500'] = geo_t63_2016_forkgd['KGD_fit_YF_500']
#
#
# geo_t63_2016['KRR_rmse_YF_500'] = geo_t63_2016_forkrr['KRR_rmse_YF_500']
# geo_t63_2016['lambda_YF_KRR_500'] = geo_t63_2016_forkrr['lambda_YF_KRR_500']
# geo_t63_2016['KRR_fit_YF_500'] = geo_t63_2016_forkrr['KRR_fit_YF_500']
#
#
# geo_t63_2016['TSVD_rmse_YF_500'] = geo_t63_2016_fortsvd['TSVD_rmse_YF_500']
# geo_t63_2016['lambda_YF_TSVD_500'] = geo_t63_2016_fortsvd['lambda_YF_TSVD_500']
# geo_t63_2016['TSVD_fit_YF_500'] = geo_t63_2016_fortsvd['TSVD_fit_YF_500']
#
# np.save(os.path.dirname(os.getcwd()) + '/Result_data/geo_t63_2016.npy', geo_t63_2016)
# print('save geo_t63_2016.npy done')
# print(geo_t63_2016.keys())
# time_total = time.time() - time_start
# print('runing time:', time_total)










