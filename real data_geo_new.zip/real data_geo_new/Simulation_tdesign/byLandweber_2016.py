import os, time
from Spectral_algorithms import XYZ_from_matfile, fun_rotation_mat, Predicted_KI, Predicted_KRR, \
    Predicted_KGD, Predicted_TSVD, KRR_condi_lambda, KGD_condi_step, TSVD_condi_nu, parameter_lambda_krr_forplot, \
    parameter_step_kgd_forplot, parameter_lambda_TSVD_forplot, parameter_lambda_krr, parameter_step_kgd, RMSE_parameter_kgd
import pandas as pd
from numpy import *
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib import rcParams
import matplotlib.gridspec as gridspec
from sklearn.model_selection import train_test_split
from matplotlib.ticker import FuncFormatter
time_start = time.time()
config = {
    "font.family":'Times New Roman',
    "font.size": 13,
#     "mathtext.fontset":'stix',
}
rcParams.update(config)



loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/geo_t63_2016_forkgd.npy', allow_pickle=True)
geo_t63_2016_forkgd = loadData.tolist()
print(geo_t63_2016_forkgd.keys())

X_train = geo_t63_2016_forkgd['XYZ_train_unit']
YF_train = np.squeeze(geo_t63_2016_forkgd['YF_train'])
X_test = geo_t63_2016_forkgd['XYZ_tes_unit']
YF_test = np.squeeze(geo_t63_2016_forkgd['YF_tes'])



'''0. set up'''
f, d = 5, 3  # folds of corss-validation; dimension of the input X
trails = 5
std_YF_noise = 500
std_YD_noise = 1
std_YI_noise = 2.5


''' 2. KGD makes the RMSE(prediction error) smaller. 5 trail, 5-cv'''
'''2.1: test first the range the optimal regularization parameter may located in, 1 trail, 5-cv'''
for th in range(1):
    np.random.seed(th)
    print('                                                                                  trail:', th + 1)
    noise_YF = np.random.normal(0, std_YF_noise, len(YF_train))
    YF_train = YF_train + noise_YF


pred_YF = parameter_step_kgd_forplot(X_train, YF_train, f, d)
errors_YF, steps_YF = pred_YF[0], pred_YF[1]

fig = plt.figure(tight_layout=True)
gs = gridspec.GridSpec(1, 1)
ax = fig.add_subplot(gs[0, 0])
ax.grid(linestyle='-.')
ax.plot(steps_YF[3:], errors_YF[3:], c='black', linestyle='-.', linewidth=1.4)
ax.set_xlabel('$\\mu$ (total intensity)', fontsize='13')
ax.set_ylabel('RMSE of YF (uniform)', fontsize='13')
plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/f2_test_para_range/KGD_YF_cv_test_t63_noi05.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
plt.show()
time_total = time.time() - time_start
print('runing time:', time_total)

geo_t63_2016_forkgd['cv_errors_YF_KGD'] = errors_YF
geo_t63_2016_forkgd['cv_steps_YF_KGD'] = steps_YF
np.save(os.path.dirname(os.getcwd()) + '/Result_data/geo_t63_2016_forkgd.npy', geo_t63_2016_forkgd)
print('save geo_t63_2016_forkgd.npy done')
print(geo_t63_2016_forkgd.keys())



# loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/geo_t63_2016_forkgd.npy', allow_pickle=True)
# geo_t63_2016_forkgd = loadData.tolist()
# print(geo_t63_2016_forkgd.keys())
# steps_YF = geo_t63_2016_forkgd['cv_steps_YF_KGD']
# errors_YF = geo_t63_2016_forkgd['cv_errors_YF_KGD']
# print(steps_YF)
# print(errors_YF)
#
# fig = plt.figure(tight_layout=True)
# gs = gridspec.GridSpec(1, 1)
# ax = fig.add_subplot(gs[0, 0])
# ax.grid(linestyle='-.')
# ax.plot(steps_YF[:3], errors_YF[:3], c='black', linestyle='-.', linewidth=1.4)
# ax.set_xlabel('$\\mu$ (total intensity)', fontsize='13')
# ax.set_ylabel('RMSE of YF (t-design)', fontsize='13')
# plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/f2_test_para_range/KGD_YF_cv_test_t63_noi05.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.show()
# time_total = time.time() - time_start
# print('runing time:', time_total)




'''2.2: RMSE for 5 trails, 5-cv '''
fits_YF, fits_YD, fits_YI = [], [], []
rmses_kgd_YF, rmses_kgd_YD, rmses_kgd_YI, step_opt_YFs, step_opt_YDs, step_opt_YIs = [], [], [], [], [], []
for th in range(trails):
    np.random.seed(th)
    print('                                                                                  trail:', th + 1)
    noise_YF = np.random.normal(0, std_YF_noise, len(YF_train))
    YF_train = YF_train + noise_YF

    step_opt_YF = parameter_step_kgd(X_train, YF_train, f, d)
    Pred_result_YF = Predicted_KGD(X_train, YF_train, X_test, YF_test, d, step_opt_YF)
    Pred_YF = Pred_result_YF[1]
    fits_YF.append(Pred_result_YF[0])

    rmses_kgd_YF.append(Pred_YF)
    step_opt_YFs.append(step_opt_YF)
    print('rmses_kgd_YF:', rmses_kgd_YF)

    time_total = time.time() - time_start
    print('runing time for 1 trail:', time_total)

geo_t63_2016_forkgd['KGD_rmse_YF_500'] = rmses_kgd_YF
geo_t63_2016_forkgd['step_YF_KGD_500'] = step_opt_YFs
geo_t63_2016_forkgd['KGD_fit_YF_500'] = fits_YF
np.save(os.path.dirname(os.getcwd()) + '/Result_data/geo_t63_2016_forkgd.npy', geo_t63_2016_forkgd)
print('save geo_t63_2016_forkgd.npy done')
print(geo_t63_2016_forkgd.keys())
time_total = time.time() - time_start
print('runing time:', time_total)






