import os, time
from Spectral_algorithms import XYZ_from_matfile, fun_rotation_mat, Predicted_KI, Predicted_KRR, \
    Predicted_KGD, Predicted_TSVD, KRR_condi_lambda, KGD_condi_step, TSVD_condi_nu, parameter_lambda_krr_forplot, \
    parameter_step_kgd_forplot, parameter_lambda_TSVD_forplot, parameter_lambda_krr, RMSE_parameter_krr, RMSE_parameter_kgd, RMSE_parameter_tsvd
import pandas as pd
from numpy import *
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib import rcParams
import matplotlib.gridspec as gridspec
from sklearn.model_selection import train_test_split
from matplotlib.ticker import FuncFormatter
time_start = time.time()
config = {
    "font.family":'Times New Roman',
    "font.size": 13,
#     "mathtext.fontset":'stix',
}
rcParams.update(config)


loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/geo_uniform.npy', allow_pickle=True)
geo_uniform = loadData.tolist()
print(geo_uniform.keys())

X_train = geo_uniform['XYZ_train_unit']
# YF_train = np.squeeze(geo_uniform['YF_train_unit'])
# YD_train = np.squeeze(geo_uniform['YD_train_unit'])
# YI_train = np.squeeze(geo_uniform['YI_train_unit'])
YF_train = np.squeeze(geo_uniform['YF_train'])
YD_train = np.squeeze(geo_uniform['YD_train'])
YI_train = np.squeeze(geo_uniform['YI_train'])
X_test = geo_uniform['XYZ_tes_unit']
# YF_test = np.squeeze(geo_uniform['YF_tes_unit'])
# YD_test = np.squeeze(geo_uniform['YD_tes_unit'])
# YI_test = np.squeeze(geo_uniform['YI_tes_unit'])
YF_test = np.squeeze(geo_uniform['YF_tes'])
YD_test = np.squeeze(geo_uniform['YD_tes'])
YI_test = np.squeeze(geo_uniform['YI_tes'])


print(np.max(YF_train))


'''0. set up'''
func = 'f2'  # from paper "DIVIDE AND CONQUER LEAST SQAURES FOR UNCERTAINTY OF KERNEL INTERPOLATION ON SPHERES"
f, d = 5, 3  # folds of corss-validation; dimension of the input X
trails = 5


''' 2. KRR makes the RMSE(prediction error) smaller. 5 trail, 5-cv'''
'''2.1: test first the range the optimal regularization parameter may located in, 1 trail, 5-cv'''
# for th in range(1):
#     np.random.seed(th)
#     print('                                                                                  trail:', th + 1)
#     noise = np.random.normal(0, 0.1, YF_train.shape[0])
#
#     YF_train = YF_train + noise
#     YD_train = YD_train + noise
#     YI_train = YI_train + noise
#
#
# pred_YF = parameter_lambda_krr_forplot(X_train, YF_train, f, d)
# pred_YD = parameter_lambda_krr_forplot(X_train, YD_train, f, d)
# pred_YI = parameter_lambda_krr_forplot(X_train, YI_train, f, d)
#
# errors_YF, lambdas_YF = pred_YF[0], pred_YF[1]
# errors_YD, lambdas_YD = pred_YD[0], pred_YD[1]
# errors_YI, lambdas_YI = pred_YI[0], pred_YI[1]
#
# geo_uniform['cv_errors_YF_KRR'] = errors_YF
# geo_uniform['cv_lambdas_YF_KRR'] = lambdas_YF
# geo_uniform['cv_errors_YD_KRR'] = errors_YD
# geo_uniform['cv_lambdas_YD_KRR'] = lambdas_YD
# geo_uniform['cv_errors_YI_KRR'] = errors_YI
# geo_uniform['cv_lambdas_YI_KRR'] = lambdas_YI
# np.save(os.path.dirname(os.getcwd()) + '/Result_data/geo_uniform.npy', geo_uniform)
# print('save geo_uniform.npy done')
# print(geo_uniform.keys())


# loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/geo_uniform.npy', allow_pickle=True)
# geo_uniform = loadData.tolist()
# print(geo_uniform.keys())
# lambdas_YF = geo_uniform['cv_lambdas_YF_KRR']
# errors_YF = geo_uniform['cv_errors_YF_KRR']
# lambdas_YD = geo_uniform['cv_lambdas_YD_KRR']
# errors_YD = geo_uniform['cv_errors_YD_KRR']
# lambdas_YI = geo_uniform['cv_lambdas_YI_KRR']
# errors_YI = geo_uniform['cv_errors_YI_KRR']
#
# print(lambdas_YF)

#
# fig = plt.figure(tight_layout=True)
# gs = gridspec.GridSpec(1, 1)
# ax = fig.add_subplot(gs[0, 0])
# ax.grid(linestyle='-.')
# ax.plot(lambdas_YF, errors_YF, c='black', linestyle='-.', linewidth=1.4)
# ax.set_xlabel('$\\mu$ (total intensity)', fontsize='13')
# ax.set_ylabel('RMSE (uniform)', fontsize='13')
# plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/f2_test_para_range/KRR_YF_cv_test.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.show()
# time_total = time.time() - time_start
# print('runing time:', time_total)
#
# fig = plt.figure(tight_layout=True)
# gs = gridspec.GridSpec(1, 1)
# ax = fig.add_subplot(gs[0, 0])
# ax.grid(linestyle='-.')
# ax.plot(lambdas_YD, errors_YD, c='black', linestyle='-.', linewidth=1.4)
# ax.set_xlabel('$\\mu$ (declination)', fontsize='13')
# ax.set_ylabel('RMSE (uniform)', fontsize='13')
# plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/f2_test_para_range/KRR_YD_cv_test.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.show()
# time_total = time.time() - time_start
# print('runing time:', time_total)
#
# fig = plt.figure(tight_layout=True)
# gs = gridspec.GridSpec(1, 1)
# ax = fig.add_subplot(gs[0, 0])
# ax.grid(linestyle='-.')
# ax.plot(lambdas_YI, errors_YI, c='black', linestyle='-.', linewidth=1.4)
# ax.set_xlabel('$\\mu$ (inclination)', fontsize='13')
# ax.set_ylabel('RMSE (uniform)', fontsize='13')
# plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/f2_test_para_range/KRR_YI_cv_test.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.show()
# time_total = time.time() - time_start
# print('runing time:', time_total)





'''2.2: RMSE for 5 trails, 5-cv '''
# rmses_krr_YF, rmses_krr_YD, rmses_krr_YI, lambda_opt_YFs, lambda_opt_YDs, lambda_opt_YIs = [], [], [], [], [], []
# for th in range(trails):
#     np.random.seed(th)
#     print('                                                                                  trail:', th + 1)
#     noise = np.random.normal(0, 0.1, YF_train.shape[0])
#
#     YF_train = YF_train + noise
#     YD_train = YD_train + noise
#     YI_train = YI_train + noise
#
#
#     # KRR
#     lambda_opt_YF = parameter_lambda_krr(X_train, YF_train, f, d)
#     Pred_YF = Predicted_KRR(X_train, YF_train, X_test, YF_test, d, lambda_opt_YF)[1]
#
#     lambda_opt_YD = parameter_lambda_krr(X_train, YD_train, f, d)
#     Pred_YD = Predicted_KRR(X_train, YD_train, X_test, YD_test, d, lambda_opt_YD)[1]
#
#     lambda_opt_YI = parameter_lambda_krr(X_train, YI_train, f, d)
#     Pred_YI = Predicted_KRR(X_train, YI_train, X_test, YI_test, d, lambda_opt_YI)[1]
#
#     print('original lambda_YF_KRR:', geo_uniform['lambda_YF_KRR'][th])
#     print('lambda_opt_YF:', lambda_opt_YF)
#
#     print('original lambda_YD_KRR:', geo_uniform['lambda_YD_KRR'][th])
#     print('lambda_opt_YD:', lambda_opt_YD)
#
#     print('original lambda_YI_KRR:', geo_uniform['lambda_YI_KRR'][th])
#     print('lambda_opt_YI:', lambda_opt_YI)


#     rmses_krr_YF.append(Pred_YF)
#     lambda_opt_YFs.append(lambda_opt_YF)
#     print('rmses_krr_YF:', rmses_krr_YF)
#
#     rmses_krr_YD.append(Pred_YD)
#     lambda_opt_YDs.append(lambda_opt_YD)
#     print('rmses_krr_YD:', rmses_krr_YD)
#
#     rmses_krr_YI.append(Pred_YI)
#     lambda_opt_YIs.append(lambda_opt_YI)
#     print('rmses_krr_YI:', rmses_krr_YI)
#
#     time_total = time.time() - time_start
#     print('runing time for 1 trail:', time_total)
#
#
# geo_uniform['KRR_rmse_YF'] = rmses_krr_YF
# geo_uniform['KRR_rmse_YD'] = rmses_krr_YD
# geo_uniform['KRR_rmse_YI'] = rmses_krr_YI
# geo_uniform['lambda_YF_KRR'] = lambda_opt_YFs
# geo_uniform['lambda_YD_KRR'] = lambda_opt_YDs
# geo_uniform['lambda_YI_KRR'] = lambda_opt_YIs
#
# np.save(os.path.dirname(os.getcwd()) + '/Result_data/geo_uniform.npy', geo_uniform)
# print('save geo_uniform.npy done')
# print(geo_uniform.keys())
# time_total = time.time() - time_start
# print('runing time:', time_total)









'''3.调取最优的参数对应的预测值fit'''
# fits_YF, fits_YD, fits_YI = [], [], []
# rmses_krr_YF, rmses_krr_YD, rmses_krr_YI, lambda_opt_YFs, lambda_opt_YDs, lambda_opt_YIs = [], [], [], [], [], []
# for th in range(trails):
#     np.random.seed(th)
#     print('                                                                                  trail:', th + 1)
#     noise = np.random.normal(0, 0.1, YF_train.shape[0])
#
#     YF_train = YF_train + noise
#     YD_train = YD_train + noise
#     YI_train = YI_train + noise
#
#     # KRR
#     lambda_opt_YF = geo_uniform['lambda_YF_KRR'][th]
#     fits_YF.append(Predicted_KRR(X_train, YF_train, X_test, YF_test, d, lambda_opt_YF)[0])
#
#     lambda_opt_YD = geo_uniform['lambda_YD_KRR'][th]
#     fits_YD.append(Predicted_KRR(X_train, YD_train, X_test, YD_test, d, lambda_opt_YD)[0])
#
#     lambda_opt_YI = geo_uniform['lambda_YI_KRR'][th]
#     fits_YI.append(Predicted_KRR(X_train, YI_train, X_test, YI_test, d, lambda_opt_YI)[0])
#
#
# geo_uniform['KRR_fit_YF'] = fits_YF
# geo_uniform['KRR_fit_YD'] = fits_YD
# geo_uniform['KRR_fit_YI'] = fits_YI
#
# np.save(os.path.dirname(os.getcwd()) + '/Result_data/geo_uniform.npy', geo_uniform)
# print('save geo_uniform.npy done')
# print(geo_uniform.keys())
# time_total = time.time() - time_start
# print('runing time:', time_total)
#
#
#
# print(geo_uniform['KRR_fit_YF'][0].shape)







# ---------------------------------------------------------


# rmses_krr: [1.447485023911645e-05, 1.4863704412782844e-05, 1.2765546787924895e-05, 1.4141761032212093e-05, 1.6241334122336816e-05]
# print(geo_uniform['KRR_rmse'])
# print(geo_uniform['KI_rmse'])
# print(geo_uniform['KGD_rmse'])
# print(geo_uniform['TSVD_rmse'])
# [1.447485023911645e-05, 1.4863704412782844e-05, 1.2765546787924895e-05, 1.4141761032212093e-05, 1.6241334122336816e-05]
# [1.447485023911645e-05, 1.4863704412782844e-05, 1.2765546787924895e-05, 1.4141761032212093e-05, 1.6241334122336816e-05]
# [0.0060399279362732955, 0.006794463205009123, 0.005550180700053748, 0.005940578041999919, 0.0064637027298718825]
# [1.447485023911645e-05, 1.4863704412782844e-05, 1.2765546787924895e-05, 1.4141761032212093e-05, 1.6241334122336816e-05]
#




#
#
#
#
#
# rmse_krr_t5, rmse_kgd_t5, rmse_tsvd_t5 = np.empty(shape=(20, 5)), np.empty(shape=(16, 5)), np.empty(shape=(16, 5))
# trails = 5
# for trail in range(trails):
#     np.random.seed(1)
#     time_start = time.time()
#     rmse_krrs, rmse_kgds, rmse_tsvds = [], [], []
#     print('------------------------------------------------ trail:', trail + 1)
#
#
#
#
#     for i in range(20):
#         train_size = (100 * (i + 1), 3)
#         X_train, y_train, X_test, y_test = generate_data(train_size, test_size, func, noise_sd, trail)
#         print('------------------------------------------------ random:', train_size)
#
#         # KRR
#         lambda_opt = parameter_lambda_krr(X_train, y_train, f, d)
#         rmse_krr = Predicted_KRR(X_train, y_train, X_test, y_test, d, lambda_opt)[1]
#         # # KGD
#         # step_opt = parameter_step_kgd(X_train, y_train, f, d, step_sta, step_end)
#         # rmse_kgd = Predicted_KGD(X_train, y_train, X_test, y_test, d, step_opt)[1]
#         # # TSVD
#         # nu_opt = parameter_lambda_TSVD(X_train, y_train, f, d)
#         # rmse_tsvd = Predicted_TSVD(X_train, y_train, X_test, y_test, d, nu_opt)[1]
#
#         rmse_krrs.append(rmse_krr)
#         print('rmse_krrs:', rmse_krrs)
#         # rmse_kgds.append(rmse_kgd)
#         # print('rmse_kgds:', rmse_kgds)
#         # rmse_tsvds.append(rmse_tsvd)
#         # print('rmse_tsvds:', rmse_tsvds)
#
#     rmse_krrs_ar = np.array(rmse_krrs)
#     rmse_krr_t5[:, trail] = np.squeeze(rmse_krrs_ar)
#     # rmse_kgds_ar = np.array(rmse_kgds)
#     # rmse_kgd_t5[:, trail] = np.squeeze(rmse_kgds_ar)
#     # rmse_tsvds_ar = np.array(rmse_tsvds)
#     # rmse_tsvd_t5[:, trail] = np.squeeze(rmse_tsvds_ar)
#     time_total = time.time() - time_start
#     print('runing time for 1 trail:', time_total) # runing time for 1 trail: 1467.094449043274, 24min
#
#
# geo_uniform['KRR_rmse_noi5_5trails'] = rmse_krr_t5
# np.save(os.path.dirname(os.getcwd()) + '/Result_data/geo_uniform.npy', geo_uniform)
# print('save geo_uniform.npy done')
# print(geo_uniform.keys())
# time_total = time.time() - time_start
# print('runing time:', time_total)







# '''2.3: plot'''
# loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/geo_uniform.npy', allow_pickle=True)
# geo_uniform = loadData.tolist()
# print(geo_uniform.keys())
#
# KRR_rmse_noi5_mean = np.mean(geo_uniform['KRR_rmse_YF_noi1_5trails'], axis=1)
# KRR_rmse_noi3_mean = np.mean(geo_uniform['KRR_rmse_noi3_5trails'], axis=1)
# KRR_rmse_noi1_mean = np.mean(geo_uniform['KRR_rmse_noi1_5trails'], axis=1)
# # KRR_rmse_noi01_mean = np.mean(geo_uniform['KRR_rmse_noi01_5trails'], axis=1)
# # KRR_rmse_noi001_mean = np.mean(geo_uniform['KRR_rmse_noi001_5trails'], axis=1)
# sizes = geo_uniform['KI_sizes']
# # KI_rmse_noi5 = geo_uniform['KI_rmse_noi5']
#
# fig = plt.figure(tight_layout=True)
# gs = gridspec.GridSpec(1, 1)
# ax = fig.add_subplot(gs[0, 0])
# ax.grid(linestyle='-.', axis="y")
#
# # ax.plot(sizes, KRR_rmse_noi001_mean, c='royalblue', linestyle='-', linewidth=1.2)
# # ax.plot(sizes, KRR_rmse_noi01_mean, c='mediumpurple', linestyle='-', linewidth=1.2)
# ax.plot(sizes, KRR_rmse_noi1_mean, c='darkorange', linestyle='-', linewidth=1.2)
# ax.plot(sizes, KRR_rmse_noi3_mean, c='forestgreen', linestyle='-', linewidth=1.2)
# ax.plot(sizes, KRR_rmse_noi5_mean, c='indianred', linestyle='-', linewidth=1.2)
# ax.set_xlabel('The number of training samples', fontsize='14')
# ax.set_ylabel('RMSE', fontsize='13')
# # plt.title('Tikhonov Regularization', fontsize='12')
# plt.yscale('log')
# plt.ylim(0.005, 0.9999)
# plt.legend([
#     # '$\\sigma$=0.0',
#     #         '$\\sigma$=0.001',
#     #         '$\\sigma$=0.01',
#             '$\\sigma$=0.1',
#             '$\\sigma$=0.3',
#             '$\\sigma$=0.5'], ncol=3, loc='upper center', fontsize='medium')
#
# plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/f2/KRR_RMSE_N_(random).pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.show()












