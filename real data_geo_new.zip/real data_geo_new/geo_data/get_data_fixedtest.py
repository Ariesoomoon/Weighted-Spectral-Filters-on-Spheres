import requests
import xmljson
import json
import xmltodict
import time
import pandas as pd
from numpy import *
import numpy as np
import math
import h5py
from sklearn.model_selection import KFold
import os, time
time_start = time.time()
from Spectral_algorithms import XYZ_from_matfile, LLA_to_XYZ, XYZ_to_LLA, requests_geomag_data, parse_heads, parse_json_data_to_list, sample


'''
1. --------------------------------------------------爬取数据--------------------------------------------------
'''
# def reading_data_and_save_csv(save_file_path='./geomagnetic_fixedtest_2664.csv'):
#     # 北纬为正数,南纬为负数; 东经正数, 西经为负数: 经度范围 [-180,180], 纬度范围 [-90, 90]
#
#     # 陕西省的经纬度位置为东经105.47°~111.27°、北纬31.70°~39.59°  百度查询
#     date = '2023-06-07'
#     all_data_lists = []
#     time_start = time.time()
#
#     # 陕西省的经纬度位置为东经105.47°~111.27°、北纬31.70°~39.59°  百度查询
#     longitude_lists = [x for x in range(-180, 180, 5)]  # 经度, 60;  = 2200
#     latitude_lists = [x for x in range(-90, 91, 5)]  # 纬度, 37
#     altitude_lists = [0]  # above mean sea level 海拔高度 km⚠️ 注意单位！注意范围！
#
#     all_data_lists = []
#     for latitude in latitude_lists:
#         time_start = time.time()
#
#         for longitude in longitude_lists:
#             for altitude in altitude_lists:
#                 print(f'latitude={latitude}, longitude={longitude}, altitude={altitude} reading ...')
#                 # time.sleep(0.001)
#
#                 json_data = requests_geomag_data(latitude, longitude, altitude, date)
#                 single_data_list = parse_json_data_to_list(json_data)
#                 print(single_data_list)
#                 all_data_lists.append(single_data_list)
#
#         time_total = time.time() - time_start
#         print('runing time for 1 trail:', time_total) # runing time for 1 trail: 1467.094449043274, 24min
#
#     heads = parse_heads()
#
#
#
#     import csv
#
#     with open(save_file_path, 'w') as file:
#         writer = csv.writer(file)
#         writer.writerow(heads)
#         writer.writerows(all_data_lists)
#
#     with open(save_file_path, 'rt') as fin:  # 读有空行的csv文件，舍弃空行
#         lines = ''
#         for line in fin:
#             if line != '\n':
#                 lines += line
#
#     with open(save_file_path, 'wt') as fout:  # 再次文本方式写入，不含空行
#         fout.write(lines)
#
# reading_data_and_save_csv()



'''
2. ---------------------------------------------- 转移数据：YF， YD, YI --------------------------------------------------
'''
# data = pd.read_csv(os.path.dirname(os.getcwd()) + '/geo_data/geomagnetic_fixedtest_2664.csv')
# print('\n output the first 5 data -----------------------------------------------------------------\n', data.head())
#
# YF = data.total_intensity
# YF = YF.to_frame()
# YF = np.array(YF).reshape(-1,1)
# # print(YF.shape)
# # print(type(YF))
# # print(YF[:4])
#
# YD = data.declination
# YD = YD.to_frame()
# YD = np.array(YD).reshape(-1,1)
# # print(YD.shape)
# # print(type(YD))
# # print(YD[:4])
#
# YI = data.inclination
# YI = YI.to_frame()
# YI = np.array(YI).reshape(-1,1)
# # print(YI.shape)
# # print(type(YI))
# # print(YI[:4])
#
# loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/geo_uniform_2016.npy', allow_pickle=True)
# geo_uniform_2016 = loadData.tolist()
# geo_uniform_2016['YF_tes'] = YF
# geo_uniform_2016['YD_tes'] = YD
# geo_uniform_2016['YI_tes'] = YI
# np.save(os.path.dirname(os.getcwd()) + '/Result_data/geo_uniform_2016.npy', geo_uniform_2016)
# print('save geo_uniform_2016.npy done')
# print(geo_uniform_2016.keys())


'''
2. -------------------------------------------------- 转移数据：XYZ_tes, 并转为LLA_tes--------------------------------------------------
'''
# data = pd.read_csv(os.path.dirname(os.getcwd()) + '/geo_data/geomagnetic_fixedtest_2664.csv')
# print('\n output the first 5 data -----------------------------------------------------------------\n', data.head())
#
# features = ['longitude','latitude', 'altitude']
# X = data[features]
# LLA_tes = np.array(X)
# XYZ_tes = LLA_to_XYZ(LLA_tes)
#
# loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/geo_uniform_2016.npy', allow_pickle=True)
# geo_uniform_2016 = loadData.tolist()
# geo_uniform_2016['XYZ_tes'] = XYZ_tes
# geo_uniform_2016['LLA_tes'] = LLA_tes
# np.save(os.path.dirname(os.getcwd()) + '/Result_data/geo_uniform_2016.npy', geo_uniform_2016)
# print('save geo_uniform_2016.npy done')
# print(geo_uniform_2016.keys())


# # 检测转换是否正确：
# loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/geo_uniform_2016.npy', allow_pickle=True)
# geo_uniform_2016 = loadData.tolist()
# print('XYZ_tes:\n', geo_uniform_2016['XYZ_tes'][:4])
# print(XYZ_to_LLA(geo_uniform_2016['XYZ_tes'][:4]))
# print(LLA_to_XYZ(XYZ_to_LLA(geo_uniform_2016['XYZ_tes'][:4])))
# # XYZ_tes:
# #  [[-3.91862092e-10 -4.79892657e-26 -6.35675231e+06]
# #  [-3.90370939e-10 -3.41530317e-11 -6.35675231e+06]
# #  [-3.85908827e-10 -6.80461383e-11 -6.35675231e+06]
# #  [-3.78509715e-10 -1.01421373e-10 -6.35675231e+06]]
# # [[-1.80000000e+02 -9.00000000e+01 -3.17245722e-05]
# #  [-1.75000000e+02 -9.00000000e+01 -3.17236409e-05]
# #  [-1.70000000e+02 -9.00000000e+01 -3.17245722e-05]
# #  [-1.65000000e+02 -9.00000000e+01 -3.17255035e-05]]
# # [[-3.91862092e-10 -4.79892657e-26 -6.35675231e+06]
# #  [-3.90370939e-10 -3.41530317e-11 -6.35675231e+06]
# #  [-3.85908827e-10 -6.80461383e-11 -6.35675231e+06]
# #  [-3.78509715e-10 -1.01421373e-10 -6.35675231e+06]]


'''---------------------------------------------  将XYZ_tes归一化  ------------------------------------------- '''
# loadData1 = np.load(os.path.dirname(os.getcwd()) + '/Result_data/geo_uniform_2016.npy', allow_pickle=True)
# geo_uniform_2016 = loadData1.tolist()
# # geo_uniform_2016['XYZ_tes_unit'] = geo_uniform_2016['XYZ_tes']/6378137.0
# # np.save(os.path.dirname(os.getcwd()) + '/Result_data/geo_uniform_2016.npy', geo_uniform_2016)
# # print('save geo_uniform_2016.npy done')
# print(geo_uniform_2016.keys())
# print(geo_uniform_2016['LLA_tes'][:2])
# print(geo_uniform_2016['XYZ_tes'][:2])
# print(geo_uniform_2016['XYZ_tes_unit'][:2])
# # [[-180.  -90.    0.]
# #  [-175.  -90.    0.]]
# # [[-3.91862092e-10 -4.79892657e-26 -6.35675231e+06]
# #  [-3.90370939e-10 -3.41530317e-11 -6.35675231e+06]]
# # [[-6.14383310e-17 -7.52402555e-33 -9.96647189e-01]
# #  [-6.12045397e-17 -5.35470338e-18 -9.96647189e-01]]
# # [[140. -25.   0.]
# #  [145. -25.   0.]]
#
# print(geo_uniform_2016['LLA_tes'][1000:1002])
# print(geo_uniform_2016['XYZ_tes'][1000:1002])
# print(geo_uniform_2016['XYZ_tes_unit'][1000:1002])
# # [[140. -25.   0.]
# #  [145. -25.   0.]]
# # [[-4430811.87150349  3717892.6071945  -2679074.46298185]
# #  [-4737986.98626981  3317574.20372563 -2679074.46298185]]
# # [[-0.69468747  0.582912   -0.42004028]
# #  [-0.74284811  0.52014784 -0.42004028]]



'''虽然train和test都是借助赤道半径，形状一个是球体一个是椭球，但是scale十分接近'''
# print(np.linalg.norm(geo_uniform_2016['XYZ_train_unit'], axis=1, keepdims=True)[:4])
# print(np.linalg.norm(geo_uniform_2016['XYZ_tes_unit'], axis=1, keepdims=True)[:4])
# # [[1.]
# #  [1.]
# #  [1.]
# #  [1.]]
# # [[0.99664719]
# #  [0.99664719]
# #  [0.99664719]
# #  [0.99664719]]






