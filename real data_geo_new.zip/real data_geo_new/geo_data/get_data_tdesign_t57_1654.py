import requests
import xmljson
import json
import xmltodict
import time
import pandas as pd
from numpy import *
import numpy as np
import math
import h5py
from sklearn.model_selection import KFold
import os, time
time_start = time.time()
from Spectral_algorithms import XYZ_from_matfile
from Spectral_algorithms import XYZ_from_matfile, LLA_to_XYZ, XYZ_to_LLA, requests_geomag_data, parse_heads, parse_json_data_to_list, sample


# geo_t57_1654 = {} # function name: f2, kernel name:h3k, data increasing way: t (of t-design) increases
# np.save('/Users/liuxiaotong/Documents/machine learning/4_Spectral approach on spheres/real data_geo_new/Result_data/geo_t57_1654.npy', geo_t57_1654)
# print('save geo_t57_1654.npy done')
#
# loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/geo_t57_1654.npy', allow_pickle=True)
# geo_t57_1654 = loadData.tolist()
# print(geo_t57_1654.keys())
#

'''
2. --------------------------------------------------取出单位球的spherical design固定采样点--------------------------------------------------
'''
# t_design = 57 # t_design = 3,7,...,63; and corresponding data size = 6,32,..,.2018
# XYZ_train = XYZ_from_matfile(t_design)
# delete1 = int(XYZ_train.shape[0]/2)
# delete2 = int(XYZ_train.shape[0]/2 + 1)
# print(delete1)
# print(delete2)
#
# XYZ_train = (XYZ_train / np.linalg.norm(XYZ_train, axis=1, keepdims=True)) * 6378137.0
# XYZ_train = np.vstack((XYZ_train[1:delete1], XYZ_train[delete2:]))
#
# geo_t57_1654['XYZ_train'] = XYZ_train
# geo_t57_1654['LLA_train'] = XYZ_to_LLA(XYZ_train)
# print(geo_t57_1654['XYZ_train'].shape)
# print(geo_t57_1654['LLA_train'].shape)
# np.save(os.path.dirname(os.getcwd()) + '/Result_data/geo_t57_1654.npy', geo_t57_1654)
# print('save geo_t57_1654.npy done')
# print(geo_t57_1654.keys())


# # 检测转换是否正确：
# print('XYZ_train:\n', geo_t57_1654['XYZ_train'][:5])
# print('LLA_train:\n', geo_t57_1654['LLA_train'][:5])
# print('XYZ_train (transfered from XYZ):\n', LLA_to_XYZ(geo_t57_1654['LLA_train'][:5]))



'''
3. --------------------------------------------------爬取数据--------------------------------------------------
'''
loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/geo_t57_1654.npy', allow_pickle=True)
geo_t57_1654 = loadData.tolist()
print(geo_t57_1654.keys())
# LLA_train = geo_t57_1654['LLA_train']
# print(LLA_train.shape[0])
#
#
# def reading_data_and_save_csv(save_file_path='./geomagnetic_tdesign_t57.csv'):
#     # 北纬为正数,南纬为负数; 东经正数, 西经为负数: 经度范围 [-180,180], 纬度范围 [-90, 90]
#
#     # 陕西省的经纬度位置为东经105.47°~111.27°、北纬31.70°~39.59°  百度查询
#     date = '2023-06-07'
#     all_data_lists = []
#     time_start = time.time()
#
#     for th in range(LLA_train.shape[0]):
#         print('---------------------------- th:', th)
#         longitude, latitude, altitude = LLA_train[th, 0], LLA_train[th, 1], 0
#         print(longitude, latitude, altitude)
#
#         print(f'latitude={latitude}, longitude={longitude}, altitude={altitude} reading ...')
#         # time.sleep(0.001)
#
#         json_data = requests_geomag_data(latitude, longitude, altitude, date)
#         single_data_list = parse_json_data_to_list(json_data)
#         print(single_data_list)
#         all_data_lists.append(single_data_list)
#
#
#     time_total = time.time() - time_start
#     print('runing time for 1 trail:', time_total) # runing time for 1 trail: 2094.0695338249207
#
#     heads = parse_heads()
#
#     import csv
#
#     with open(save_file_path, 'w') as file:
#         writer = csv.writer(file)
#         writer.writerow(heads)
#         writer.writerows(all_data_lists)
#
#     with open(save_file_path, 'rt') as fin:  # 读有空行的csv文件，舍弃空行
#         lines = ''
#         for line in fin:
#             if line != '\n':
#                 lines += line
#
#     with open(save_file_path, 'wt') as fout:  # 再次文本方式写入，不含空行
#         fout.write(lines)
#
# reading_data_and_save_csv()


data = pd.read_csv(os.path.dirname(os.getcwd()) + '/geo_data/geomagnetic_tdesign_t57.csv')
print('\n output the first 5 data -----------------------------------------------------------------\n', data.head())

YF = data.total_intensity
YF = YF.to_frame()
YF = np.array(YF).reshape(-1,1)
print(YF.shape)
print(type(YF))
print(YF[:4])

YD = data.declination
YD = YD.to_frame()
YD = np.array(YD).reshape(-1,1)
print(YD.shape)
print(type(YD))
print(YD[:4])

YI = data.inclination
YI = YI.to_frame()
YI = np.array(YI).reshape(-1,1)
print(YI.shape)
print(type(YI))
print(YI[:4])


loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/geo_t57_1654.npy', allow_pickle=True)
geo_t57_1654 = loadData.tolist()
geo_t57_1654['YF_train'] = YF
geo_t57_1654['YD_train'] = YD
geo_t57_1654['YI_train'] = YI

np.save(os.path.dirname(os.getcwd()) + '/Result_data/geo_t57_1654.npy', geo_t57_1654)
print('save geo_t57_1654.npy done')
print(geo_t57_1654.keys())



'''
5. data normalization
'''
loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/geo_t57_1654.npy', allow_pickle=True)
geo_t57_1654 = loadData.tolist()
print(geo_t57_1654.keys())

geo_t57_1654['XYZ_train_unit'] = geo_t57_1654['XYZ_train']/6378137.0
np.save(os.path.dirname(os.getcwd()) + '/Result_data/geo_t57_1654.npy', geo_t57_1654)
print('save geo_t57_1654.npy done')
print(geo_t57_1654.keys())
print(np.linalg.norm(geo_t57_1654['XYZ_train_unit'], axis=1, keepdims=True)[:4])
# [[1.]
#  [1.]
#  [1.]
#  [1.]]





