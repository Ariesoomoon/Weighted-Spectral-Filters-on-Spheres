import requests
import xmljson
import json
import xmltodict
import time
import pandas as pd
from numpy import *
import numpy as np
import math
import h5py
from sklearn.model_selection import KFold
import os, time
time_start = time.time()
from Spectral_algorithms import XYZ_from_matfile
from Spectral_algorithms import XYZ_from_matfile, LLA_to_XYZ, XYZ_to_LLA, requests_geomag_data, parse_heads, parse_json_data_to_list, sample

#
# # geo_t63_2016 = {} # function name: f2, kernel name:h3k, data increasing way: t (of t-design) increases
# # np.save('/Users/liuxiaotong/Documents/machine learning/4_Spectral approach on spheres/real data_geo_new/Result_data/geo_t63_2016.npy', geo_t63_2016)
# # print('save geo_t63_2016.npy done')

loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/geo_t63_2016.npy', allow_pickle=True)
geo_t63_2016 = loadData.tolist()
print(geo_t63_2016.keys())


'''
2. --------------------------------------------------取出单位球的spherical design固定采样点--------------------------------------------------
'''
t_design = 63 # t_design = 3,7,...,63; and corresponding data size = 6,32,..,.2018
XYZ_train = XYZ_from_matfile(t_design)
delete1 = int(XYZ_train.shape[0]/2)
delete2 = int(XYZ_train.shape[0]/2 + 1)
print(delete1)
print(delete2)


# # XYZ_train = (XYZ_train / np.linalg.norm(XYZ_train, axis=1, keepdims=True)) * 6378137.0
# # XYZ_train = np.vstack((XYZ_train[1:delete1], XYZ_train[delete2:]))
# #
# # geo_t63_2016['XYZ_train'] = XYZ_train
# # geo_t63_2016['LLA_train'] = XYZ_to_LLA(XYZ_train)
# print(geo_t63_2016['XYZ_train'].shape)
# print(geo_t63_2016['LLA_train'].shape)
# np.save(os.path.dirname(os.getcwd()) + '/Result_data/geo_t63_2016.npy', geo_t63_2016)
# print('save geo_t63_2016.npy done')
# print(geo_t63_2016.keys())



# # 检测转换是否正确：
# print('XYZ_train:\n', geo_t63_2016['XYZ_train'][:5])
# print('LLA_train:\n', geo_t63_2016['LLA_train'][:5])
# print('XYZ_train (transfered from XYZ):\n', LLA_to_XYZ(geo_t63_2016['LLA_train'][:5]))
# XYZ_train:
#  [[ 506708.150138         0.         6357977.54331932]
#  [ 367614.17631404  468488.19979665 6350276.38885059]
#  [-106331.64138034  594520.0792602  6349478.01383443]
#  [-451761.80428223  223502.76187326 6358190.7315207 ]
#  [-632257.65569978 -208770.81732624 6343287.52252418]]
# LLA_train:
#  [[    0.            85.47363764 21250.38850029]
#  [   51.87936744    84.6782606  21199.19534297]
#  [  100.14029976    84.60248681 21193.89165219]
#  [  153.67674723    85.49764849 21251.80652659]
#  [ -161.72683085    84.04748721 21152.78974017]]
# XYZ_train (transfered from XYZ):
#  [[ 506708.15013552       0.         6357977.54335113]
#  [ 367614.17631224  468488.19979436 6350276.3888825 ]
#  [-106331.64137982  594520.07925729 6349478.01386636]
#  [-451761.80428001  223502.76187217 6358190.73155251]
#  [-632257.65569669 -208770.81732522 6343287.5225562 ]]



'''  ------------------- 经纬度的平方和很小的时候，海拔的预测会非常不准确，因此我们去掉了t-design中的0,0,1和0，0，-1 --------------------'''
# print('XYZ_train:\n', XYZ_train[:2])
# print('LLA_train:\n', XYZ_to_LLA(XYZ_train)[:2])
# print('XYZ_train (transfered from XYZ):\n', LLA_to_XYZ(XYZ_to_LLA(XYZ_train))[:2])
#
# print('--------------------------------')
# XYZ_train = XYZ_train * 6378137.0
# print('XYZ_train:\n', XYZ_train[:2])
# print('LLA_train:\n', XYZ_to_LLA(XYZ_train)[:2])
# print('XYZ_train (transfered from XYZ):\n', LLA_to_XYZ(XYZ_to_LLA(XYZ_train))[:2])
#
# # XYZ_train:
# #  [[0.         0.         1.        ]
# #  [0.07944454 0.         0.99683929]]
# # LLA_train:
# #  [[ 0.00000000e+00  9.00000000e+01 -6.39959363e+06]
# #  [ 0.00000000e+00  9.00285078e+01 -6.39975329e+06]]
# # XYZ_train (transfered from XYZ):
# #  [[-1.94256979e-21 -0.00000000e+00 -4.28413115e+04]
# #  [ 7.94445542e-02  0.00000000e+00 -4.30009759e+04]]
# # --------------------------------
# # XYZ_train:
# #  [[      0.               0.         6378137.        ]
# #  [ 506708.150138         0.         6357977.54331932]]
# # LLA_train:
# #  [[ 0.00000000e+00  9.00000000e+01 -6.39959363e+06]
# #  [ 0.00000000e+00  8.54736376e+01  2.12503885e+04]]
# # XYZ_train (transfered from XYZ):
# #  [[-1.94256979e-21 -0.00000000e+00 -4.28413115e+04]
# #  [ 5.06708150e+05  0.00000000e+00  6.35797754e+06]]




'''
3. --------------------------------------------------爬取数据--------------------------------------------------
'''
# loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/geo_t63_2016.npy', allow_pickle=True)
# geo_t63_2016 = loadData.tolist()
# print(geo_t63_2016.keys())
# LLA_train = geo_t63_2016['LLA_train']
# print(LLA_train.shape[0])
#
#
# def reading_data_and_save_csv(save_file_path='./geomagnetic_tdesign_t63.csv'):
#     # 北纬为正数,南纬为负数; 东经正数, 西经为负数: 经度范围 [-180,180], 纬度范围 [-90, 90]
#
#     # 陕西省的经纬度位置为东经105.47°~111.27°、北纬31.70°~39.59°  百度查询
#     date = '2023-06-07'
#     all_data_lists = []
#     time_start = time.time()
#
#     for th in range(LLA_train.shape[0]):
#         print('---------------------------- th:', th)
#         longitude, latitude, altitude = LLA_train[th, 0], LLA_train[th, 1], 0
#         print(longitude, latitude, altitude)
#
#         print(f'latitude={latitude}, longitude={longitude}, altitude={altitude} reading ...')
#         # time.sleep(0.001)
#
#         json_data = requests_geomag_data(latitude, longitude, altitude, date)
#         single_data_list = parse_json_data_to_list(json_data)
#         print(single_data_list)
#         all_data_lists.append(single_data_list)
#
#
#     time_total = time.time() - time_start
#     print('runing time for 1 trail:', time_total) # runing time for 1 trail: 2094.0695338249207
#
#     heads = parse_heads()
#
#     import csv
#
#     with open(save_file_path, 'w') as file:
#         writer = csv.writer(file)
#         writer.writerow(heads)
#         writer.writerows(all_data_lists)
#
#     with open(save_file_path, 'rt') as fin:  # 读有空行的csv文件，舍弃空行
#         lines = ''
#         for line in fin:
#             if line != '\n':
#                 lines += line
#
#     with open(save_file_path, 'wt') as fout:  # 再次文本方式写入，不含空行
#         fout.write(lines)
#
# reading_data_and_save_csv()


# data = pd.read_csv(os.path.dirname(os.getcwd()) + '/geo_data/geomagnetic_tdesign_t63.csv')
# print('\n output the first 5 data -----------------------------------------------------------------\n', data.head())
#
# YF = data.total_intensity
# YF = YF.to_frame()
# YF = np.array(YF).reshape(-1,1)
# print(YF.shape)
# print(type(YF))
# print(YF[:4])
#
# YD = data.declination
# YD = YD.to_frame()
# YD = np.array(YD).reshape(-1,1)
# print(YD.shape)
# print(type(YD))
# print(YD[:4])
#
# YI = data.inclination
# YI = YI.to_frame()
# YI = np.array(YI).reshape(-1,1)
# print(YI.shape)
# print(type(YI))
# print(YI[:4])
#
#
# loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/geo_t63_2016.npy', allow_pickle=True)
# geo_t63_2016 = loadData.tolist()
# geo_t63_2016['YF_train'] = YF
# geo_t63_2016['YD_train'] = YD
# geo_t63_2016['YI_train'] = YI
#
# np.save(os.path.dirname(os.getcwd()) + '/Result_data/geo_t63_2016.npy', geo_t63_2016)
# print('save geo_t63_2016.npy done')
# print(geo_t63_2016.keys())



'''
5. data normalization
'''
# loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/geo_t63_2016.npy', allow_pickle=True)
# geo_t63_2016 = loadData.tolist()
# print(geo_t63_2016.keys())
#
# geo_t63_2016['XYZ_train_unit'] = geo_t63_2016['XYZ_train']/6378137.0
# np.save(os.path.dirname(os.getcwd()) + '/Result_data/geo_t63_2016.npy', geo_t63_2016)
# print('save geo_t63_2016.npy done')
# print(geo_t63_2016.keys())
# print(np.linalg.norm(geo_t63_2016['XYZ_train_unit'], axis=1, keepdims=True)[:4])
# # [[1.]
# #  [1.]
# #  [1.]
# #  [1.]]



