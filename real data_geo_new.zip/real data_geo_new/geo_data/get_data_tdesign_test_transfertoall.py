import requests
import xmljson
import json
import xmltodict
import time
import pandas as pd
from numpy import *
import numpy as np
import math
import h5py
from sklearn.model_selection import KFold
import os, time
time_start = time.time()
from Spectral_algorithms import XYZ_from_matfile, LLA_to_XYZ, XYZ_to_LLA, requests_geomag_data, parse_heads, parse_json_data_to_list, sample



data = pd.read_csv(os.path.dirname(os.getcwd()) + '/geo_data/geomagnetic_fixedtest_2664.csv')
print('\n output the first 5 data -----------------------------------------------------------------\n', data.head())

loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/geo_t57_1654.npy', allow_pickle=True)
geo_t57_1654 = loadData.tolist()
print(geo_t57_1654.keys())


'''
1. -------------------------- 转移数据 XYZ_tes, LLA_tes, XYZ_tes_unit, YF_tes, YD_tes, YI_tes， 到每一个不同size的数据集上------------------
'''
# 1. ------------------- 转移数据：YF， YD, YI ---------------
YF = data.total_intensity
YF = YF.to_frame()
YF = np.array(YF).reshape(-1,1)

YD = data.declination
YD = YD.to_frame()
YD = np.array(YD).reshape(-1,1)

YI = data.inclination
YI = YI.to_frame()
YI = np.array(YI).reshape(-1,1)

# 2. ------------- 转移数据：XYZ_tes, 并转为LLA_tes------------
features = ['longitude','latitude', 'altitude']
X = data[features]
LLA_tes = np.array(X)
XYZ_tes = LLA_to_XYZ(LLA_tes)
print(LLA_tes[:5])

# （1）
geo_t57_1654['YF_tes'] = YF
geo_t57_1654['YD_tes'] = YD
geo_t57_1654['YI_tes'] = YI

# （2）
geo_t57_1654['XYZ_tes'] = XYZ_tes
geo_t57_1654['LLA_tes'] = LLA_tes
geo_t57_1654['XYZ_tes_unit'] = XYZ_tes/6378137.0

np.save(os.path.dirname(os.getcwd()) + '/Result_data/geo_t57_1654.npy', geo_t57_1654)
print('save geo_t57_1654.npy done')
print(geo_t57_1654.keys())



'''
2. -------------------------------------------------- 测试数据 --------------------------------------------------
'''
# 检测转换是否正确
#(1)
loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/geo_t57_1654.npy', allow_pickle=True)
geo_t57_1654 = loadData.tolist()
print('XYZ_tes:\n', geo_t57_1654['XYZ_tes'][:4])
print(XYZ_to_LLA(geo_t57_1654['XYZ_tes'][:4]))
print(LLA_to_XYZ(XYZ_to_LLA(geo_t57_1654['XYZ_tes'][:4])))
# XYZ_tes:
#  [[-3.91862092e-10 -4.79892657e-26 -6.35675231e+06]
#  [-3.90370939e-10 -3.41530317e-11 -6.35675231e+06]
#  [-3.85908827e-10 -6.80461383e-11 -6.35675231e+06]
#  [-3.78509715e-10 -1.01421373e-10 -6.35675231e+06]]
# [[-1.80000000e+02 -9.00000000e+01 -3.17245722e-05]
#  [-1.75000000e+02 -9.00000000e+01 -3.17236409e-05]
#  [-1.70000000e+02 -9.00000000e+01 -3.17245722e-05]
#  [-1.65000000e+02 -9.00000000e+01 -3.17255035e-05]]
# [[-3.91862092e-10 -4.79892657e-26 -6.35675231e+06]
#  [-3.90370939e-10 -3.41530317e-11 -6.35675231e+06]
#  [-3.85908827e-10 -6.80461383e-11 -6.35675231e+06]
#  [-3.78509715e-10 -1.01421373e-10 -6.35675231e+06]]


#(2)
loadData1 = np.load(os.path.dirname(os.getcwd()) + '/Result_data/geo_t57_1654.npy', allow_pickle=True)
geo_t57_1654 = loadData1.tolist()
print(geo_t57_1654.keys())
print(geo_t57_1654['LLA_tes'][:2])
print(geo_t57_1654['XYZ_tes'][:2])
print(geo_t57_1654['XYZ_tes_unit'][:2])
# [[-180.  -90.    0.]
#  [-175.  -90.    0.]]
# [[-3.91862092e-10 -4.79892657e-26 -6.35675231e+06]
#  [-3.90370939e-10 -3.41530317e-11 -6.35675231e+06]]
# [[-6.14383310e-17 -7.52402555e-33 -9.96647189e-01]
#  [-6.12045397e-17 -5.35470338e-18 -9.96647189e-01]]

print(geo_t57_1654['LLA_tes'][1000:1002])
print(geo_t57_1654['XYZ_tes'][1000:1002])
print(geo_t57_1654['XYZ_tes_unit'][1000:1002])
# [[140. -25.   0.]
#  [145. -25.   0.]]
# [[-4430811.87150349  3717892.6071945  -2679074.46298185]
#  [-4737986.98626981  3317574.20372563 -2679074.46298185]]
# [[-0.69468747  0.582912   -0.42004028]
#  [-0.74284811  0.52014784 -0.42004028]]


#(3) 虽然train和test都是借助赤道半径，形状一个是球体一个是椭球，但是scale十分接近
print(np.linalg.norm(geo_t57_1654['XYZ_train_unit'], axis=1, keepdims=True)[:4])
print(np.linalg.norm(geo_t57_1654['XYZ_tes_unit'], axis=1, keepdims=True)[:4])
# [[1.]
#  [1.]
#  [1.]
#  [1.]]
# [[0.99664719]
#  [0.99664719]
#  [0.99664719]
#  [0.99664719]]






