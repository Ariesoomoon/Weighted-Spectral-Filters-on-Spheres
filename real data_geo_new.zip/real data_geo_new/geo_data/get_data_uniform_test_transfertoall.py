import requests
import xmljson
import json
import xmltodict
import time
import pandas as pd
from numpy import *
import numpy as np
import math
import h5py
from sklearn.model_selection import KFold
import os, time
time_start = time.time()
from Spectral_algorithms import XYZ_from_matfile, LLA_to_XYZ, XYZ_to_LLA, requests_geomag_data, parse_heads, parse_json_data_to_list, sample



data = pd.read_csv(os.path.dirname(os.getcwd()) + '/geo_data/geomagnetic_fixedtest_2664.csv')
print('\n output the first 5 data -----------------------------------------------------------------\n', data.head())

loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/geo_uniform_46.npy', allow_pickle=True)
geo_uniform_46 = loadData.tolist()


'''
1. -------------------------- 转移数据 XYZ_tes, LLA_tes, XYZ_tes_unit, YF_tes, YD_tes, YI_tes，到每一个不同size的数据集上------------------
'''
# 1. ------------------- 转移数据：YF， YD, YI ---------------
YF = data.total_intensity
YF = YF.to_frame()
YF = np.array(YF).reshape(-1,1)

YD = data.declination
YD = YD.to_frame()
YD = np.array(YD).reshape(-1,1)

YI = data.inclination
YI = YI.to_frame()
YI = np.array(YI).reshape(-1,1)

# 2. ------------- 转移数据：XYZ_tes, 并转为LLA_tes------------
features = ['longitude','latitude', 'altitude']
X = data[features]
LLA_tes = np.array(X)
XYZ_tes = LLA_to_XYZ(LLA_tes)


# （1）
geo_uniform_46['YF_tes'] = YF
geo_uniform_46['YD_tes'] = YD
geo_uniform_46['YI_tes'] = YI

# （2）
geo_uniform_46['XYZ_tes'] = XYZ_tes
geo_uniform_46['LLA_tes'] = LLA_tes
geo_uniform_46['XYZ_tes_unit'] = XYZ_tes/6378137.0

np.save(os.path.dirname(os.getcwd()) + '/Result_data/geo_uniform_46.npy', geo_uniform_46)
print('save geo_uniform_46.npy done')
print(geo_uniform_46.keys())



'''
2. -------------------------------------------------- 测试数据 --------------------------------------------------
'''
# # 检测转换是否正确
##(1)
loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/geo_uniform_46.npy', allow_pickle=True)
geo_uniform_46 = loadData.tolist()
print('XYZ_tes:\n', geo_uniform_46['XYZ_tes'][:4])
print(XYZ_to_LLA(geo_uniform_46['XYZ_tes'][:4]))
print(LLA_to_XYZ(XYZ_to_LLA(geo_uniform_46['XYZ_tes'][:4])))


##(2)
loadData1 = np.load(os.path.dirname(os.getcwd()) + '/Result_data/geo_uniform_46.npy', allow_pickle=True)
geo_uniform_46 = loadData1.tolist()
print(geo_uniform_46.keys())
print(geo_uniform_46['LLA_tes'][:2])
print(geo_uniform_46['XYZ_tes'][:2])
print(geo_uniform_46['XYZ_tes_unit'][:2])


##(3)
'''虽然train和test都是借助赤道半径，形状一个是球体一个是椭球，但是scale十分接近'''
print(np.linalg.norm(geo_uniform_46['XYZ_train_unit'], axis=1, keepdims=True)[:4])
print(np.linalg.norm(geo_uniform_46['XYZ_tes_unit'], axis=1, keepdims=True)[:4])
# # [[1.]
# #  [1.]
# #  [1.]
# #  [1.]]
# # [[0.99664719]
# #  [0.99664719]
# #  [0.99664719]
# #  [0.99664719]]






