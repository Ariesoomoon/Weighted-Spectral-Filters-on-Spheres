import requests
import xmljson
import json
import xmltodict
import time
import pandas as pd
from numpy import *
import numpy as np
import math
import h5py
from sklearn.model_selection import KFold
import os, time
time_start = time.time()
from Spectral_algorithms import XYZ_from_matfile, LLA_to_XYZ, XYZ_to_LLA, requests_geomag_data, parse_heads, parse_json_data_to_list, sample, sample_unit


'''
以6378137.0，即地球赤道平均半径为基准，随机采样，这个采样是正方体
'''
trails = 5
train_size = (2016, 3)
test_size = (1000, 3)  # 这个固定好，但是不用这些测试数据


'''
1. --------------------------------------------------取出单位球的随机采样点--------------------------------------------------
'''
# # geo_uniform_2016_prior = {} # function name: f2, kernel name:h3k, data increasing way: t (of t-design) increases
# # np.save('/Users/liuxiaotong/Documents/machine learning/4_Spectral approach on spheres/real data_geo_new/Result_data/geo_uniform_2016_prior.npy', geo_uniform_2016_prior)
# # print('save geo_uniform_2016_prior.npy done')
#
# loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/geo_uniform_2016_prior.npy', allow_pickle=True)
# geo_uniform_2016_prior = loadData.tolist()
# print(geo_uniform_2016_prior.keys())
#
# XYZ_train, XYZ_tes = sample_unit(train_size, test_size)[1], sample_unit(train_size, test_size)[3]
# geo_uniform_2016_prior['XYZ_train'] = XYZ_train
# geo_uniform_2016_prior['XYZ_tes'] = XYZ_tes
# np.save(os.path.dirname(os.getcwd()) + '/Result_data/geo_uniform_2016_prior.npy', geo_uniform_2016_prior)
# print('save geo_uniform_2016_prior.npy done')
# print(geo_uniform_2016_prior.keys())
# print(geo_uniform_2016_prior['XYZ_train'].shape) # (2016, 3)





'''
2. --------------------------------------------------XYZ转换为LLA坐标--------------------------------------------------
'''
# loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/geo_uniform_2016_prior.npy', allow_pickle=True)
# geo_uniform_2016_prior = loadData.tolist()
#
# XYZ_train = geo_uniform_2016_prior['XYZ_train']
# geo_uniform_2016_prior['LLA_train'] = XYZ_to_LLA(XYZ_train)
# np.save(os.path.dirname(os.getcwd()) + '/Result_data/geo_uniform_2016_prior.npy', geo_uniform_2016_prior)
# print('save geo_uniform_2016_prior.npy done')
# print(geo_uniform_2016_prior.keys())
#
# # 检测转换是否正确：
# print('XYZ_train:\n', geo_uniform_2016_prior['XYZ_train'][:5])
# print(geo_uniform_2016_prior['LLA_train'][:5])
# print(LLA_to_XYZ(geo_uniform_2016_prior['LLA_train'][:5]))



'''---------------------------- 一些测试，关于是否用单位球采样还是用赤道半径球采样 ------------------------------------'''
loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/geo_uniform_2016_prior.npy', allow_pickle=True)
geo_uniform_2016_prior = loadData.tolist()
#
# XYZ_train = geo_uniform_2016_prior['XYZ_train']
# geo_uniform_2016_prior['LLA_train'] = XYZ_to_LLA(XYZ_train)
# np.save(os.path.dirname(os.getcwd()) + '/Result_data/geo_uniform_2016_prior.npy', geo_uniform_2016_prior)
# print('save geo_uniform_2016_prior.npy done')
# print(geo_uniform_2016_prior.keys())

# 检测转换是否正确：
print('XYZ_train:\n', geo_uniform_2016_prior['XYZ_train'][:5])
print('LLA_train:\n', geo_uniform_2016_prior['LLA_train'][:5])
print('XYZ_train (transfered from XYZ):\n', LLA_to_XYZ(geo_uniform_2016_prior['LLA_train'][:5]))

# XYZ_train:
#  [[ 0.20053839  0.88405308  0.42217829]  # XYZ （在单位球体表面进行采样）
#  [ 0.26298257 -0.44732694  0.8548326 ]
#  [-0.10227969  0.64202259  0.75983278]
#  [-0.36947012  0.92471766  0.09159187]
#  [ 0.11189896  0.69989165 -0.70542916]]
# LLA_train:
#  [[ 7.72193250e+01  1.74153707e+02 -6.37835943e+06]   # XYZ--->LLA
#  [-5.95488191e+01  1.02443698e+02 -6.39859497e+06]
#  [ 9.90516445e+01  1.21713661e+02 -6.39364403e+06]
#  [ 1.11779136e+02  1.79954687e+02 -6.37813801e+06]
#  [ 8.09164047e+01 -1.35019795e+02 -6.38883188e+06]]
# XYZ_train (transfered from XYZ):
#  [[ 2.00538459e-01  8.84053395e-01 -4.34943296e+03]  # LLA--->XYZ; XY会产生很小的误差, Z上的误差非常大，因为此时一个很小的误差，转换时都会被赤道半径放大。
#  [ 2.62985868e-01 -4.47332554e-01 -4.18307003e+04]
#  [-1.02281582e-01  6.42034480e-01 -3.64116585e+04]
#  [-3.69470125e-01  9.24717662e-01 -3.37685388e+01]
#  [ 1.11900718e-01  6.99902664e-01  3.02326928e+04]]




'''
以以上第一个数据为例:
(1)LLA中的latitude和altitude受Z的影响较大，longitude不受影响，这个容易理解，因为公式里，longitude只和X， Y有关
(2)当Z很小，经过转换后返回的Z距离原始的z较远； XY都比较准确 
(3)当Z很大，经过转换后返回的Z会很接近原始的z；XY都比较准确
(2)和(3)中的返回的X，Y，Z和原始的X，Y，Z不一样，这是公式本身的转换误差引起的
公式见：https://en.wikipedia.org/wiki/Geographic_coordinate_conversion#Datum_transformations

我们可以发现，当z变化时，返回回去的X,Y都有变化，即（2.00538462e-01  8.84053396e-01）和（2.0053839e-01 8.8405308e-01）相较于原来的
（.20053839 , 0.88405308）都有点变化，但是X和Y上的引起变化的来源不一样。
过程都是XYZ --<1>-> LLA --<2>-> XYZ
对X：转化后的X和原始的X不一样，是由于两次转换过程中的公式的转换误差造成的
对Y：除了公式的转换误差（变化来源1），在<1>中，根据公式，latitude和Z值有关（变化来源12）

总结：采样的时候，由于要用固定采样spherical design， 我们需要从XYZ出发，在单位球体表面采样【初采样方式1】和在以6378137.0（地球赤道平均半径）为半径的球体表面上采样【初采样方式2】，转化后的经纬度是不一样的。
需要注意，我们没办法保证转化后的LLA坐标对应的椭球体（不是标准的）上也是spherical design，也很难证明到底哪个【初采样方式？】更能让转化过去的椭球体上更接近spherical design。

⚠️最终我们采用【初采样方式2】，因为【初采样方式1】转换过去的纬度latitude超出了范围。虽然海拔有负值，但是在单位球上采样，转过去的海拔，负的太多，公式造成的转换误差很大。
其实如果纬度不超过范围，我们用单位球采样也是可以的，因为X，Y上的误差看起来都很小，但是纬度的超出让我们看到，这个肉眼看起来很小的误差（XYZ上），（在LLA上）是不可容忍的。


'''

# XYZ1 = np.array([[ 0.20053839 , 0.88405308 , 0.42217829]])
# print(XYZ1)
# print(XYZ_to_LLA(XYZ1))
# print(LLA_to_XYZ(XYZ_to_LLA(XYZ1)))
# # [[0.20053839 0.88405308 0.42217829]]
# # [[ 7.72193248e+01  1.74153707e+02 -6.37835943e+06]]  # LLA中的latitude和altitude受Z的影响较大，longitude不受影响，这个容易理解，因为公式里，longitude只和X， Y有关
# # [[ 2.00538462e-01  8.84053396e-01 -4.34943289e+03]]  # 当Z很小，经过转换后返回的Z距离原始的z较远； XY都比较准确


# XYZ1 = np.array([[ 0.20053839 , 0.88405308 , 422178.29]])
# print(XYZ1)
# print(XYZ_to_LLA(XYZ1))
# print(LLA_to_XYZ(XYZ_to_LLA(XYZ1)))
# # [[2.0053839e-01 8.8405308e-01 4.2217829e+05]]
# # [[ 7.72193248e+01  8.99998883e+01 -5.93457402e+06]]
# # [[2.0053839e-01 8.8405308e-01 4.2217829e+05]]         # 当Z很大，经过转换后返回的Z会很接近原始的z；XY都比较准确


# XYZ1 = np.array([[ 200538.39 , 884053.08 , 422178.29]])  # 不管是Z变化还是XYZ scale变化，logitude都不变，latitude都变化
# print(XYZ1)
# print(XYZ_to_LLA(XYZ1))
# print(LLA_to_XYZ(XYZ_to_LLA(XYZ1)))
# # [[200538.39 884053.08 422178.29]]
# # [[ 7.72193248e+01  2.59353284e+01 -5.37419092e+06]]
# # [[200538.3899988  884053.07999472 422183.85903363]]


'''以下是之前的用赤道半径为球体半径的采样'''
# machine learning/4_Spectral approach on spheres/之前的/real data_geo_random_tdesign_original/geo_data/get_data_uniform_2016.py
# ------------------------------------------------------------------------------ real data: geo
# XYZ_train:
#  [[ 1279061.30581477  5638611.65057005  2692710.97981052]   # XYZ （在以赤道半径为球心的球体表面进行采样）
#  [ 1677338.83435539 -2853112.48746247  5452239.46277289]
#  [ -652353.8665089   4094908.06330874  4846317.5686978 ]
#  [-2356531.07430792  5897975.93851537   584185.5144421 ]
#  [  713706.87935995  4464004.8182929  -4499323.84513285]]

# [[ 7.72193250e+01  2.51197036e+01  3.82728344e+03]          # XYZ--->LLA
#  [-5.95488191e+01  5.89112743e+01  1.56477194e+04]
#  [ 9.90516445e+01  4.96390985e+01  1.23725681e+04]
#  [ 1.11779136e+02  5.29040906e+00  1.80296252e+02]
#  [ 8.09164047e+01 -4.50563282e+01  1.06685395e+04]]

# [[ 1279061.30581364  5638611.65056504  2692710.97983487]    # LLA--->XYZ 会产生很小的误差
#  [ 1677338.83434932 -2853112.48745214  5452239.46280999]
#  [ -652353.86650703  4094908.06329701  4846317.5687339 ]
#  [-2356531.07430782  5897975.93851512   584185.51444787]
#  [  713706.87935818  4464004.81828187 -4499323.8451677 ]]

'''-------------------------- 测试结束--------------------------------------'''


'''
'XYZ_train', 'XYZ_tes', 
'LLA_train', 'LLA_tes', 
'YF_train', 'YD_train', 'YI_train', 
'YF_tes', 'YD_tes', 'YI_tes', 
'XYZ_train_unit', 'XYZ_tes_unit'
'YF_train_unit', 'YD_train_unit', 'YI_train_unit', 
'YF_tes_unit', 'YD_tes_unit', 'YI_tes_unit', 
'KI_condi', 'KI_rmse_YF', 'KI_rmse_YD', 'KI_rmse_YI', 
'KRR_rmse_YF', 'KRR_rmse_YD', 'KRR_rmse_YI', 
'cv_lambdas_YF_KRR', 'cv_errors_YF_KRR', 'cv_lambdas_YD_KRR', 'cv_errors_YD_KRR', 'cv_lambdas_YI_KRR', 'cv_errors_YI_KRR', 
'lambda_YF_KRR', 'lambda_YD_KRR', 'lambda_YI_KRR', 
'cv_errors_YF_TSVD', 'cv_lambdas_YF_TSVD', 'cv_errors_YD_TSVD', 'cv_lambdas_YD_TSVD', 'cv_errors_YI_TSVD', 'cv_lambdas_YI_TSVD', 
'cv_errors_YF_KGD', 'cv_steps_YF_KGD', 'cv_errors_YD_KGD', 'cv_steps_YD_KGD', 'cv_errors_YI_KGD', 'cv_steps_YI_KGD', 
'KGD_rmse_YF', 'KGD_rmse_YD', 'KGD_rmse_YI', 
'step_YF_KGD', 'step_YD_KGD', 'step_YI_KGD', 
'KI_fit_YF', 'KI_fit_YD', 'KI_fit_YI', 
'KRR_fit_YF', 'KRR_fit_YD', 'KRR_fit_YI', 
'TSVD_rmse_YF', 'TSVD_rmse_YD', 'TSVD_rmse_YI', 
'lambda_YF_TSVD', 'lambda_YD_TSVD', 'lambda_YI_TSVD', 
'TSVD_fit_YF', 'TSVD_fit_YD', 'TSVD_fit_YI', 
'KI_fit_YF_ori', 'KI_fit_YD_ori', 'KI_fit_YI_ori', 
'KRR_fit_YF_ori', 'KRR_fit_YD_ori', 'KRR_fit_YI_ori', 
'KGD_fit_YF_ori', 'KGD_fit_YD_ori', 'KGD_fit_YI_ori', 
'KGD_fit_YF', 'KGD_fit_YD', 'KGD_fit_YI', 
'TSVD_fit_YF_ori', 'TSVD_fit_YD_ori', 'TSVD_fit_YI_ori'
'''


