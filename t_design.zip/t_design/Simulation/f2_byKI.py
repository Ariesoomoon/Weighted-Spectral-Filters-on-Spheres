import os, time
from Spectral_algorithms import XYZ_from_matfile, fun_rotation_mat, generate_data, Predicted_KI, Predicted_KRR, \
    Predicted_KGD, Predicted_TSVD, KRR_condi_lambda, KGD_condi_step, TSVD_condi_nu, parameter_lambda_krr_forplot, \
    parameter_step_kgd_forplot, parameter_lambda_TSVD_forplot, parameter_lambda_krr
import pandas as pd
from numpy import *
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib import rcParams
import matplotlib.gridspec as gridspec
from matplotlib.ticker import FuncFormatter
time_start = time.time()


'''0. set up'''
func = 'f2'  # from paper "DIVIDE AND CONQUER LEAST SQAURES FOR UNCERTAINTY OF KERNEL INTERPOLATION ON SPHERES"
f, d = 5, 3  # folds of corss-validation; dimension of the input X
test_size = (100, 3)
trails = 5


'''
------------------------------------ 1. Increase the amount of data by increase the "t" in t-design -------------------------------------
Observe the RMSE of KI changes along with the increasing N when noise = 0, 0.001, 0.01, 0.1, 0.3, 0.5
'''

# f2_h3k_tdesign = {} # function name: f2, kernel name:h3k, data increasing way: t (of t-design) increases
# np.save('/Users/liuxiaotong/Documents/machine learning/4_Spectral approach on spheres/t_design/Result_data/f2_h3k_tdesign.npy', f2_h3k_tdesign)
# print('save f2_h3k_tdesign.npy done')

loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/f2_h3k_tdesign.npy', allow_pickle=True)
f2_h3k_tdesign = loadData.tolist()
print(f2_h3k_tdesign.keys())


''' 1.1 caculate RMSE '''
# np.random.seed(1)
# noise_sd = 0.0
# t_designs, data_sizes, rmses, condis = [], [], [], []
# for i in range(16):
#     t_design = 3 + i*4 # t_design = 3,7,...,63; and corresponding data size = 6,32,..,.2018
#     XYZ_train = XYZ_from_matfile(t_design)
#     t_designs.append(t_design)
#     data_sizes.append(len(XYZ_train))
#
#     X_train, y_train, X_test, y_test = generate_data(XYZ_train, test_size, func, noise_sd)  # generate the (len(XYZ_train), d) training data set and (100, 3) testing data set
#     Pred = Predicted_KI(X_train, y_train, X_test, y_test, d)
#     rmse, condi = Pred[1], Pred[2]
#     rmses.append(rmse)
#     condis.append(condi)
#     print('RMSEs:', rmses)
#
#
# # noise_sd = 0.0
# f2_h3k_tdesign['KI_rmse_noi0'] = rmses
# f2_h3k_tdesign['KI_ts'] = t_designs
# f2_h3k_tdesign['KI_sizes'] = data_sizes
# f2_h3k_tdesign['KI_condi'] = condis
#
# # noise_sd = 0.001
# f2_h3k_tdesign['KI_rmse_noi001'] = rmses
#
# # noise_sd = 0.01
# f2_h3k_tdesign['KI_rmse_noi01'] = rmses
#
# # noise_sd = 0.1
# f2_h3k_tdesign['KI_rmse_noi1'] = rmses
#
# # noise_sd = 0.3
# f2_h3k_tdesign['KI_rmse_noi3'] = rmses
#
# # noise_sd = 0.5
# f2_h3k_tdesign['KI_rmse_noi5'] = rmses
#
#
# np.save(os.path.dirname(os.getcwd()) + '/Result_data/f2_h3k_tdesign.npy', f2_h3k_tdesign)
# print('save f2_h3k_tdesign.npy done')
# print(f2_h3k_tdesign.keys())
# time_total = time.time() - time_start
# print('runing time:', time_total)





'''2: RMSE for 5 trails, 5-cv '''
noise_sd = 0.5 # 0.1, 0.3, 0.5
rmses_ki_t5 = np.empty(shape=(16, 5))
trails = 5
for trail in range(trails):
    time_start = time.time()
    rmses_ki = []
    np.random.seed(trail)
    print('------------------------------------------------ trail:', trail + 1)
    for i in range(16):
        t_design = 3 + i * 4
        print('------------------------------------------------ t_design:', t_design)
        XYZ_train = XYZ_from_matfile(t_design)
        X_train, y_train, X_test, y_test = generate_data(XYZ_train, test_size, func, noise_sd)

        # KI
        Pred = Predicted_KI(X_train, y_train, X_test, y_test, d)[1]
        rmses_ki.append(Pred)

    rmses_ki_ar = np.array(rmses_ki)
    rmses_ki_t5[:, trail] = np.squeeze(rmses_ki_ar)
    time_total = time.time() - time_start
    print('runing time for 1 trail:', time_total) # runing time for 1 trail: 1467.094449043274, 24min


f2_h3k_tdesign['KI_rmse_noi5_5trails'] = rmses_ki_t5
# f2_h3k_rotation['KI_rmse_noi3_5trails'] = rmses_ki_t5
# f2_h3k_rotation['KI_rmse_noi1_5trails'] = rmses_ki_t5
np.save(os.path.dirname(os.getcwd()) + '/Result_data/f2_h3k_tdesign.npy', f2_h3k_tdesign)
print('save f2_h3k_tdesign.npy done')
print(f2_h3k_tdesign.keys())
time_total = time.time() - time_start
print('runing time:', time_total)




