import os, time
from Spectral_algorithms import XYZ_from_matfile, fun_rotation_mat, generate_data, Predicted_KI, Predicted_KRR, \
    Predicted_KGD, Predicted_TSVD, KRR_condi_lambda, KGD_condi_step, TSVD_condi_nu, parameter_lambda_krr_forplot, \
    parameter_step_kgd_forplot, parameter_lambda_TSVD_forplot, parameter_lambda_krr, parameter_step_kgd, RMSE_parameter_kgd
import pandas as pd
from numpy import *
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib import rcParams
import matplotlib.gridspec as gridspec
from matplotlib.ticker import FuncFormatter
time_start = time.time()
config = {
    "font.family":'Times New Roman',
    "font.size": 15,
#     "mathtext.fontset":'stix',
}
rcParams.update(config)


'''0. set up'''
func = 'f2'  # from paper "DIVIDE AND CONQUER LEAST SQAURES FOR UNCERTAINTY OF KERNEL INTERPOLATION ON SPHERES"
f, d = 5, 3  # folds of corss-validation; dimension of the input X
test_size = (100, 3)
trails = 5

loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/f2_h3k_tdesign.npy', allow_pickle=True)
f2_h3k_tdesign = loadData.tolist()
print(f2_h3k_tdesign.keys())


''' 1. KGD reduces the condition number of 10974.549734760414 when t=47, n=1130, 1 trail'''
# np.random.seed(1)
# noise_sd = 0.0
# XYZ_train = XYZ_from_matfile(47)
# X_train, y_train, X_test, y_test = generate_data(XYZ_train, test_size, func, noise_sd)  # generate the (len(XYZ_train), d) training data set and (100, 3) testing data set

# t47_steps, t47_condis = KGD_condi_step(X_train, y_train, d)
# f2_h3k_tdesign['t47_steps_KGD'] = t47_steps
# f2_h3k_tdesign['t47_condisdrop_KGD'] = t47_condis
# np.save(os.path.dirname(os.getcwd()) + '/Result_data/f2_h3k_tdesign.npy', f2_h3k_tdesign)
# print('save f2_h3k_tdesign.npy done')
# print(f2_h3k_tdesign.keys())
# time_total = time.time() - time_start
# print('runing time:', time_total) # 1788'


# # plot
# condis_ori = f2_h3k_tdesign['KI_condi'][11] # original condition number when t=47, n=1130
# print(condis_ori) # 10974.549734760414
# ts_KGD = f2_h3k_tdesign['t47_steps_KGD']
# condisdrop_KGD = f2_h3k_tdesign['t47_condisdrop_KGD']
# # print(condisdrop_KGD)
# # print(ts_KGD)
#
# fig = plt.figure(tight_layout=True)
# gs = gridspec.GridSpec(1, 1)
# ax = fig.add_subplot(gs[0, 0])
# ax.grid(linestyle='-.', axis="y")
#
# plt.axhline(condis_ori,ls="--",c="forestgreen", linewidth=1.2)
# ax.plot(ts_KGD, condisdrop_KGD, c='royalblue', linestyle='-', linewidth=1.2)
# ax.set_xlabel('$t$', fontsize='13')
# ax.set_ylabel('Condition number', fontsize='13')
# plt.yscale('log')
# plt.title('Landweber Iteration', fontsize='12')
# plt.legend(['original condition number','condition number under KGD'], loc='upper right', fontsize='medium')
# plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/f2/KGDdropsCondi_t(t=47).pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.show()


''' 2. KGD makes the RMSE(prediction error) smaller. 5 trail, 5-cv'''
'''2.1: test first the range the optimal regularization parameter may located in, 1 trail, 5-cv'''
# np.random.seed(6)
# noise_sd = 0.5
# XYZ_train = XYZ_from_matfile(63)
# # 3,7,...,63
# X_train, y_train, X_test, y_test = generate_data(XYZ_train, test_size, func, noise_sd)
#
# pred = parameter_step_kgd_forplot(X_train, y_train, f, d)
# errors, lambda_opts = pred[0], pred[1]
#
# fig = plt.figure(tight_layout=True)
# gs = gridspec.GridSpec(1, 1)
# ax = fig.add_subplot(gs[0, 0])
# ax.grid(linestyle='-.')
# ax.plot(lambda_opts, errors, c='black', linestyle='-.', linewidth=1.4)
# ax.set_xlabel('$t$', fontsize='13')
# ax.set_ylabel('RMSE($\\sigma$=0.5)', fontsize='13')
# plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/f2_test_para_range/KGD_cv_test(t=63).pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.show()
# time_total = time.time() - time_start
# print('runing time:', time_total)


'''2.2: RMSE for 5 trails, 5-cv '''
noise_sd = 0.5
rmse_krr_t5, rmse_kgd_t5, rmse_tsvd_t5 = np.empty(shape=(16, 5)), np.empty(shape=(16, 5)), np.empty(shape=(16, 5))
trails = 5
for trail in range(trails):
    time_start = time.time()
    rmse_krrs, rmse_kgds, rmse_tsvds = [], [], []
    np.random.seed(trail)
    print('------------------------------------------------ trail:', trail + 1)
    for i in range(16):
        t_design = 3 + i * 4
        print('------------------------------------------------ t_design:', t_design)
        XYZ_train = XYZ_from_matfile(t_design)
        X_train, y_train, X_test, y_test = generate_data(XYZ_train, test_size, func, noise_sd)

        # # KGD
        step_opt = parameter_step_kgd(X_train, y_train, f, d, t_design)
        rmse_kgd = Predicted_KGD(X_train, y_train, X_test, y_test, d, step_opt)[1]

        rmse_kgds.append(rmse_kgd)
        print('rmse_kgds:', rmse_kgds)

    rmse_kgds_ar = np.array(rmse_kgds)
    rmse_kgd_t5[:, trail] = np.squeeze(rmse_kgds_ar)
    time_total = time.time() - time_start
    print('runing time for 1 trail:', time_total)


f2_h3k_tdesign['KGD_rmse_noi5_5trails'] = rmse_kgd_t5
# f2_h3k_tdesign['KGD_rmse_noi3_5trails'] = rmse_kgd_t5
# f2_h3k_tdesign['KGD_rmse_noi1_5trails'] = rmse_kgd_t5
# f2_h3k_tdesign['KGD_rmse_noi01_5trails'] = rmse_kgd_t5
# f2_h3k_tdesign['KGD_rmse_noi001_5trails'] = rmse_kgd_t5
np.save(os.path.dirname(os.getcwd()) + '/Result_data/f2_h3k_tdesign.npy', f2_h3k_tdesign)
print('save f2_h3k_tdesign.npy done')
print(f2_h3k_tdesign.keys())
time_total = time.time() - time_start
print('runing time:', time_total)








