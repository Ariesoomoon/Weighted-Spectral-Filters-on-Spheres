import os, time
from Spectral_algorithms import XYZ_from_matfile, fun_rotation_mat, generate_data, Predicted_KI, Predicted_KRR, \
    Predicted_KGD, Predicted_TSVD, KRR_condi_lambda, KGD_condi_step, TSVD_condi_nu, parameter_lambda_krr_forplot, \
    parameter_step_kgd_forplot, parameter_lambda_TSVD_forplot, parameter_lambda_krr, RMSE_parameter_krr, RMSE_parameter_kgd, RMSE_parameter_tsvd
import pandas as pd
from numpy import *
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib import rcParams
import matplotlib.gridspec as gridspec
from matplotlib.ticker import FuncFormatter
time_start = time.time()
config = {
    "font.family":'Times New Roman',
    "font.size": 20,
#     "mathtext.fontset":'stix',
}
rcParams.update(config)


'''0. set up'''
func = 'f2'  # from paper "DIVIDE AND CONQUER LEAST SQAURES FOR UNCERTAINTY OF KERNEL INTERPOLATION ON SPHERES"
f, d = 5, 3  # folds of corss-validation; dimension of the input X
test_size = (100, 3)
trails = 5

loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/f2_h3k_tdesign.npy', allow_pickle=True)
f2_h3k_tdesign = loadData.tolist()
print(f2_h3k_tdesign.keys())


''' 1. KRR reduces the condition number of 10974.549734760414 when t=47, n=1130, 1 trail'''
# np.random.seed(1)
# noise_sd = 0.0
# XYZ_train = XYZ_from_matfile(47)
# X_train, y_train, X_test, y_test = generate_data(XYZ_train, test_size, func, noise_sd)  # generate the (len(XYZ_train), d) training data set and (100, 3) testing data set

# t47_lambdas, t47_condis = KRR_condi_lambda(X_train, y_train, d)
# f2_h3k_tdesign['t47_lambdas_KRR'] = t47_lambdas
# f2_h3k_tdesign['t47_condisdrop_KRR'] = t47_condis
# np.save(os.path.dirname(os.getcwd()) + '/Result_data/f2_h3k_tdesign.npy', f2_h3k_tdesign)
# print('save f2_h3k_tdesign.npy done')
# print(f2_h3k_tdesign.keys())
# time_total = time.time() - time_start
# print('runing time:', time_total)

#
# # plot
# condis_ori = f2_h3k_tdesign['KI_condi'][11] # original condition number when t=47, n=1130
# print(condis_ori) # 10974.549734760414
# mus_KRR = f2_h3k_tdesign['t47_lambdas_KRR']
# condisdrop_KRR = f2_h3k_tdesign['t47_condisdrop_KRR']
# # print(condisdrop_KRR)
# # print(mus_KRR)
#
# fig = plt.figure(tight_layout=True)
# gs = gridspec.GridSpec(1, 1)
# ax = fig.add_subplot(gs[0, 0])
# ax.grid(linestyle='-.', axis="y")
#
# plt.axhline(condis_ori,ls="--",c="forestgreen", linewidth=1.2)
# ax.plot(mus_KRR, condisdrop_KRR, c='royalblue', linestyle='-', linewidth=1.2)
# ax.set_xlabel('$\\mu$', fontsize='13')
# ax.set_ylabel('Condition number', fontsize='13')
# plt.yscale('log')
# plt.title('Tikhonov regularization', fontsize='12')
# plt.legend(['original condition number','condition number under KRR'], loc='upper right', fontsize='medium')
# plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/f2/KRRdropsCondi_mu(t=47).pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.show()


''' 2. KRR makes the RMSE(prediction error) smaller. 5 trail, 5-cv'''
'''2.1: test first the range the optimal regularization parameter may located in, 1 trail, 5-cv'''
# np.random.seed(1)
# noise_sd = 0.5
# XYZ_train = XYZ_from_matfile(15)
# # 3,7,...,63
# X_train, y_train, X_test, y_test = generate_data(XYZ_train, test_size, func, noise_sd)
#
# pred = parameter_lambda_krr_forplot(X_train, y_train, f, d)
# errors, lambda_opts = pred[0], pred[1]
#
# fig = plt.figure(tight_layout=True)
# gs = gridspec.GridSpec(1, 1)
# ax = fig.add_subplot(gs[0, 0])
# ax.grid(linestyle='-.')
# ax.plot(lambda_opts, errors, c='black', linestyle='-.', linewidth=1.4)
# ax.set_xlabel('$\\mu$', fontsize='13')
# ax.set_ylabel('RMSE($\\sigma$=0.5)', fontsize='13')
# plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/f2_test_para_range/KRR_cv_test(t=15).pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.show()
# time_total = time.time() - time_start
# print('runing time:', time_total)


'''2.2: RMSE for 5 trails, 5-cv '''
noise_sd = 0.3
rmse_krr_t5, rmse_kgd_t5, rmse_tsvd_t5 = np.empty(shape=(16, 5)), np.empty(shape=(16, 5)), np.empty(shape=(16, 5))
# step_sta, step_end = 2, 200
trails = 5
for trail in range(trails):
    time_start = time.time()
    rmse_krrs, rmse_kgds, rmse_tsvds = [], [], []
    np.random.seed(trail)
    print('------------------------------------------------ trail:', trail + 1)
    for i in range(16):
        t_design = 3 + i * 4
        print('------------------------------------------------ t_design:', t_design)
        XYZ_train = XYZ_from_matfile(t_design)
        X_train, y_train, X_test, y_test = generate_data(XYZ_train, test_size, func, noise_sd)

        # KRR
        lambda_opt = parameter_lambda_krr(X_train, y_train, f, d)
        rmse_krr = Predicted_KRR(X_train, y_train, X_test, y_test, d, lambda_opt)[1]

        rmse_krrs.append(rmse_krr)
        print('rmse_krrs:', rmse_krrs)

    rmse_krrs_ar = np.array(rmse_krrs)
    rmse_krr_t5[:, trail] = np.squeeze(rmse_krrs_ar)

    time_total = time.time() - time_start
    print('runing time for 1 trail:', time_total) # runing time for 1 trail: 1467.094449043274, 24min


# f2_h3k_tdesign['KRR_rmse_noi5_5trails'] = rmse_krr_t5
f2_h3k_tdesign['KRR_rmse_noi3_5trails'] = rmse_krr_t5
# f2_h3k_tdesign['KRR_rmse_noi1_5trails'] = rmse_krr_t5
# f2_h3k_tdesign['KRR_rmse_noi01_5trails'] = rmse_krr_t5
# f2_h3k_tdesign['KRR_rmse_noi001_5trails'] = rmse_krr_t5
np.save(os.path.dirname(os.getcwd()) + '/Result_data/f2_h3k_tdesign.npy', f2_h3k_tdesign)
print('save f2_h3k_tdesign.npy done')
print(f2_h3k_tdesign.keys())
time_total = time.time() - time_start
print('runing time:', time_total)








