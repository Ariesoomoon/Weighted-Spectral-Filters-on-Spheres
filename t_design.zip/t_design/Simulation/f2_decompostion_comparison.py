import os, time
from Spectral_algorithms import XYZ_from_matfile, fun_rotation_mat, generate_data, Predicted_KI, Predicted_KRR, \
    Predicted_KGD, Predicted_TSVD, KRR_condi_lambda, KGD_condi_step, TSVD_condi_nu, parameter_lambda_krr_forplot, \
    parameter_step_kgd_forplot, parameter_lambda_TSVD_forplot, parameter_lambda_krr, RMSE_parameter_krr, RMSE_parameter_kgd, RMSE_parameter_tsvd
import pandas as pd
from numpy import *
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib import rcParams
import matplotlib.gridspec as gridspec
from matplotlib.ticker import FuncFormatter
time_start = time.time()
config = {
    "font.family":'Times New Roman',
    "font.size": 23,
#     "mathtext.fontset":'stix',
}
rcParams.update(config)


'''0. set up'''
func = 'f2'  # from paper "DIVIDE AND CONQUER LEAST SQAURES FOR UNCERTAINTY OF KERNEL INTERPOLATION ON SPHERES"
f, d = 5, 3  # folds of corss-validation; dimension of the input X
test_size = (100, 3)
trails = 5


'''1. How do bias and variance change， 1 trail, no cv, we still fix the data size to 1130(t=47)'''
'''1.1 calculate RMSE'''
# loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/Bias_var_com.npy', allow_pickle=True)
# Bias_var_com = loadData.tolist()
# print(Bias_var_com.keys())
# 
# np.random.seed(1)
# noise_sd = 0.0 # 0.0, 0.01, 0.1, 0.5
# XYZ_train = XYZ_from_matfile(47)
# X_train, y_train, X_test, y_test = generate_data(XYZ_train, test_size, func, noise_sd)  # generate the (len(XYZ_train), d) training data set and (100, 3) testing data set


# ##(1). KRR
# mus, rmses = RMSE_parameter_krr(X_train, y_train, X_test, y_test, d)
# # Bias_var_com['KRR_rmse_noi5_1trail'] = rmses
# # Bias_var_com['KRR_mus_noi5_1trail'] = mus
# Bias_var_com['KRR_rmse_noi0_1trail'] = rmses

##(2). KGD
# step_list = [1,2,5,10, 50, 550, 1050, 1550, 2050, 2550, 3050, 3550, 4050, 4550, 5050, 5550, 6050, 6550, 7050] # noise=0.5
# ts, rmses = RMSE_parameter_kgd(X_train, y_train, X_test, y_test, d, step_list)
# Bias_var_com['KGD_rmse_noi5_1trail'] = rmses
# Bias_var_com['KGD_ts_noi5_1trail'] = ts
# Bias_var_com['KGD_rmse_noi0_1trail'] = rmses

#(3).TSVD
# nus, rmses = RMSE_parameter_tsvd(X_train, y_train, X_test, y_test, d)
# Bias_var_com['TSVD_rmse_noi5_1trail'] = rmses
# Bias_var_com['TSVD_nus_noi5_1trail'] = nus
# Bias_var_com['TSVD_rmse_noi0_1trail'] = rmses
#
# np.save(os.path.dirname(os.getcwd()) + '/Result_data/Bias_var_com.npy', Bias_var_com)
# print('save Bias_var_com.npy done')
# print(Bias_var_com.keys())
# time_total = time.time() - time_start
# print('runing time:', time_total)



# TSVD_noi5 = Bias_var_com['TSVD_rmse_noi5_1trail_new']
# TSVD_noi5_min_index = TSVD_noi5.index(min(TSVD_noi5))
# TSVD_noi5_min = min(TSVD_noi5)
# TSVD_noi0_bias = Bias_var_com['TSVD_rmse_noi0_1trail_new'][TSVD_noi5_min_index]
# TSVD_noi5_min_variance = TSVD_noi5_min - TSVD_noi0_bias
# nus = Bias_var_com['TSVD_nus_noi5_1trail_new']
# nus_min = nus[TSVD_noi5_min_index]
# # print('TSVD_noi5_min_index:', TSVD_noi5_min_index)
# # print('nus_min:', nus_min)
# # TSVD_noi5_min_index: 53
# # nus_min: 13.25

