import os, time
from Spectral_algorithms import XYZ_from_matfile, fun_rotation_mat, generate_data, Predicted_KI, Predicted_KRR, \
    Predicted_KGD, Predicted_TSVD, KRR_condi_lambda, KGD_condi_step, TSVD_condi_nu, parameter_lambda_krr_forplot, \
    parameter_step_kgd_forplot, parameter_lambda_TSVD_forplot, parameter_lambda_krr, RMSE_parameter_krr, RMSE_parameter_kgd, RMSE_parameter_tsvd
import pandas as pd
from numpy import *
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib import rcParams
import matplotlib.gridspec as gridspec
from matplotlib.ticker import FuncFormatter
time_start = time.time()
config = {
    "font.family":'Times New Roman',
    "font.size": 23,
    "mathtext.fontset":'stix',
}
rcParams.update(config)


loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/Bias_var_com.npy', allow_pickle=True)
Bias_var_com = loadData.tolist()
print(Bias_var_com.keys())

'''-------------------------- KRR --------------------------------------'''
# KRR_mus = Bias_var_com['KRR_mus_noi5_1trail']
# KRR_bias = Bias_var_com['KRR_rmse_noi0_1trail']      # bias
# KRR_rmse_noi5 = Bias_var_com['KRR_rmse_noi5_1trail'] # total rmse
#
# '''---------------- 为了画的图好看而调整的 ------------------'''
# print(KRR_mus)
# print(len(KRR_mus))
# KRR_mus = KRR_mus[::2]
# KRR_bias = KRR_bias[::2]
# KRR_rmse_noi5 = KRR_rmse_noi5[::2]
# print(KRR_mus)
# print(len(KRR_mus))
# '''-------------------------------------------------------'''
#
# KRR_bias_ar = np.array(KRR_bias)
# KRR_rmse_noi5_ar = np.array(KRR_rmse_noi5)
# KRR_noi5_variance = KRR_rmse_noi5_ar - KRR_bias_ar   # variance
# print(KRR_rmse_noi5)
#
# fig = plt.figure(tight_layout=True)
# gs = gridspec.GridSpec(1, 1)
# ax = fig.add_subplot(gs[0, 0])
# ax.grid(linestyle='-.', axis="y")
# ax.plot(KRR_mus, KRR_bias, c='orange', marker='d',  linestyle='--', linewidth=1.2, markersize=5)
# ax.plot(KRR_mus, KRR_noi5_variance, c='forestgreen', marker='s', markersize=4,  linestyle='--', linewidth=1.2)
# ax.plot(KRR_mus, KRR_rmse_noi5, c='royalblue', marker='o',  linestyle='--', linewidth=1.2, markersize=4)
# ax.set_xlabel('$\\mu$', fontsize='23')
# ax.set_ylabel('RMSE', fontsize='23')
# # plt.yscale('log')
# # plt.title('Tikhonov Regularization', fontsize='12')
# # plt.ylim(0.0, 0.5)
# plt.legend(['Fitting part','Stability part', 'Approximation error',], loc='upper right', fontsize=20)
# plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/f2/KRR_Bias_Var_1130_(tdesign).pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.show()



'''-------------------------- KGD --------------------------------------'''
# KGD_ts = Bias_var_com['KGD_ts_noi5_1trail']
# KGD_bias = Bias_var_com['KGD_rmse_noi0_1trail']      # bias
# KGD_rmse_noi5 = Bias_var_com['KGD_rmse_noi5_1trail'] # total rmse
# KGD_bias_ar = np.array(KGD_bias)
# KGD_rmse_noi5_ar = np.array(KGD_rmse_noi5)
# KGD_noi5_variance = KGD_rmse_noi5_ar - KGD_bias_ar   # variance
#
# fig = plt.figure(tight_layout=True)
# gs = gridspec.GridSpec(1, 1)
# ax = fig.add_subplot(gs[0, 0])
# ax.grid(linestyle='-.', axis="y")
# ax.plot(KGD_ts, KGD_bias, c='orange', marker='d',  linestyle='--', linewidth=1.2, markersize=5)
# ax.plot(KGD_ts, KGD_noi5_variance, c='forestgreen', marker='s', markersize=4,  linestyle='--', linewidth=1.2)
# ax.plot(KGD_ts, KGD_rmse_noi5, c='royalblue', marker='o',  linestyle='--', linewidth=1.2, markersize=4)
# ax.set_xlabel('$t$', fontsize='23')
# ax.set_ylabel('RMSE', fontsize='23')
# plt.ylim(-0.01, 0.23)
# # plt.title('Landweber Iteration', fontsize='12')
# plt.legend(['Fitting part','Stability part', 'Approximation error',], loc='upper right', fontsize=20)
# plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/f2/KGD_Bias_Var_1130_(tdesign).pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.show()




'''-------------------------- TSVD --------------------------------------'''
TSVD_nus = Bias_var_com['TSVD_nus_noi5_1trail']
TSVD_bias = Bias_var_com['TSVD_rmse_noi0_1trail']      # bias
TSVD_rmse_noi5 = Bias_var_com['TSVD_rmse_noi5_1trail'] # total rmse

'''------------ 为了画的图好看而调整的 ----------------------'''
print(TSVD_nus)
print(len(TSVD_nus))
TSVD_nus = TSVD_nus[::3]
TSVD_bias = TSVD_bias[::3]
TSVD_rmse_noi5 = TSVD_rmse_noi5[::3]
print(TSVD_nus)
print(len(TSVD_nus))
'''-------------------------------------------------------'''
TSVD_bias_ar = np.array(TSVD_bias)
TSVD_rmse_noi5_ar = np.array(TSVD_rmse_noi5)
TSVD_noi5_variance = TSVD_rmse_noi5_ar - TSVD_bias_ar   # variance
print(TSVD_nus)

fig = plt.figure(tight_layout=True)
gs = gridspec.GridSpec(1, 1)
ax = fig.add_subplot(gs[0, 0])
ax.grid(linestyle='-.', axis="y")
ax.plot(TSVD_nus, TSVD_bias, c='orange', marker='d',  linestyle='--', linewidth=1.2, markersize=5)
ax.plot(TSVD_nus, TSVD_noi5_variance, c='forestgreen', marker='s', markersize=4,  linestyle='--', linewidth=1.2)
ax.plot(TSVD_nus, TSVD_rmse_noi5, c='royalblue', marker='o',  linestyle='--', linewidth=1.2, markersize=4)
ax.set_xlabel('$\\nu$', fontsize='23')
ax.set_ylabel('RMSE', fontsize='23')
# plt.title('Spectral Cut-off', fontsize='13')
plt.legend(['Fitting part','Stability part', 'Approximation error',], loc='upper right', fontsize=16)
plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/f2/TSVD_Bias_Var_1130_(tdesign)_new.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
plt.show()






