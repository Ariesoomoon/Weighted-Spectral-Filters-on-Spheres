import os, time
from Spectral_algorithms import XYZ_from_matfile, fun_rotation_mat, generate_data, Predicted_KI, Predicted_KRR, \
    Predicted_KGD, Predicted_TSVD, KRR_condi_lambda, KGD_condi_step, TSVD_condi_nu, parameter_lambda_krr_forplot, \
    parameter_step_kgd_forplot, parameter_lambda_TSVD_forplot, parameter_lambda_krr
import pandas as pd
from numpy import *
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib import rcParams
import matplotlib.gridspec as gridspec
from matplotlib.ticker import FuncFormatter
time_start = time.time()

config = {
    "font.family":'Times New Roman',
    "font.size": 20,
    "mathtext.fontset":'stix',
}
rcParams.update(config)


loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/f2_h3k_tdesign.npy', allow_pickle=True)
f2_h3k_tdesign = loadData.tolist()
print(f2_h3k_tdesign.keys())


'''----------------------------- KI -----------------------------------'''
# sizes = f2_h3k_tdesign['KI_sizes']
# condis = f2_h3k_tdesign['KI_condi']
# fig = plt.figure(tight_layout=True)
# gs = gridspec.GridSpec(1, 1)
# ax = fig.add_subplot(gs[0, 0])
# ax.grid(linestyle='-.', axis="y")
#
# ax.plot(sizes, condis, c='royalblue', linestyle='-', linewidth=1.2) # condi=[1.0, 1.612599660652674, 9.749194001868375, 37.36974223496753, 112.17342650455599, 321.44248868690715, 671.5413553669802, 1398.157423632555, 2541.42629482062, 4215.898770110927, 7070.0432188056175, 10974.549734760414, 16801.509325642714, 25116.383505739737, 34138.36746585262, 47170.15263652693]
# ax.set_xlabel('The number of training samples', fontsize='14')
# ax.set_ylabel('Condition number', fontsize='13')
# plt.yscale('log')
# plt.ylim(0.9, 100000)  # you can't set the minimum y-value to 0 on a log scale since log(0) is not defined
# # plt.title('Kernel Interpolation', fontsize='12')
# plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/f2/KI_Condi_N(tdesign).pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.show()


