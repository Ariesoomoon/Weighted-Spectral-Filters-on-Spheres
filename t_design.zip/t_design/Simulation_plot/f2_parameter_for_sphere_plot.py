import os, time
from Spectral_algorithms import XYZ_from_matfile, fun_rotation_mat, generate_data, Predicted_KI, Predicted_KRR, \
    Predicted_KGD, Predicted_TSVD, KRR_condi_lambda, KGD_condi_step, TSVD_condi_nu, parameter_lambda_krr_forplot, \
    parameter_step_kgd_forplot, parameter_lambda_TSVD_forplot, parameter_lambda_krr, RMSE_parameter_krr, RMSE_parameter_kgd, RMSE_parameter_tsvd
import pandas as pd
from numpy import *
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib import rcParams
import matplotlib.gridspec as gridspec
from matplotlib.ticker import FuncFormatter
time_start = time.time()
config = {
    "font.family":'Times New Roman',
    "font.size": 13,
    "mathtext.fontset":'stix',
}
rcParams.update(config)




'''1. 检测绘制球面的时候，最优参数是否处在设定的参数选择范围内'''
'''1.1 calculate RMSE'''
loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/Bias_var_com.npy', allow_pickle=True)
Bias_var_com = loadData.tolist()
print(Bias_var_com.keys())
np.random.seed(1)


# (1). KRR
KRR_mus = Bias_var_com['KRR_mus_noi5_1trail']
print(KRR_mus)
KRR_rmse_noi5 = Bias_var_com['KRR_rmse_noi5_1trail'] # total rmse
KRR_rmse_noi1 = Bias_var_com['KRR_rmse_noi1_1trail'] # total rmse
KRR_rmse_noi3 = Bias_var_com['KRR_rmse_noi3_1trail'] # total rmse

fig = plt.figure(tight_layout=True)
gs = gridspec.GridSpec(1, 1)
ax = fig.add_subplot(gs[0, 0])
ax.grid(linestyle='-.', axis="y")
ax.plot(KRR_mus, KRR_rmse_noi1, c='royalblue', linestyle=':', linewidth=1.2)
ax.plot(KRR_mus, KRR_rmse_noi3, c='royalblue', linestyle='--', linewidth=1.2)
ax.plot(KRR_mus, KRR_rmse_noi5, c='royalblue', linestyle='-', linewidth=1.2)
ax.set_xlabel('$\\mu$ (|D|=1130)', fontsize='12')
ax.set_ylabel('RMSE', fontsize='12')
plt.title('KRR', fontsize='12')
# plt.yscale('log')
# plt.ylim(0.0, 0.5)
plt.legend(['$\\sigma=0.1$', '$\\sigma=0.3$', '$\\sigma=0.5$'], loc='upper right', fontsize='medium')
plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/f2_test_para_range/KRR_RMSE_N_noi531_1130.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
plt.show()



# #(2). KGD
# KGD_ts_noi5 = Bias_var_com['KGD_ts_noi5_1trail']
# # KGD_rmse_noi5 = Bias_var_com['KGD_rmse_noi5_1trail'] # total rmse
# KGD_ts_noi1 = Bias_var_com['KGD_ts_noi1_1trail']
# # KGD_rmse_noi1 = Bias_var_com['KGD_rmse_noi1_1trail'] # total rmse
# KGD_ts_noi3 = Bias_var_com['KGD_ts_noi3_1trail']
# # KGD_rmse_noi3 = Bias_var_com['KGD_rmse_noi3_1trail'] # total rmse
#
# print(KGD_ts_noi5)
# print(KGD_ts_noi3)
# print(KGD_ts_noi1)
#
# fig = plt.figure(tight_layout=True)
# gs = gridspec.GridSpec(1, 1)
# ax = fig.add_subplot(gs[0, 0])
# ax.grid(linestyle='-.', axis="y")
# # ax.plot(KGD_ts_noi1, KGD_rmse_noi1, c='royalblue', linestyle='-', linewidth=1.2)
# ax.plot(KGD_ts_noi3, KGD_rmse_noi3, c='royalblue', linestyle='-', linewidth=1.2)
# # ax.plot(KGD_ts_noi5, KGD_rmse_noi5, c='royalblue', linestyle='-', linewidth=1.2)
# ax.set_xlabel('$t$ (|D|=1130)', fontsize='12')
# ax.set_ylabel('RMSE', fontsize='12')
# plt.title('KGD', fontsize='12')
# plt.legend(['$\\sigma=0.3$'], loc='upper right', fontsize='medium')
# plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/f2_test_para_range/KGD_RMSE_N_noi3_1130.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.show()




# ##(3).TSVD
TSVD_mus = Bias_var_com['TSVD_nus_noi5_1trail']
# TSVD_rmse_noi5 = Bias_var_com['TSVD_rmse_noi5_1trail'] # total rmse
# TSVD_rmse_noi1 = Bias_var_com['TSVD_rmse_noi1_1trail'] # total rmse
# TSVD_rmse_noi3 = Bias_var_com['TSVD_rmse_noi3_1trail'] # total rmse
#
print(TSVD_mus)
# fig = plt.figure(tight_layout=True)
# gs = gridspec.GridSpec(1, 1)
# ax = fig.add_subplot(gs[0, 0])
# ax.grid(linestyle='-.', axis="y")
# ax.plot(TSVD_mus, TSVD_rmse_noi1, c='royalblue', linestyle=':', linewidth=1.2)
# ax.plot(TSVD_mus, TSVD_rmse_noi3, c='royalblue', linestyle='--', linewidth=1.2)
# ax.plot(TSVD_mus, TSVD_rmse_noi5, c='royalblue', linestyle='-', linewidth=1.2)
# ax.set_xlabel('$\\nu$ (|D|=1130)', fontsize='12')
# ax.set_ylabel('RMSE', fontsize='12')
# plt.title('TSVD', fontsize='12')
# # plt.yscale('log')
# # plt.ylim(0.0, 0.5)
# plt.legend(['$\\sigma=0.1$', '$\\sigma=0.3$', '$\\sigma=0.5$'], loc='upper right', fontsize='medium')
# plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/f2_test_para_range/TSVD_RMSE_N_noi531_1130.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.show()







