import numpy as np
import os, time
from Spectral_algorithms import XYZ_from_matfile, fun_rotation_mat, generate_data, Predicted_KI, Predicted_KRR, \
    Predicted_KGD, Predicted_TSVD, KRR_condi_lambda, KGD_condi_step, TSVD_condi_nu, parameter_lambda_krr_forplot, \
    parameter_step_kgd_forplot, parameter_lambda_TSVD_forplot, parameter_lambda_krr, RMSE_parameter_krr, RMSE_parameter_kgd, RMSE_parameter_tsvd
import pandas as pd
from numpy import *
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from matplotlib.ticker import FuncFormatter
time_start = time.time()


'''千万注意：test的规模会影响python在训练数据上的噪音生成，因此，如果训练参数的时候用的是100的test, 用generate时也是100test'''
'''目前spherical_plot_f2里面存有matlab可以直接画的100， 1000， 和2000test'''

'''0. set up'''
func = 'f2'  # from paper "DIVIDE AND CONQUER LEAST SQAURES FOR UNCERTAINTY OF KERNEL INTERPOLATION ON SPHERES"
f, d = 5, 3  # folds of corss-validation; dimension of the input X
test_size_use1 = (100, 3)
test_size_use2 = (3900, 3) # 补的
trails = 5
# spherical_plot_f2 = {}
# np.save('/Users/liuxiaotong/Documents/machine learning/4_Kernel method_spherical/Result_data/f2/spherical_plot_f2.npy', spherical_plot_f2)
# print('save spherical_plot_f2.npy done')


loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/spherical_plot_f2.npy', allow_pickle=True)
spherical_plot_f2 = loadData.tolist()
print(spherical_plot_f2.keys())

np.random.seed(1)
XYZ_train = XYZ_from_matfile(47)


'''generate data'''
noise_sd = 0.1
X_train, y_train, X_test_use1, y_test_use1 = generate_data(XYZ_train, test_size_use1, func, noise_sd)  # generate the (len(XYZ_train), d) training data set and (100, 3) testing data set
X_train_nouse, y_train_nouse, X_test_use2, y_test_use2 = generate_data(XYZ_train, test_size_use2, func, noise_sd)  # generate the (len(XYZ_train), d) training data set and (100, 3) testing data set
X_test = np.vstack((X_test_use1,X_test_use2))
y_test = np.hstack((y_test_use1,y_test_use2))


'''1. save the training data with differen level of noise 0.0, 0.01, 0.1, 0.5 '''
# # # spherical_plot_f2['X'] = X_train # (1130, 3)
# # # spherical_plot_f2['X_tes_1000'] = X_test # (1000, 3)
# # # spherical_plot_f2['y_tes_1000'] = y_test # (1000, 3)
# # spherical_plot_f2['X_tes_2000'] = X_test # (2000, 3)
# # spherical_plot_f2['y_tes_2000'] = y_test # (2000, 3)
# spherical_plot_f2['X_tes_4000'] = X_test # (4000, 3)
# spherical_plot_f2['y_tes_4000'] = y_test # (4000, 3)
# # # spherical_plot_f2['y'] = y_train
# # # spherical_plot_f2['y_noi5'] = y_train
# # # spherical_plot_f2['y_noi1'] = y_train
# # # spherical_plot_f2['y_noi3'] = y_train
# # np.save(os.path.dirname(os.getcwd()) + '/Result_data/spherical_plot_f2.npy', spherical_plot_f2)
# # print('save spherical_plot_f2.npy done')
# # print(spherical_plot_f2.keys())


'''2. save fit results when noise = 0.3, 0.1, 0.5'''
loadData1 = np.load(os.path.dirname(os.getcwd()) + '/Result_data/Bias_var_com.npy', allow_pickle=True)
Bias_var_com = loadData1.tolist()
print(Bias_var_com.keys())


'''2.0 by KI'''
# (2) calculate test error
fit = Predicted_KI(X_train, y_train, X_test, y_test, d)[0]
fit = np.array(fit)

# spherical_plot_f2['fit_kerinter_noi5'] = fit
# spherical_plot_f2['fit_kerinter_noi3'] = fit
# spherical_plot_f2['fit_kerinter_noi1'] = fit
# spherical_plot_f2['fit_kerinter_noi5_test1000'] = fit
# spherical_plot_f2['fit_kerinter_noi3_test1000'] = fit
# spherical_plot_f2['fit_kerinter_noi1_test1000'] = fit
# spherical_plot_f2['fit_kerinter_noi5_test4000'] = fit
# spherical_plot_f2['fit_kerinter_noi3_test4000'] = fit
spherical_plot_f2['fit_kerinter_noi1_test4000'] = fit


'''2.1 by KRR'''
# (2) take parameter
KRR_noi5 = Bias_var_com['KRR_rmse_noi5_1trail']
mus = Bias_var_com['KRR_mus_noi5_1trail']
KRR_noi3 = Bias_var_com['KRR_rmse_noi3_1trail']
KRR_noi1 = Bias_var_com['KRR_rmse_noi1_1trail']
mus_min = mus[np.argmin(KRR_noi1)]  # ⚠️ change input
print('mus_min:', mus_min)

# (3) calculate test error
fit = Predicted_KRR(X_train, y_train, X_test, y_test, d, mus_min)[0]
fit = np.array(fit)

# spherical_plot_f2['fit_KRR_noi5'] = fit
# spherical_plot_f2['fit_KRR_noi3'] = fit
# spherical_plot_f2['fit_KRR_noi1'] = fit
# spherical_plot_f2['fit_KRR_noi5_test1000'] = fit
# spherical_plot_f2['fit_KRR_noi3_test1000'] = fit
# spherical_plot_f2['fit_KRR_noi1_test1000'] = fit
# spherical_plot_f2['fit_KRR_noi5_test4000'] = fit
# spherical_plot_f2['fit_KRR_noi3_test4000'] = fit
spherical_plot_f2['fit_KRR_noi1_test4000'] = fit


'''2.2 by KGD'''
# (2) take parameter
# KGD_noi5 = Bias_var_com['KGD_rmse_noi5_1trail']
# ts_noi5 = Bias_var_com['KGD_ts_noi5_1trail']
# ts_min = ts_noi5[np.argmin(KGD_noi5)]

# KGD_noi3 = Bias_var_com['KGD_rmse_noi3_1trail']
# ts_noi3 = Bias_var_com['KGD_ts_noi3_1trail']
# ts_min = ts_noi3[np.argmin(KGD_noi3)]

KGD_noi1 = Bias_var_com['KGD_rmse_noi1_1trail']
ts_noi1 = Bias_var_com['KGD_ts_noi1_1trail']
ts_min = ts_noi1[np.argmin(KGD_noi1)]

# print('ts_min:', ts_min)
# KGD_noi5_min_index: 8
# ts_min: 2050  # noise=0.5
# ts_min: 4000 # noise=0.1
# ts_min: 40000 # noise=0.01

# (3) calculate test error
fit = Predicted_KGD(X_train, y_train, X_test, y_test, d, ts_min)[0]
fit = np.array(fit)

# spherical_plot_f2['fit_KGD_noi5'] = fit
# spherical_plot_f2['fit_KGD_noi1'] = fit
# spherical_plot_f2['fit_KGD_noi3'] = fit
# spherical_plot_f2['fit_KGD_noi5_test1000'] = fit
# spherical_plot_f2['fit_KGD_noi1_test1000'] = fit
# spherical_plot_f2['fit_KGD_noi3_test1000'] = fit
# spherical_plot_f2['fit_KGD_noi5_test4000'] = fit
spherical_plot_f2['fit_KGD_noi1_test4000'] = fit
# spherical_plot_f2['fit_KGD_noi3_test4000'] = fit


'''2.3 by TSVD'''
# (2) take parameter
TSVD_noi5 = Bias_var_com['TSVD_rmse_noi5_1trail']
nus = Bias_var_com['TSVD_nus_noi5_1trail']
TSVD_noi1 = Bias_var_com['TSVD_rmse_noi1_1trail']
TSVD_noi3 = Bias_var_com['TSVD_rmse_noi3_1trail']
nus_min = nus[np.argmin(TSVD_noi1)]    # ⚠️ change input
print('nus_min:', nus_min)
# TSVD_noi5_min_index: 53
# nus_min: 13.25  # noise=0.5
# nus_min: 0.5    # noise=0.1
# nus_min: 1.5    # noise=0.3

# (3) calculate test error
fit = Predicted_TSVD(X_train, y_train, X_test, y_test, d, nus_min)[0]
fit = np.array(fit)

# spherical_plot_f2['fit_TSVD_noi5'] = fit
# spherical_plot_f2['fit_TSVD_noi1'] = fit
# spherical_plot_f2['fit_TSVD_noi3'] = fit

# spherical_plot_f2['fit_TSVD_noi5_test1000'] = fit
# spherical_plot_f2['fit_TSVD_noi3_test1000'] = fit
# spherical_plot_f2['fit_TSVD_noi1_test1000'] = fit
# spherical_plot_f2['fit_TSVD_noi5_test4000'] = fit
# spherical_plot_f2['fit_TSVD_noi3_test4000'] = fit
spherical_plot_f2['fit_TSVD_noi1_test4000'] = fit
np.save(os.path.dirname(os.getcwd()) + '/Result_data/spherical_plot_f2.npy', spherical_plot_f2)
print('save spherical_plot_f2.npy done')
print(spherical_plot_f2.keys())





'''3.1 transform .npy file to .mat file'''
numpy_file = np.load(os.path.dirname(os.getcwd()) + '/Result_data/spherical_plot_f2.npy', allow_pickle=True)
import scipy.io as io
io.savemat(os.path.dirname(os.getcwd()) + '/Result_data/spherical_plot_f2.mat', {'data': numpy_file})
# dict_keys(['X', 'y', 'y_noi5', 'y_noi1', 'y_noi01', 'fit_KRR_noi5', 'fit_KGD_noi5', 'fit_TSVD_noi5',
# 'fit_TSVD_noi01', 'fit_TSVD_noi1', 'fit_KGD_noi1', 'fit_KGD_noi01', 'fit_KRR_noi01', 'fit_KRR_noi1'])




